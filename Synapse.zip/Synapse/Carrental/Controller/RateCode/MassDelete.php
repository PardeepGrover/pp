<?php
namespace Synapse\Carrental\Controller\RateCode;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\RateCodeFactory;
use Synapse\Carrental\Model\ResourceModel\RateCode\CollectionFactory;
use Magento\Customer\Model\Session;

/**
 * Class MassDelete
 * @package Magenest\RentalAndBookingSystem\Controller\Adminhtml\Attribute
 */
class MassDelete extends \Magento\Framework\App\Action\Action
{
    /**
     * @var VehicleTypeCollectionFactory
     */
	protected $rateCodeFactory;
	protected $rateCodeCollectionFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $_customerSession;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        Action\Context $context,
		CollectionFactory $collectionFactory,
		rateCodeFactory $rateCodeFactory,
		Session $customerSession,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->_filter = $filter;
		$this->rateCodeFactory = $rateCodeFactory;
		$this->rateCodeCollectionFactory = $collectionFactory;
		$this->_customerSession   = $customerSession;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
		$collection = $this->_filter->getCollection($this->rateCodeCollectionFactory->create());
		 
		$supplier_id = $this->_customerSession->getCustomer()->getId();
		
		
		if(isset($supplier_id) && $supplier_id!=''){
			$collection = $collection->addFieldToFilter('main_table.supplier_id',$supplier_id);	
		}
		if(!$this->getRequest()->getParam('excluded',false)) { 
			$ids = $this->getRequest()->getParam('selected');
			if(isset($ids) && count($ids)>0){
				$collection = $collection->addFieldToFilter('main_table.id',array('in'=>implode(',',$ids)));	
			}
		
		}		
		$deleted = 0;
		
         foreach($collection as $item) {
				$rateCodeFactoryModel = $this->rateCodeFactory->create();
				$rateCodeFactoryModel->load($item->getId())->delete();
				unset($rateCodeFactoryModel);
				$deleted++;
		}
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $deleted));
		
		/* Dispatch envent */
		/* $this->_eventManager->dispatch(
			'mass_event_vehicle_directory', ['supplier_id' => $supplier_id, 'action' => 'delete' ,'items'=>$collection]
		); */
		
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/ratecode');
    }
}
