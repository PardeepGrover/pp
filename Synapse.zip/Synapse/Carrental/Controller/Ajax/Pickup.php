<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Ajax;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Search\Model\AutocompleteInterface;
use Magento\Framework\Controller\ResultFactory;
#use Synapse\Carrental\Model\WarehouseinfoFactory;
use Synapse\Carrental\Model\LocationFactory;
use Synapse\Carrental\Model\ServiceLocationFactory;

class Pickup extends Action
{
    /**
     * @var  \Magento\Search\Model\AutocompleteInterface
     */
    private $autocomplete;
	
	private $warehouseinfoFactory;
	
	private $_servicelocationFactory;
    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Search\Model\AutocompleteInterface $autocomplete
     */
    public function __construct(
        Context $context,
        AutocompleteInterface $autocomplete,
		LocationFactory $LocationFactory,
		ServiceLocationFactory $ServiceLocationFactory
    ) {
        $this->autocomplete = $autocomplete;
		$this->locationFactory = $LocationFactory;
		$this->_servicelocationFactory = $ServiceLocationFactory;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        if (!$this->getRequest()->getParam('q', false)) {
            /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
            $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
            $resultRedirect->setUrl($this->_url->getBaseUrl());
            return $resultRedirect;
        }
		$responseData = [];
		$serviceLocationModel 	 = $this->_servicelocationFactory->create();
		$SlocationCollection = $serviceLocationModel->getCollection();
		$SlocationCollection->addFieldToFilter('main_table.location_type','pickup');
		/* join will replace with supplier service location */
		$SlocationCollection->getSelect()->joinLeft(
			 ['location'=>$SlocationCollection->getTable('directory_city_loctions')],
			 'location.locality_id= main_table.pickup_location_id',
			 ['location.location_name','location.locality_id']
		);
		$SlocationCollection->getSelect()->joinLeft(
			 ['city'=>$SlocationCollection->getTable('directory_country_region_city')],
			 'location.city_id= city.city_id',
			 ['city.city_name','city.country_id']
		 );
		 /* join will replace with supplier service location */
		$SlocationCollection->getSelect()->where
		('location.location_name like"%'.$this->getRequest()->getParam('q').'%"
			or 
			 city.city_name like "%'.$this->getRequest()->getParam('q').'%"
		');
		if($SlocationCollection):
			foreach($SlocationCollection as $_wval):
					$responseData[] = [
						"title" =>$_wval->getCountryId().'-'.$_wval->getCityName() .'-'.$_wval->getLocationName(),
						"num_results" =>"",
						"id" =>$_wval->getLocalityId(),
						"country_id" =>$_wval->getCountryId()
					];
			endforeach;
		endif;
		
        /** @var \Magento\Framework\Controller\Result\Json $resultJson */
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($responseData);
        return $resultJson;
    }
}
