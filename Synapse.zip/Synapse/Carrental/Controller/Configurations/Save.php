<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Configurations;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\ConfigurationsFactory;
use Magento\Framework\Controller\Result\JsonFactory ;
class Save extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $configurationsModelFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
		ConfigurationsFactory $ConfigurationsFactory,
        Validator $formKeyValidator,
		JsonFactory $resultJsonFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->configurationsModelFactory = $ConfigurationsFactory;
		$this->resultJsonFactory = $resultJsonFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		
		 
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		$result = $this->resultJsonFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParams();
			$configurationsModel = $this->configurationsModelFactory->create();
			$configurationsModel->setData($data);
			$configurationsModel->setId('1');
			$configurationsModel->save();
			
		 }catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			$this->session->logout();
			$this->session->start();
			$this->messageManager->addError($message);
			return $resultRedirect->setPath('customer/account/login');
		}
		catch (\Exception $e) {
			// $this->messageManager->addException($e, __('We can\'t save the Contacts.'));
		}

           // $this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
        //}
		return $resultRedirect->setPath('carrental/configurations');
    }
	
}
