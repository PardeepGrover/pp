<?php
namespace Synapse\Carrental\Controller\Fleet;
use Synapse\Carrental\Model\ResourceModel\Fleet\CollectionFactory;
use Synapse\Carrental\Model\FleetFactory;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\Model\View\Result\ForwardFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Customer\Model\Session;

/**
 * Class MassStatus
 */
class MassDelete extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $fleetcarmodelsFactory;
	
	protected $fleetModelFactory;
	
	protected $fleetCollectionFactory;
	
	private $dataPersistor;
	
	protected $_customerSession;

    /**
     * MassStatus constructor.
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param LocationFactory $locationFactory
     * @param ForwardFactory $forwardFactory
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
		CollectionFactory $collectionFactory,
        DataPersistorInterface $dataPersistor,
        ForwardFactory $forwardFactory,
        Filter $filter,
		Session $customerSession,
		FleetFactory $FleetFactory
    ) {
        parent::__construct($context);
        $this->_filter = $filter;
		$this->fleetCollectionFactory = $collectionFactory;
		$this->fleetModelFactory = $FleetFactory;
		$this->dataPersistor = $dataPersistor;
		$this->_customerSession   = $customerSession;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {

		$collection = $this->_filter->getCollection($this->fleetCollectionFactory->create());
		
		$supplier_id = $this->_customerSession->getCustomer()->getId();
		
		$totals = 0;
		
		try {			
			foreach ($collection as $item) {
				$model = $this->fleetModelFactory->create();
				$model->setId($item->getId());
				$model->setIsDeleted('1');
				$model->save();
				//$item->delete();
				$totals++;
			}
			
		$this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $totals));
		} catch (\Magento\Framework\Exception\LocalizedException $e) {
			$this->messageManager->addErrorMessage($e->getMessage());
		} catch (\Exception $e) {
			$this->_getSession()->addException($e, __('Something went wrong while updating the location(s) status.'));
		}
		
		/* Dispatch envent */
		$this->_eventManager->dispatch(
			'mass_event_fleet', ['supplier_id' => $supplier_id, 'action' => 'delete' ,'items'=>$collection]
		);
		

				unset($collection);
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		return $resultRedirect->setPath('carrental/fleet/');

    }
}

