<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Fleet;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Model\FleetcarmodelsFactory;
use Synapse\Carrental\Model\VehicleDirectoryFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Massadd extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $fleetFactory;
	protected $fleetcarmodelsFactory;
	protected $vehicleDirectoryFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		FleetFactory $FleetFactory,
		FleetcarmodelsFactory $FleetcarmodelsFactory,
		VehicleDirectoryFactory $VehicleDirectoryFactory,
		JsonFactory $resultJsonFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->fleetFactory = $FleetFactory;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
		$this->vehicleDirectoryFactory = $VehicleDirectoryFactory;
		$this->resultJsonFactory = $resultJsonFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		/** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		$result = $this->resultJsonFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParams();
			$fleetId = '';
			if($data){
				$fleetModel = $this->fleetFactory->create(); 
				if(isset($data['fleet_name']) && $data['fleet_name']!=''){
					$fleetModel->setFleetName($data['fleet_name']);
					$fleetModel->setSupplierId($this->session->getCustomer()->getId());
					$newrow = $fleetModel->save();
					$fleetId = $newrow->getId();
				
				}else{
					$fleetId = $data['fleet_list'];
				}
				$vmodel = $this->vehicleDirectoryFactory->create();
				if(isset($data['selected']) && count($data['selected'])){
					foreach($data['selected'] as $_cmodelId):
						
						/* getting data from directory to copy in fleet car models */ 
						$vehicleCollection = $vmodel->getCollection();
						$vehicleCollection->addFieldToFilter('main_table.supplier_id',$this->session->getCustomer()->getId());
						$vehicleCollection->addFieldToFilter('main_table.car_model_id',$_cmodelId);
						$vcoll = $vehicleCollection->getFirstItem();
						/* getting data from directory to copy in fleet car models */ 
						
						/* Copying in fleet car model with assigned fleets */ 
						$fleetcarmodelsFactry = $this->fleetcarmodelsFactory->create();
						
						/* checking if already added the carmodel in fleet then updating */ 
						$fleetcarmodelCollection = $fleetcarmodelsFactry->getCollection();
						$fleetcarmodelCollection->addFieldToFilter('main_table.fleet_id',$fleetId);
						$fleetcarmodelCollection->addFieldToFilter('main_table.car_model_id',$_cmodelId);
						$fleetcarmodelid = $fleetcarmodelCollection->getFirstItem()->getId();
						if(isset($fleetcarmodelid) && $fleetcarmodelid!=''){
							$fleetcarmodelsFactry->setId($fleetcarmodelid);
							unset($fleetcarmodelCollection);
						}
						/* checking if already added the carmodel in fleet then updating */ 
						
						$fleetcarmodelsFactry->setFleetId($fleetId);
						$fleetcarmodelsFactry->setCarModelId($_cmodelId);
						$fleetcarmodelsFactry->setVehicleTransmission($vcoll->getVehicleTransmission());
						$fleetcarmodelsFactry->setVehicleFuel($vcoll->getVehicleFuel());
						$fleetcarmodelsFactry->setCarmodelClass($vcoll->getCarmodelClass());
						$fleetcarmodelsFactry->setQty($vcoll->getQty());
						$fleetcarmodelsFactry->save();
						/* Copying in fleet car model with assigned fleets */ 
						unset($vehicleCollection);
						unset($vcoll);
						unset($fleetcarmodelsFactry);
					endforeach;
					$message = __(
							'Record(s) saved successfully!'
					);
					$this->messageManager->addSuccess($message);
				}
				
				//$result->setData(['success' => true]);
				//return $result;
				 
			}
		}catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			$this->session->logout();
			$this->session->start();
			$this->messageManager->addError($message);
			return $resultRedirect->setPath('customer/account/login');
		}
		catch (\Exception $e) {
			$this->messageManager->addException($e, __('We can\'t save the records.'));
			 
		}
	
           // $this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
        //}
		return $resultRedirect->setPath('carrental/fleet/view/',array('id'=>$fleetId));
    }
	
}
