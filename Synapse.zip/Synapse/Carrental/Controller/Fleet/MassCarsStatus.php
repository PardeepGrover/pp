<?php
namespace Synapse\Carrental\Controller\Fleet;

use Synapse\Carrental\Model\FleetcarmodelsFactory;
use Synapse\Carrental\Model\ResourceModel\Fleetcarmodels\CollectionFactory;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\Model\View\Result\ForwardFactory;
use Magento\Framework\Controller\ResultFactory;
use Magenest\RentalAndBookingSystem\Controller\Adminhtml\Location as LocationController;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Framework\App\Request\DataPersistorInterface;

/**
 * Class MassStatus
 */
class MassCarsStatus extends \Magento\Framework\App\Action\Action
{
    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $fleetcarmodelsFactory;
	
	protected $fleetcarmodelsCollectionFactory;
	
	private $dataPersistor;

    /**
     * MassStatus constructor.
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param LocationFactory $locationFactory
     * @param ForwardFactory $forwardFactory
     * @param Filter $filter
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
		CollectionFactory $collectionFactory,
        FleetcarmodelsFactory $FleetcarmodelsFactory,
	    DataPersistorInterface $dataPersistor,
        ForwardFactory $forwardFactory,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->_filter = $filter;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
		$this->fleetcarmodelsCollectionFactory = $collectionFactory;
		$this->dataPersistor = $dataPersistor;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {

		$collection = $this->_filter->getCollection($this->fleetcarmodelsCollectionFactory->create());
		$status = (int) $this->getRequest()->getParam('status');
		$fleet_id  = $this->dataPersistor->get('view_id');
		if(isset($fleet_id) && $fleet_id!=''){
			if($this->getRequest()->getParam('excluded',false)) { 
				$collection = $collection->addFieldToFilter('fleet_id',$fleet_id);
			}
		}
		$totals = 0;
		try {			
			foreach ($collection as $item) {
				$fleetCarModel = $this->fleetcarmodelsFactory->create();
				$fleetCarModel->load($item->getId())
				->setId($item->getId())
				->setStatus($status)
				->save();
				unset($fleetCarModel);
				$totals++;
			}
			
		$this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been updated.', $totals));
		} catch (\Magento\Framework\Exception\LocalizedException $e) {
			$this->messageManager->addErrorMessage($e->getMessage());
		} catch (\Exception $e) {
			$this->_getSession()->addException($e, __('Something went wrong while updating the location(s) status.'));
		}
		unset($collection);
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
		return $resultRedirect->setPath('carrental/fleet/view',array('id'=>$fleet_id));

    }
}

