<?php 
namespace Synapse\Carrental\Controller\Fleet;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
class View extends \Magento\Framework\App\Action\Action { 
	
	protected $resultPageFactory;
	protected $_customerSession;
	 /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		 DataPersistorInterface $dataPersistor
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
			$this->dataPersistor = $dataPersistor;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$this->dataPersistor->set('view_id',$this->getRequest()->getParam('id'));
		 $resultPage = $this->resultPageFactory->create();
		$resultPage->addHandle('carrental_fleet_view');
		return $resultPage;
	} 
  
} 


 
