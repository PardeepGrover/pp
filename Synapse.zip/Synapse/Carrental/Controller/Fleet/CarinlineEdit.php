<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Fleet;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\FleetcarmodelsFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class CarinlineEdit extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $fleetcarmodelsFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		JsonFactory $resultJsonFactory,
		FleetcarmodelsFactory $FleetcarmodelsFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		$resultJson = $this->resultJsonFactory->create();
		$error = false;
        $messages = [];
		$postItems = $this->getRequest()->getParam('items', []);
		if (!count($postItems)) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }
		try {
			$data = $this->getRequest()->getParam('items');
			if($data){
				$supplierId = $this->session->getcustomer()->getId();
				foreach($data as $did=>$_car):
					$fleetcarModel = $this->fleetcarmodelsFactory->create();
					$fleetcarModel->setId($_car['id']);
					$fleetcarModel->setVehicleTransmission($_car['vehicle_transmission']);
					$fleetcarModel->setVehicleFuel($_car['vehicle_fuel']);
					$fleetcarModel->setCarmodelClass($_car['carmodel_class']);
					$fleetcarModel->setQty($_car['qty']);
					$fleetcarModel->save();
				endforeach;
				$message = __(
					'updated Record added in Your Vehicle Directory',4
				);
				//$this->messageManager->addSuccess($message);
					
			}
		}catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			$error = true;
			
		}
		catch (\Exception $e) {
			  $error = true;
			$message = __(
					'Something went wrong'
				);
		}
		return $resultJson->setData([
            'messages' => $message,
            'error' => $error
        ]);
    }
	
}
