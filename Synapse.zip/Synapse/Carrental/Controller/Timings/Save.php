<?php 
namespace Synapse\Carrental\Controller\Timings;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\UrlInterface ;
use Synapse\Carrental\Helper\Data as Carrentalhelper;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Synapse\Carrental\Model\WarehousetimingsrangeFactory;
use Synapse\Carrental\Model\HolidaysFactory;
class Save extends \Magento\Framework\App\Action\Action { 
	
	private $_helper;
	private $_urlInterface;
	private $_holidaysFactory;
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		FormKeyValidator $formKeyValidator,
		Carrentalhelper $carrentalhelper ,
		UrlInterface $UrlInterface,
		WarehousetimingsrangeFactory $WarehousetimingsrangeFactory,
		HolidaysFactory $HolidaysFactory
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
            $this->resultRedirectFactory = $context->getResultRedirectFactory();
            $this->_formKeyValidator = $formKeyValidator;
            $this->_helper =           $carrentalhelper;
            $this->_urlInterface    =  $UrlInterface;
            $this->_warehousetimingsrangeFactory    =  $WarehousetimingsrangeFactory;
            $this->_holidaysFactory    =  $HolidaysFactory;
			
            return parent::__construct($context);
        }
	/**
     * Process  form save
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
       $resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
        $redirectUrl = null;
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
        if (!$this->getRequest()->isPost()) {
           $this->_getSession()->setTimingsFormData($this->getRequest()->getPostValue());
            return $this->resultRedirectFactory->create()->setUrl(
                $this->_redirect->error($this->_buildUrl('*/*/add'))
            );
        }
        try {
		    $warehousetimings = $this->getRequest()->getParam('timings');
			//echo "<pre>";
			//var_dump($warehousetimings['holidays']);
			//die;
			$customer = $this->_customerSession;
            $supplier_id = $customer->getCustomer()->getId();
			if($warehousetimings['event_type']==2 && isset($warehousetimings['holidays'])){
				foreach($warehousetimings['holidays'] as $_hid){
					$warehousetimingsFactory  = $this->_helper->WarehousetimingsFactory();
					$warehousetimingsFactory->setData($warehousetimings);
					$warehousetimingsFactory->setPickupHours(serialize($warehousetimings['pickuphours']));
					
					if(isset($warehousetimings['dropoffhours'][0]['sameaspickup'])):
						$warehousetimingsFactory->setDropoffHours(serialize($warehousetimings['pickuphours']));
					else:
						$warehousetimingsFactory->setDropoffHours(serialize($warehousetimings['dropoffhours']));
					
					endif;
					
					$warehousetimingsFactory->setSupplierId($supplier_id);
					$warehousetimingsFactory->setHolidays($_hid);
					$issaved = $warehousetimingsFactory->save();
				}
				
			}
			 
			if($warehousetimings['event_type']==1){
				/* storing data in timings table */
				$warehousetimingsFactory  = $this->_helper->WarehousetimingsFactory();
				$warehousetimingsFactory->setData($warehousetimings);
				$warehousetimingsFactory->setPickupHours(serialize($warehousetimings['pickuphours']));
				if(isset($warehousetimings['dropoffhours'][0]['sameaspickup'])):
						$warehousetimingsFactory->setDropoffHours(serialize($warehousetimings['pickuphours']));
				else:
					$warehousetimingsFactory->setDropoffHours(serialize($warehousetimings['dropoffhours']));
				
				endif;
				
				$warehousetimingsFactory->setWeekday(implode(',', array_filter($warehousetimings['weekday'][0])));
				$warehousetimingsFactory->setSupplierId($supplier_id);
				
				
				if(isset($warehousetimings['pickuphours'][0]['pickuphours24'])){
					 
					$warehousetimingsFactory->setPickuphourstwentyfour($warehousetimings['pickuphours'][0]['pickuphours24']);
				}
				if(isset($warehousetimings['dropoffhours'][0]['dropoffhours24'])){
					 
					$warehousetimingsFactory->setDropoffhourstwentyfour($warehousetimings['dropoffhours'][0]['dropoffhours24']);
				}
				 
				if(isset($warehousetimings['dropoffhours'][0]['is_dropoffbox'])){
					$warehousetimingsFactory->setIsDropoffbox($warehousetimings['dropoffhours'][0]['is_dropoffbox']);
				}
				if(isset($warehousetimings['dropoffhours'][0]['sameaspickup'])){
					$warehousetimingsFactory->setSameaspickup($warehousetimings['dropoffhours'][0]['sameaspickup']);
				}
				
				$issaved = $warehousetimingsFactory->save();
			}
			if($warehousetimings['event_type']==1){
				$working_dates = $this->getAllDatesByDayName($warehousetimings);
			}else{
				$working_dates = $this->getAllDatesFromHolidays($warehousetimings);
			}
			if (!empty($working_dates)) {
				
				$this->deleteExistingWorkingHoursForSameDate($working_dates,$warehousetimings,$supplier_id);
				$pickuphours = [];
				foreach ($working_dates as $working_date) {
					if (isset($warehousetimings['pickuphours']) && !empty(			$warehousetimings['pickuphours'])) {
						if(isset($warehousetimings['pickuphours'][0]['pickuphours24'])){
							$pickuphours[0]['time_from'] = '00:00:00';
							$pickuphours[0]['time_to'] = '23:59:59';
						}else{
							$pickuphours = $warehousetimings['pickuphours'];
						}
						foreach ($pickuphours as $ph) {
							$ph_inp_arr = array();
							$ph_inp_arr['working_date'] = $working_date;
							$ph_inp_arr['supplier_id'] = $supplier_id;
							$ph_inp_arr['warehouse_id'] = $warehousetimings['warehouse_id'];
							$ph_inp_arr['start_date'] = $warehousetimings['from_date'];
							$ph_inp_arr['end_date'] = $warehousetimings['to_date'];
							$ph_inp_arr['event_type'] = $warehousetimings['event_type'];
							$ph_inp_arr['week_days'] = @implode(',', array_filter($warehousetimings['weekday'][0]));
							$ph_inp_arr['status'] = 1;
							$ph_inp_arr['pickup_start_time'] = $ph['time_from'];
							$ph_inp_arr['pickup_end_time'] = $ph['time_to'];
							$ph_inp_arr['fee'] = $ph['fee_amount'] ?? null;
							$rangemodel = $this->_warehousetimingsrangeFactory->create();
							$rangemodel->setData($ph_inp_arr);
							$rangemodel->save();
						}
						
					}
					
					 if (isset($warehousetimings['dropoffhours']) && !empty($warehousetimings['dropoffhours'])) {
						if(isset($warehousetimings['dropoffhours'][0]['dropoffhours24'])){
							$dropoffhours[0]['time_from'] = '00:00:00';
							$dropoffhours[0]['time_to'] = '23:59:59';
						}else{
							$dropoffhours = $warehousetimings['dropoffhours'];
						}
						if(isset($warehousetimings['dropoffhours'][0]['sameaspickup'])){
							 $dropoffhours = $pickuphours;
						}
                            foreach ($dropoffhours as $dh) {
								$ph_inp_arr = array();
								$ph_inp_arr['working_date'] = $working_date;
								$ph_inp_arr['supplier_id']  = $supplier_id;
								$ph_inp_arr['warehouse_id'] = $warehousetimings['warehouse_id'];
								$ph_inp_arr['start_date']   = $warehousetimings['from_date'];
								$ph_inp_arr['end_date']   = $warehousetimings['to_date'];
								$ph_inp_arr['event_type'] = $warehousetimings['event_type'];
								$ph_inp_arr['week_days']  = @implode(',', array_filter($warehousetimings['weekday'][0]));
								$ph_inp_arr['status'] = 1;
								$ph_inp_arr['dropoff_start_time'] = $dh['time_from'];
								$ph_inp_arr['dropoff_end_time'] = $dh['time_to'];
								$ph_inp_arr['fee'] = $dh['fee_amount'] ?? null;
								$rangemodel = $this->_warehousetimingsrangeFactory->create();
								$rangemodel->setData($ph_inp_arr);
								$rangemodel->save();
                            }
                        }
					 
				}
				 
				 
			}
			 
            $this->messageManager->addSuccess(__('Record Successfully saved!.'));
            $url = $this->_urlInterface->getUrl('*/*/index');
            return $this->resultRedirectFactory->create()->setUrl($this->_redirect->success($url));
        } catch (InputException $e) {
            $this->messageManager->addError($e->getMessage());
            foreach ($e->getErrors() as $error) {
                $this->messageManager->addError($error->getMessage());
            }
        } catch (\Exception $e) {
            
             var_dump($e->getMessage());
			 die;
            $redirectUrl = $this->_urlInterface->getUrl('*/*/index');
            $this->messageManager->addException($e, __('We can\'t save the data.'));
        }

        $url = $redirectUrl;
        if (!$redirectUrl) {
            $this->_getSession()->setWarehouseFormData($this->getRequest()->getPostValue());
            $url = $this->_urlInterface->getUrl('*/*/index', ['id' => $this->getRequest()->getParam('id')]);
       }

        return $this->resultRedirectFactory->create()->setUrl($this->_redirect->error($url));
    }
    
    protected  function getAllDatesByDayName($warehousetimings){
        $weekday = array_filter($warehousetimings['weekday'][0]);
		$date_array = [];
		$days=['1'=>'Monday',
			   '2' => 'Tuesday',
			   '3' => 'Wednesday',
			   '4'=>'Thursday',
			   '5' =>'Friday',
			   '6' => 'Saturday',
			   '7'=>'Sunday',
			    
			];
		if (!empty($warehousetimings)) {
			foreach ($weekday as $day_number){
				if($day_number==8)
				 continue;	
				for($i = strtotime($days[$day_number], strtotime($warehousetimings['from_date'])); $i <= strtotime($warehousetimings['to_date']); 		$i = strtotime('+1 week', $i)){
					$date_array[]=date('Y-m-d',$i);
					 
				}
			}
			return $date_array;		 
		}
        
    }
	public function deleteExistingWorkingHoursForSameDate($working_dates,$warehousetimings,$supplier_id){
		$rangemodel = $this->_warehousetimingsrangeFactory->create();
		$rangeCollection = $rangemodel->getCollection();
		$rangeCollection->addFieldToFilter('working_date',['in'=>$working_dates]);
		$rangeCollection->addFieldToFilter('supplier_id',['eq'=>$supplier_id]);
		$rangeCollection->addFieldToFilter('warehouse_id',['eq'=>$warehousetimings['warehouse_id']]);
		$rangeCollection->addFieldToFilter('event_type',['eq'=>$warehousetimings['event_type']]);
		$rangeCollection->walk('delete');
		
		 
		
	}
	public function getAllDatesFromHolidays($warehousetimings){
		$holidayModel = $this->_holidaysFactory->create();
		$collection = $holidayModel->getCollection();
		$collection->addFieldToFilter('id',['in'=>$warehousetimings['holidays']]);
		$collection->addFieldToSelect('holiday_date');
		$holidaydays = $collection->getColumnValues('holiday_date');
		return  $holidaydays;
		
	}
} 


 
