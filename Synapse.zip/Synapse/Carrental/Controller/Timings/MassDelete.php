<?php

namespace Synapse\Carrental\Controller\Timings;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\ResourceModel\Warehousetimings\CollectionFactory;
use Synapse\Carrental\Model\WarehousetimingsFactory;
use Magento\Customer\Model\Session;

class MassDelete extends \Magento\Framework\App\Action\Action
{
 
    protected $warehouseTimingsFactory;
	
	protected $warehousetimingsModelFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $resultFactory;
	
	protected $_customerSession;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CollectionFactory $CollectionFactory,
		WarehousetimingsFactory $WarehousetimingsFactory,
		Session $customerSession,
        Filter $filter
    ) {
		parent::__construct($context);

        $this->_filter = $filter;
        $this->warehouseTimingsFactory = $CollectionFactory;
		$this->warehousetimingsModelFactory =$WarehousetimingsFactory;
		$this->_customerSession   = $customerSession;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->warehouseTimingsFactory->create());

		$delete = 0;
		$supplier_id = $this->_customerSession->getCustomer()->getId();
        
		foreach ($collection as $item) {
			$model = $this->warehousetimingsModelFactory->create();
			$model->load($item->getTimingId())->delete();
			unset($model);
			//$item->delete();
            $delete++;
        }
        
		$this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $delete));
       
		/* Dispatch envent */
		$this->_eventManager->dispatch(
			'mass_event_timings_delete', ['supplier_id' => $supplier_id, 'action' => 'delete' ,'items'=>$collection]
		);
        
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/timings');
    }
}
