<?php 
namespace Synapse\Carrental\Controller\Timings;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
class Index extends \Magento\Framework\App\Action\Action { 
	
	/**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	protected $resultPageFactory;
	protected $_customerSession;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		DataPersistorInterface $dataPersistor
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
			$this->dataPersistor = $dataPersistor;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$id = '';
		$id = $this->getRequest()->getParam('id',false);
		$this->dataPersistor->set('front_warehouse_id',$id);
		 
		$resultPage = $this->resultPageFactory->create();
		$resultPage->addHandle('carrental_timings_index');
		return $resultPage;
	} 
  
} 


 
