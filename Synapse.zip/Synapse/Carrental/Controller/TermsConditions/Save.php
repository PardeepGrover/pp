<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\TermsConditions;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\TermsConditionsFactory;
use Synapse\Carrental\Model\TermsConditionsContentFactory;

/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $_termsConditionsFactory;
	protected $_termsConditionsContentFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		TermsConditionsFactory $TermsConditionsFactory,
		TermsConditionsContentFactory $TermsConditionsContentFactory
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->_termsConditionsFactory = $TermsConditionsFactory;
		$this->_termsConditionsContentFactory = $TermsConditionsContentFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());

		if ($validFormKey && $this->getRequest()->isPost()) {
			try {
				$termsConditionsModel = $this->_termsConditionsFactory->create();
				$termsConditionsModel->setTitle('test');
				$termsConditionsModel->setSupplierId($this->session->getCustomer()->getId());
				$termsConditionsModel->save();
				$termsConditionId = $termsConditionsModel->getId();
				if($termsConditionId) {
					$postData = $this->getRequest()->getParams();
					if(!empty($postData['caption'])){
						$termsConditionsContentModel = $this->_termsConditionsContentFactory->create();
						foreach($postData['caption'] as $key => $value){
							if($value['value']|| $value['value'] !='') {
								$termsConditionsContentModel->setTermsConditionId($termsConditionId);
								$termsConditionsContentModel->setCategoryId($value['subcapton_id']);
								$termsConditionsContentModel->setContent($value['value']);
								$termsConditionsContentModel->setSupplierId($this->session->getCustomer()->getId());
								$termsConditionsContentModel->setStatus(1);
								$termsConditionsContentModel->save();
							}

						}						
					}					
				}
				$this->messageManager->addSuccess(__('You saved the  information.'));
                
				return $resultRedirect->setPath('carrental/termsconditions/');
            }catch (UserLockedException $e) {
                $message = __(
                    'You did not sign in correctly or your account is temporarily disabled.'
                );
                $this->session->logout();
                $this->session->start();
                $this->messageManager->addError($message);
                return $resultRedirect->setPath('customer/account/login');
            }
            catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t save the Terms Conditions.'));
            }

            $this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
        }
		return $resultRedirect->setPath('carrental/termsconditions/edit');
    }
	
}
