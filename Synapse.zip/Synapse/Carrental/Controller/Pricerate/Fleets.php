<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Pricerate;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\WarehouseinfoFactory;
use Synapse\Carrental\Model\FleetFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Fleets extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleDirectoryFactory;
	protected $fleetModelFactory;
	protected $warehouseinfoFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		WarehouseinfoFactory $warehouseinfoFactory,
		JsonFactory $resultJsonFactory,
		FleetFactory $FleetFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->fleetModelFactory = $FleetFactory;
		$this->warehouseinfoFactory = $warehouseinfoFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		
		 
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		//$resultRedirect = $this->resultRedirectFactory->create();
		$resultJson = $this->resultJsonFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParams();
			if($data){
				$str = '<option value="">Select</option>';
				$supplierId = $this->session->getcustomer()->getId();
				$warehousemodel  = $this->warehouseinfoFactory->create();
				$warehousecollection =  $warehousemodel->getCollection();
				$warehousecollection->addFieldToFilter('main_table.supplier_id',$supplierId);
				$warehousecollection->addFieldToFilter('main_table.id',$data['warehouse_id']);
				$warehousecollection->addFieldToSelect('assigned_fleets');
				$warehousecollection->getSelect()->joinLeft(
					['flt'=>$warehousecollection->getTable('wais_fleet')],
					'FIND_IN_SET(flt.id, main_table.assigned_fleets) > 0',
					['flt.id','flt.fleet_name']
				);
				if($warehousecollection->getSize()){
					foreach($warehousecollection as $res):
						$str = $str.'<option value="'.$res->getId().'">'.$res->getFleetName().'</option>';
					endforeach;
					
				}
				 
				 return $resultJson->setData([
						'messages' => [__('Saved SuccessFully')],
						'error' => 0,
						'result'=>$str
					]);
			}
		}catch (UserLockedException $e) {
			return $resultJson->setData([
				'messages' => 'You did not sign in correctly or your account is temporarily disabled',
				'error' =>1 
			]);
		}
		catch (\Exception $e) {
			return $resultJson->setData([
				'messages' => $e->getMessage(),
				'error' => 1
			]);
		
		}
		
    }
	private function getDefaultFleetId($supplierId){
		
		$fleetModel = $this->fleetModelFactory->create();
		$fleetCollection = $fleetModel->getCollection();
		$fleetCollection->addFieldToFilter('main_table.supplier_id',$supplierId);
		$fleetCollection->addFieldToFilter('fleet_name','Default');
		$fleetCollection->addFieldToSelect('id');
		unset($fleetModel);
		return $fleetCollection->getFirstItem()->getId();
	}
	private function IsExistInDirectory($_carmodelid){
		$vdirectoryModel = $this->vehicleDirectoryFactory->create();
		$dircoll = $vdirectoryModel->getCollection();
		$dircoll->addFieldToFilter('car_model_id',$_carmodelid);
		$id = $dircoll->getFirstItem()->getId();
		unset($vdirectoryModel);
		return $id;
	}
	
}
