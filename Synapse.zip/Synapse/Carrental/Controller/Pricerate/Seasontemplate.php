<?php 
namespace Synapse\Carrental\Controller\Pricerate;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Registry;
class Seasontemplate extends \Magento\Framework\App\Action\Action { 
	
	protected $resultPageFactory;
	protected $_customerSession;
	protected $_registry;
	protected $_resultJsonFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory,
		\Magento\Customer\Model\Session $customerSession,
		Registry $registry
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
			$this->_registry = $registry;
			$this->_resultJsonFactory = $resultJsonFactory;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$resultPage = $this->resultPageFactory->create();
		$this->_registry->register('seasontemplaterequestdata',$this->getRequest()->getParams());
		//$this->_registry->register('season_id',$this->getRequest()->getParam('season_id'));
		$html = $resultPage->getLayout()->createBlock('Synapse\Carrental\Block\Supplier\Pricerate')->setTemplate('Synapse_Carrental::supplier/pricerate/seasonlist.phtml')->tohtml();
		
		$result = $this->_resultJsonFactory->create();
		return $result->setData(['success' => true,'html'=>$html]);
		 
	
               
	} 
  
} 


 
