<?php 
namespace Synapse\Carrental\Controller\Pricerate;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
class View extends \Magento\Framework\App\Action\Action { 
	
	protected $resultPageFactory;
	protected $_customerSession;
	protected $_registry;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Framework\Registry $registry
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
			$this->_registry = $registry;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$this->_registry->register('edit_id',$this->getRequest()->getParam('id'));
		$resultPage = $this->resultPageFactory->create();
		$resultPage->addHandle('carrental_pricerate_view');
		 return $resultPage;
               
	} 
  
} 


 
