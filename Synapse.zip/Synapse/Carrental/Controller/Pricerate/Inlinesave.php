<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Pricerate;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehiclepricelistFactory;
use Synapse\Carrental\Model\VehiclepricelistseasonsFactory;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
use Magento\Framework\Registry;
 


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Inlinesave extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleseasonalpriceFactory;
	
	protected $_registry;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
		Registry $registry
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
		$this->_registry = $registry;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		$data = $this->getRequest()->getParams();
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		if ($this->getRequest()->isPost()) {
			try {
				if($data['inline']){
					foreach($data['inline'] as $id=>$price):
					$model = $this->vehicleseasonalpriceFactory->create();
					$model->setId($id);
					$model->setPrice($price);
					$model->save();
					endforeach;
				}
				
				$this->messageManager->addSuccess(__('You saved the  information.'));
                return $resultRedirect->setPath('carrental/pricerate/view/id/'.$data['pricelist_id']);
            }catch (UserLockedException $e) {
                $message = __(
                    'You did not sign in correctly or your account is temporarily disabled.'
                );
                $this->session->logout();
                $this->session->start();
                $this->messageManager->addError($message);
                return $resultRedirect->setPath('customer/account/login');
            }
            catch (\Exception $e) {
				$this->messageManager->addException($e, __('We can\'t save the Contacts.'.$e->getMessage()));
            }

            //$this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
        }
		return $resultRedirect->setPath('carrental/pricerate/view/id/'.$data['pricelist_id']);
    }
	
}
