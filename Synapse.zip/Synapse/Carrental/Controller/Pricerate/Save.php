<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Pricerate;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehiclepricelistFactory;
use Synapse\Carrental\Model\VehiclepricelistseasonsFactory;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
 


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehiclepricelistFactory;
	protected $vehiclepricelistseasonsFactory;
	protected $vehicleseasonalpriceFactory;
	
	
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		VehiclepricelistFactory $VehiclepricelistFactory,
		VehiclepricelistseasonsFactory $VehiclepricelistseasonsFactory,
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->vehiclepricelistFactory = $VehiclepricelistFactory;
		$this->vehiclepricelistseasonsFactory = $VehiclepricelistseasonsFactory;
		$this->vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());
		if ($validFormKey && $this->getRequest()->isPost()) {
			try {
				$supplierId = $this->session->getCustomer()->getId();
				$sseasonId = '';
				$data = $this->getRequest()->getParams();
				$pricelistModel = $this->vehiclepricelistFactory->create();
				$pricelistModel->setPricelistName($data['arr']['pricelist_name']);
				$pricelistModel->setSupplierId($supplierId);
				$pricelistModel->setWarehouseId($data['arr']['warehouse']);
				$pricelistModel->setRateCode($data['arr']['ratecode']);
				$pricelistModel->setPickupFromdate($data['arr']['from_date']);
				$pricelistModel->setPickupTodate($data['arr']['to_date']);
				$pricelistModel->setFleetId($data['arr']['fleets']);
				$pricelistModel->setStatus('1');
				$savedpricelistobj = $pricelistModel->save();
				$pricelistId = $savedpricelistobj->getId();
				
				if(isset($data['season'])){
					$seasonIdarr = [];
					foreach($data['season'] as $k=>$_val){
						$seasonlistModel = $this->vehiclepricelistseasonsFactory->create();
						if($_val['season_name']){
							$seasonlistModel->setSupplierId($supplierId);
							$seasonlistModel->setWarehouseId($data['arr']['warehouse']);
							$seasonlistModel->setPricelistId($pricelistId);
							$seasonlistModel->setSeasonName($_val['season_name']);
							$seasonlistModel->setSeasonFromDate($_val['season_from_date']);
							$seasonlistModel->setSeasonToDate($_val['season_to_date']);
							$savedSeasons = $seasonlistModel->save();
							$sseasonId = $savedSeasons->getId();
							$seasonIdarr[$k] = $sseasonId;
						
						}
						
						 
					}
					
				}
				if($prices = $data['arr']['season_price']){
						    $seasonIds = [];
							foreach($prices as $_carmodelId =>$seasonprices){
								foreach($seasonprices as $seasonId => $pricess){
									foreach($pricess as $templateId => $subtemplate){
										foreach($subtemplate as $subtempId => $vals){
										 $seasonsPriceModel = $this->vehicleseasonalpriceFactory->create();
										 $seasonsPriceModel->setSupplierId($supplierId);
										 $seasonsPriceModel->setPricelistId($pricelistId);
										 $seasonsPriceModel->setSeasonId($seasonIdarr[$seasonId]);
										 $seasonsPriceModel->setFleetId($data['arr']['fleets']);
										 $seasonsPriceModel->setTemplateId($templateId);
										 $seasonsPriceModel->setSubTemplateId($subtempId);
										  $seasonsPriceModel->setSubTemplatePriceRange('');
										 $seasonsPriceModel->setCarModelId($_carmodelId);
										 $seasonsPriceModel->setPrice($vals);
										 $dta = $seasonsPriceModel->save();
										 unset($seasonsPriceModel);
										 
										 $seasonIds[] = $dta->getId();
										
										}
										
									}
								}
							}
							 
				$objdata = new \Magento\Framework\DataObject(array('ids' =>array_unique($seasonIds)));
				$this->_eventManager->dispatch('synapse_carrental_product_create', ['ids' => $objdata]);
					 
				}
				
				unset($seasonlistModel);
				unset($seasonsPriceModel);
				$this->messageManager->addSuccess(__('You saved the  information.'));
                return $resultRedirect->setPath('carrental/pricerate/');
            }catch (UserLockedException $e) {
                $message = __(
                    'You did not sign in correctly or your account is temporarily disabled.'
                );
                $this->session->logout();
                $this->session->start();
                $this->messageManager->addError($message);
                return $resultRedirect->setPath('customer/account/login');
            }
            catch (\Exception $e) {
				var_dump($e->getMessage());
				die("In catch");
				$this->messageManager->addException($e, __('We can\'t save the Contacts.'.$e->getMessage()));
            }

            //$this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
        }
		return $resultRedirect->setPath('carrental/pricerate/');
    }
	
}
