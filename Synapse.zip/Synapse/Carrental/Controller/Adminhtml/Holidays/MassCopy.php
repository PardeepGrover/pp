<?php
namespace Synapse\Carrental\Controller\Adminhtml\Holidays;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\ResourceModel\Holidays\CollectionFactory as HolidaysCollectionFactory;
use Synapse\Carrental\Model\HolidaysFactory as HolidaysFactory;

/**
 * Class MassDelete
 * @package Magenest\RentalAndBookingSystem\Controller\Adminhtml\Attribute
 */
class MassCopy extends \Magento\Backend\App\Action
{
    /**
     * @var holidaysCollectionFactory
     */
    protected $holidaysCollectionFactory;
	
	/**
     * @var holidaysCollectionFactory
     */
    protected $holidaysFactory;
    /**
     * @var Filter
     */
    protected $_filter;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        Action\Context $context,
        HolidaysCollectionFactory $holidaysCollectionFactory,
		HolidaysFactory $holidaysFactory,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->_filter = $filter;
        $this->holidaysCollectionFactory = $holidaysCollectionFactory;
		$this->holidaysFactory = $holidaysFactory;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->holidaysCollectionFactory->create());
		$requestdata = $this->getRequest()->getParams();
		$copy = 0;
		if(isset($requestdata['country']) && isset($requestdata['year'])){
			
			$countries = explode(',',$requestdata['country']);
			$years = explode(',',$requestdata['year']);
			foreach ($collection as $item) {
				foreach($countries as $_cntry){
					foreach($years as $_year){
						$model = $this->holidaysFactory->create();
						$prehdate = $item->getHolidayDate(); 
						$predate = date('d',strtotime($prehdate));
						$premonth = date('m',strtotime($prehdate));
						
						$timestampnewdate = strtotime($_year.'-'.$premonth.'-'.$predate);
						$newdate = date('Y-m-d',$timestampnewdate);
						
						$model->setHolidayDate($newdate);
						$model->setHolidayDay(date('D', $timestampnewdate));
						$model->setHolidayDatef(date('d M Y', $timestampnewdate));
						$model->setHolidayCountry($_cntry);
						$model->setHolidayName($item->getHolidayName());
						$model->save(); 
						$copy++;
					}
				}
					
			}
				
		}
			 
		 
		$this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been copied.', $copy));
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/holidays');
    }
}
