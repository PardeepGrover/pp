<?php
/**
 * Created by PhpStorm.
 */
namespace Synapse\Carrental\Controller\Adminhtml\Holidays;

use Magento\Backend\App\Action;
use Psr\Log\LoggerInterface;
use Magento\Framework\Exception\LocalizedException;
use Synapse\Carrental\Model\HolidaysFactory;

/**
 * Class Save
 * @package Magenest\RentalAndBookingSystem\Controller\Adminhtml\Location
 */
class Save extends Action
{
    /**
     * @var LoggerInterface
     */
    protected $_logger;

    /**
     * @var WarehouseholidayFactory
     */
    protected $holidayFactory;

    /**
     * Save constructor.
     * @param Action\Context $context
     * @param LoggerInterface $loggerInterface
     */
    public function __construct(
        Action\Context $context,
        LoggerInterface $loggerInterface,
        HolidaysFactory $Holidays
    ) {
        $this->holidayFactory = $Holidays;
        $this->_logger = $loggerInterface;
        parent::__construct($context);
    }
    /**
     * save action
     * @return $this
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute()
    {
	    
        $data = $this->getRequest()->getPostValue();
	/** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
		$model = $this->holidayFactory->create();
		if (isset($data['id']) && $data['id']!='') {
			$model->load($data['id']);
		}
		$allHolidays = $this->holidayFactory->create()->getCollection();
		$allHolidays->addFieldToFilter('holiday_name', $data['holiday_name']);
		$allHolidays->addFieldToFilter('holiday_date', date("Y-m-d", strtotime($data['holiday_date'])));
		$allHolidays->addFieldToFilter('holiday_country', $data['holiday_country']);
		 
                try {
			 
			$timestamp =  strtotime($data['holiday_date']);
			$holiday_day = date('D', $timestamp);
			$dayformat = date('d M Y', $timestamp);
			 
			$model->setHolidayCountry($data['holiday_country']);
			$model->setHolidayDate($data['holiday_date']);
			$model->setHolidayName($data['holiday_name']);
			$model->setHolidayDay($holiday_day);
			$model->setHolidayDatef($dayformat);
			$model->save();
			$this->messageManager->addSuccessMessage(__('Holiday has been saved.'));
			if ($this->getRequest()->getParam('back')) {
				return $resultRedirect->setPath('carrental/holidays/');
			}
			return $resultRedirect->setPath('carrental/holidays/');
                } catch (LocalizedException $e) {
                    $this->messageManager->addErrorMessage($e->getMessage());
                } catch (\Exception $e) {
                    $this->messageManager->addErrorMessage($e, __('Something went wrong while saving the Holidays.'));
                    
                     
                }
             

        }
        return $resultRedirect->setPath('carrental/holidays/');
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }
}
