<?php
namespace Synapse\Carrental\Controller\Adminhtml\Holidays;
use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\ResourceModel\Holidays\CollectionFactory as HolidaysCollectionFactory;

/**
 * Class MassDelete
 * @package Magenest\RentalAndBookingSystem\Controller\Adminhtml\Attribute
 */
class MassDelete extends \Magento\Backend\App\Action
{
    /**
     * @var VehicleTypeCollectionFactory
     */
    protected $holidaysCollectionFactory;

    /**
     * @var Filter
     */
    protected $_filter;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        Action\Context $context,
        HolidaysCollectionFactory $holidaysCollectionFactory,
        Filter $filter
    ) {
        parent::__construct($context);
        $this->_filter = $filter;
        $this->holidaysCollectionFactory = $holidaysCollectionFactory;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
         $collection = $this->_filter->getCollection($this->holidaysCollectionFactory->create());
	     $delete = 0;
        foreach ($collection as $item) {
           $item->delete();
		   $delete++;
            
        }
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $delete));
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/holidays');
    }
}
