<?php 
namespace Synapse\Carrental\Controller\Adminhtml\City;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\Model\Session;
class Index extends Action{
	
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	 /**
     * @var \Magento\Backend\Model\Session
     */
	protected $session;
	public function __construct(
		Action\Context  $context,
        PageFactory  $resultPageFactory,
		Session $session
	){
		$this->resultPageFactory = $resultPageFactory;
		$this->session = $session;
		parent::__construct($context);
		
	}
	/**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
		return $this->resultPageFactory->create();
    }	
	
}