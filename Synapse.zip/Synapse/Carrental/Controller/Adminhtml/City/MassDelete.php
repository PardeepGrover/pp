<?php

namespace Synapse\Carrental\Controller\Adminhtml\City;

use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\CityFactory;
use Synapse\Carrental\Model\ResourceModel\City\CollectionFactory;
#use Magento\Customer\Model\Session;

class MassDelete extends \Magento\Framework\App\Action\Action
{
 
    protected $cityFactory;
	protected $cityCollectionFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $resultFactory;
	
	protected $_customerSession;

    /**
     * MassFleetStatus constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CollectionFactory $collectionFactory,
		CityFactory $CityFactory,
		Filter $filter
    ) {
		parent::__construct($context);

        $this->_filter = $filter;
		$this->cityFactory = $CityFactory;
		$this->cityCollectionFactory = $collectionFactory;
	}

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
		$data = $this->getRequest()->getParams();
		 $collection = $this->_filter->getCollection($this->cityCollectionFactory->create());
		$isdeleted = 0;
        foreach ($collection as $item) {
			$item->delete();
			unset($cityModel);
			$isdeleted++;
		}
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $isdeleted));
       
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/city');
    }
}

