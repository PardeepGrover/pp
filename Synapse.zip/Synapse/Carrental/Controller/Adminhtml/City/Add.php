<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 21/12/2016
 * Time: 10:58
 */
namespace Synapse\Carrental\Controller\Adminhtml\City;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Synapse\Carrental\Model\CityFactory;
/**
 * Class Index
 * @package 
 */
class Add extends Action
{
    
	 /**
     * @var cityFactory
     */
    protected $cityFactory;
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context  $context,
        PageFactory  $resultPageFactory,
		CityFactory  $CityFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->cityFactory       = $CityFactory;
		parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
		$resultPage = $this->resultPageFactory->create();
		if($this->getRequest()->getParam('id')){
			$model = $this->cityFactory->create();
		    $model->load($this->getRequest()->getParam('id'));
			$data = [];
			$data['country_id'] =  $model->getCountryId();
			$data['city_name'] =  $model->getCityName();
			$this->_getSession()->setFormData($data);
		}
		$title = $this->getRequest()->getParam('id')? __('Edit City'): __('Add City');
		$resultPage->getConfig()->getTitle()->set($title);
		return $resultPage; 
    }
	/**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_pageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::city');
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Synapse_Carrental::city');
    }
}
