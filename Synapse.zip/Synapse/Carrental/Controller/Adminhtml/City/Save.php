<?php
/**
* Copyright 2018. All rights reserved.
* See LICENSE.txt for license details.
*/namespace Synapse\Carrental\Controller\Adminhtml\City;use Magento\Framework\Api\DataObjectHelper;use Magento\Framework\App\Action\Context;use Magento\Framework\App\Request\DataPersistorInterface;use Magento\Framework\View\Result\PageFactory;use Magento\Framework\Exception\LocalizedException;use Magento\Framework\App\Action\Action;use Synapse\Carrental\Model\CityFactory;use Magento\Backend\Model\Session;
class Save extends Action{	private $resultPageFactory;    private $dataObjectHelper;    private $requestManagement;	private $requestPostDataProcessor;	private $requestFactory;	private $dataPersistor;	private $cityfactory;	protected $session;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param RequestManagementInterface $requestManagement
     */
    public function __construct(		Context $context,		PageFactory $resultPageFactory,		DataObjectHelper $dataObjectHelper,		DataPersistorInterface $dataPersistor,		CityFactory $CityFactory,		Session $session	) {
        parent::__construct($context);		$this->resultPageFactory = $resultPageFactory;		$this->dataObjectHelper = $dataObjectHelper;		$this->dataPersistor = $dataPersistor;		$this->cityfactory = $CityFactory;		$this->session = $session;	}	/**
     * {@inheritdoc}
     */
    public function execute()	{
        $resultRedirect = $this->resultRedirectFactory->create();		$data = $this->getRequest()->getPostValue();		///echo "<pre>";		//var_dump($data);		//die;		//$id = $this->getRequest()->getParam('city_id');				if ($data){			 
			$model = $this->cityfactory->create();			try {				$collection = $model->getCollection();				$collection->addFieldToFilter('country_id',$data['country_id']);				$collection->addFieldToFilter('city_name',$data['city_name']);				$collection->addFieldToSelect('id');				 				if($collection->getSize()){					$model->load($collection->getFirstItem()->getId());				}				$model->setData($data);				$model->save();				 				$this->messageManager->addSuccess(__('You saved successfully.'));				$this->session->setFormData(false);				if ($this->getRequest()->getParam('back')) {					return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);				}				return $resultRedirect->setPath('*/*/');			}catch (\Magento\Framework\Exception\LocalizedException $e) {					$this->messageManager->addError($e->getMessage());			} catch (\RuntimeException $e) {				$this->messageManager->addError($e->getMessage());			} catch (\Exception $e) {					$this->messageManager->addException($e, __('Something went wrong while saving the label.'));			}			$this->session->setFormData($data);
			return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
		}
		return $resultRedirect->setPath('*/*/index');
	}
}
