<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 21/12/2016
 * Time: 10:58
 */
namespace Synapse\Carrental\Controller\Adminhtml\City;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Synapse\Carrental\Model\CityFactory;
/**
 * Class Index
 * @package 
 */
class Edit extends Action
{
      /**
     * @var holidayFactory
     */
    protected $cityFactory;
    
     /**
     * @var holidayFactory
     */
    protected $cityCollection;
    
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context  $context,
        PageFactory  $resultPageFactory,
		CityFactory $CityFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->cityFactory = $CityFactory;
		$this->cityCollection = $this->cityFactory->create()->getCollection();
	parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
		$resultPage = $this->resultPageFactory->create();
		$resultPage->getConfig()->getTitle()->set(__('Edit City'));
		$this->_forward('add');
		return $resultPage; 
    }
	/**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_pageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::city');
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Synapse_Carrental::city');
    }
}
