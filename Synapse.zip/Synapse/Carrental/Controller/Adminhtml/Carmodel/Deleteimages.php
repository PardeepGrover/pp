<?php
/**
* Copyright 2018. All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Controller\Adminhtml\Carmodel;

use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Action\Action;
use Synapse\Carrental\Model\CarModelFactory ;
use Synapse\Carrental\Model\CarModelAttrFactory ;
use Synapse\Carrental\Model\CarModelImagesFactory ;
use Magento\Framework\Controller\Result\JsonFactory ;
/**
 * Class Deleteimages
 *
 * @package Synapse\Carrental\Controller\Adminhtml\Carmodel
 */
class Deleteimages extends Action
{
    /**
     * @var PageFactory
     */
    private $resultPageFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var RequestManagementInterface
     */
    private $requestManagement;

    /**
     * @var 
     */
    private $requestPostDataProcessor;

    /**
     * @var 
     */
    private $requestFactory;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	
	
	private $carmodelfactory;
	private $carmodelattrfactory;
	private $carmodelimagesFactory;
	private $jsonfactory;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param RequestManagementInterface $requestManagement
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        DataObjectHelper $dataObjectHelper,
        DataPersistorInterface $dataPersistor,
		CarModelFactory $CarModelFactory,
		CarModelAttrFactory $CarModelAttrFactory,
		CarModelImagesFactory $CarModelImagesFactory,
		JsonFactory $resultJsonFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPersistor = $dataPersistor;
		$this->carmodelfactory = $CarModelFactory;
		$this->carmodelattrfactory = $CarModelAttrFactory;
		$this->carmodelimagesFactory =  $CarModelImagesFactory;
		$this->resultJsonFactory = $resultJsonFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        //$resultRedirect = $this->resultRedirectFactory->create();	
		$result = $this->resultJsonFactory->create();
        if ($data = $this->getRequest()->getParams()) {
            try {
					if(count($data)>0){
						$carmodelimagesFactory = $this->carmodelimagesFactory->create();
						$carmodelimagesCollection = $carmodelimagesFactory->getCollection();
						$carmodelimagesCollection->addFieldToFilter('id',array('in'=>implode(',',$data['arr'])));
						$carmodelimagesCollection->walk('delete');
						 
						$result->setData(['success' => true]);
					}else{
						$result->setData(['error' => true]);
					}
				
					return $result;
				
				} catch (LocalizedException $e) {
						$this->messageManager->addErrorMessage($e->getMessage());
				} catch (\RuntimeException $e) {
						$this->messageManager->addErrorMessage($e->getMessage());
				} catch (\Exception $e) {
					$this->messageManager->addExceptionMessage($e, __('Something went wrong while updating the return.'));
				}
            
			}
           //return $resultRedirect->setPath('*/*/');
    }

    /**
     * Perform save
     *
     * @param array $data
     * @return RmaRequestInterface
     */
    private function performSave($data)
    {
        $requestObject = $this->requestFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $requestObject,
            $data,
            RmaRequestInterface::class
        );

        return $this->requestManagement->updateRequest($requestObject, true);
    }
}
