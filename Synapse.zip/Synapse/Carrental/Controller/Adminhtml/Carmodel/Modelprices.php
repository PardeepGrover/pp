<?php
/**
 * Created by PhpStorm.
 */
namespace Synapse\Carrental\Controller\Adminhtml\Carmodel;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Reports\Model\Flag;

use Magento\Framework\Stdlib\DateTime\TimezoneInterface;

/**
 * Class Modelprices
 * @package Magenest\RentalAndBookingSystem\Controller\Rental
 */
class Modelprices extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	 /**
     * @var \Magento\Backend\Model\Session
     */
	protected $session;
	
	/**
     * @var \Magento\Framework\App\Response\Http\FileFactory
     */
    protected $_fileFactory;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\Filter\Date
     */
    protected $_dateFilter;
	
	protected $timezone;
		
	
	/**
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\App\Response\Http\FileFactory $fileFactory
     * @param \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter
     * @param TimezoneInterface $timezone
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\App\Response\Http\FileFactory $fileFactory,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Stdlib\DateTime\Filter\Date $dateFilter,
        TimezoneInterface $timezone
    ) {
        parent::__construct($context);
        $this->_fileFactory = $fileFactory;
		$this->resultPageFactory = $resultPageFactory;
        $this->_dateFilter = $dateFilter;
        $this->timezone = $timezone;
    }
	

   /**
     * Add report/sales breadcrumbs
     *
     * @return $this
     */
    public function _initAction()
    {
       $resultPage = $this->resultPageFactory->create();
       return $resultPage;
    }
	
	/**
     * Invoice report action
     *
     * @return void
     */
    public function execute()
    {
		$resultPage = $this->resultPageFactory->create();
		$resultPage->getConfig()->getTitle()->prepend(__('Car Model Prices'));
		$gridBlock = $resultPage->getLayout()->getBlock('adminhtml_sales_invoiced.grid');

		$filterFormBlock = $resultPage->getLayout()->getBlock('grid.filter.form');

		$this->_initReportAction([$gridBlock, $filterFormBlock]);
	  
		$resultPage->addHandle('carrental_carmodel_modelprices');
		return $resultPage;

		//$this->_view->renderLayout();
    }
	
	 /**
     * Report action init operations
     *
     * @param array|\Magento\Framework\DataObject $blocks
     * @return $this
     */
    public function _initReportAction($blocks)
    {

        if (!is_array($blocks)) {
            $blocks = [$blocks];
        }

        $requestData = $this->_objectManager->get(
            \Magento\Backend\Helper\Data::class
        )->prepareFilterString(
            $this->getRequest()->getParam('filter')
        );
        $inputFilter = new \Zend_Filter_Input(
            ['from' => $this->_dateFilter, 'to' => $this->_dateFilter],
            [],
            $requestData
        );
        $requestData = $inputFilter->getUnescaped();
        $requestData['store_ids'] = $this->getRequest()->getParam('store_ids');
        $params = new \Magento\Framework\DataObject();

        foreach ($requestData as $key => $value) {
            if (!empty($value)) {
                $params->setData($key, $value);
            }
        }

        foreach ($blocks as $block) {
            if ($block) {
                $block->setPeriodType($params->getData('period_type'));
                $block->setFilterData($params);
            }
        }

        return $this;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Synapse_Carrental::carmodel');
    }
}
