<?php
/**
* Copyright 2018. All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Controller\Adminhtml\TermsConditions;

use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Action\Action;
use Synapse\Carrental\Model\CaptionsFactory;
use Magento\Backend\Model\Session;

/**
 * Class Save
 *
 * @package Synapse\Carrental\Controller\Adminhtml\Carmodel
 */
class Savecaption extends Action
{
    /**
     * @var PageFactory
     */
    private $resultPageFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var RequestManagementInterface
     */
    private $requestManagement;

    /**
     * @var 
     */
    private $requestPostDataProcessor;

    /**
     * @var 
     */
    private $requestFactory;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	
	
	private $captionfactory;
	protected $session;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param RequestManagementInterface $requestManagement
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        DataObjectHelper $dataObjectHelper,
        DataPersistorInterface $dataPersistor,
		CaptionsFactory $CaptionsFactory,
		Session $session
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPersistor = $dataPersistor;
		$this->captionfactory = $CaptionsFactory;
		$this->session = $session;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
		$data = $this->getRequest()->getPostValue();
		if ($data) {
			// echo "<pre>";
			//print_r($data); die; 
			/** @var \Webspeaks\ProductsGrid\Model\Contact $model */
			$model = $this->captionfactory->create();
			$data['identifier'] = 'identity';
			$data['status'] = 1;
			$id = $this->getRequest()->getParam('id');
			
			if ($id) {
				$model->load($id);
			}
			
			$model->setTitle($data['title']);
			$model->setIdentifier('identity');
			$model->setStatus($data['status']);
			try {
				$model->save();
				$this->messageManager->addSuccess(__('You saved this Caption.'));
				$this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
				if ($this->getRequest()->getParam('back')) {
					return $resultRedirect->setPath('*/*/editcaption', ['id' => $model->getId(), '_current' => true]);
				}
				return $resultRedirect->setPath('*/*/');
				
			} catch (\Magento\Framework\Exception\LocalizedException $e) {
				$this->messageManager->addError($e->getMessage());
			} catch (\RuntimeException $e) {
				$this->messageManager->addError($e->getMessage());
			} catch (\Exception $e) {
				$this->messageManager->addException($e, __('Something went wrong while saving the label.'));
			}

			$this->_getSession()->setFormData($data);
			return $resultRedirect->setPath('*/*/editcaption', ['id' => $this->getRequest()->getParam('id')]);
		}
		return $resultRedirect->setPath('*/*/');
	}
}
