<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 21/12/2016
 * Time: 10:58
 */
namespace Synapse\Carrental\Controller\Adminhtml\Location;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Synapse\Carrental\Model\LocationFactory;
/**
 * Class Index
 * @package 
 */
class Add extends Action
{
    
	 /**
     * @var cityFactory
     */
    protected $locationFactory;
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context  $context,
        PageFactory  $resultPageFactory,
		LocationFactory  $LocationFactory
    ) {
        $this->resultPageFactory	 = $resultPageFactory;
		$this->locationFactory       = $LocationFactory;
		parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
		$resultPage = $this->resultPageFactory->create();
		if($this->getRequest()->getParam('id')){
			$model = $this->locationFactory->create();
		    $model->load($this->getRequest()->getParam('id'));
			$data = [];
			$data['country_id'] =  $model->getCountryId();
			$data['city_name'] =  $model->getCityName();
			$this->_getSession()->setFormData($data);
		}
		$title = $this->getRequest()->getParam('id')? __('Edit Location'): __('Add Location');
		$resultPage->getConfig()->getTitle()->set($title);
		return $resultPage; 
    }
	/**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_pageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::location');
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Synapse_Carrental::location');
    }
}
