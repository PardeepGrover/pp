<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 21/12/2016
 * Time: 10:58
 */
namespace Synapse\Carrental\Controller\Adminhtml\Fuelpolicy;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
/**
 * Class Index
 * @package Magenest\RentalAndBookingSystem\Controller\Rental
 */
class Index extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	/**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context  $context,
        PageFactory  $resultPageFactory,
		DataPersistorInterface $dataPersistor
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->dataPersistor = $dataPersistor;
		parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
		$id = $this->getRequest()->getParam('id');
		if($this->getRequest()->getParam('id',NULL)){
			$this->dataPersistor->set('admin_supplier_fuel',$id);
		}else{
			$this->dataPersistor->set('admin_supplier_fuel',NULL);
		}
		return $this->resultPageFactory->create();
    }
	/**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_pageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::fuel');
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
		return true;
    }
}
