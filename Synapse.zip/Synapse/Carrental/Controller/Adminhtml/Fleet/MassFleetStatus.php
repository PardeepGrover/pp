<?php

namespace Synapse\Carrental\Controller\Adminhtml\Fleet;

use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Model\ResourceModel\Fleet\CollectionFactory;
use Magento\Customer\Model\Session;

class MassFleetStatus extends \Magento\Framework\App\Action\Action
{
 
    protected $fleetModelFactory;
	protected $fleetCollectionFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $resultFactory;
	
	protected $_customerSession;

    /**
     * MassFleetStatus constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CollectionFactory $collectionFactory,
		FleetFactory $fleetFactory,
		Session $customerSession,
        Filter $filter
    ) {
		parent::__construct($context);

        $this->_filter = $filter;
		$this->fleetModelFactory = $fleetFactory;
		$this->fleetCollectionFactory = $collectionFactory;
		$this->_customerSession   = $customerSession ;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->fleetCollectionFactory->create());
		$status = (int) $this->getRequest()->getParam('status');	
        $delete = 0;
        foreach ($collection as $item) {
				$fleetModel = $this->fleetModelFactory->create();
				$fleetModel->load($item->getId())
				->setId($item->getId())
				->setStatus($status)
				->save();
				unset($fleetModel);
				$delete++;
			}
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been updated.', $delete));
       
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/fleet');
    }
}

