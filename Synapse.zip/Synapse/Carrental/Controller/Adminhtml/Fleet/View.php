<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 21/12/2016
 * Time: 10:58
 */
namespace Synapse\Carrental\Controller\Adminhtml\Fleet;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
#use Synapse\Carrental\Helper\Data as carrentalhelper;
/**
 * Class View
 * @package Magenest\RentalAndBookingSystem\Controller\Rental
 */
class View extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

	private $dataPersistor;
    
    /**
     *
     * @var type object 
     */
    protected $_carrentalhelper;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context  $context,
        PageFactory  $resultPageFactory,
        \Synapse\Carrental\Helper\Data $carrentalhelper,
		 DataPersistorInterface $dataPersistor
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_carrentalhelper  = $carrentalhelper;
		$this->dataPersistor = $dataPersistor;
	parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
		$this->dataPersistor->set('view_id',$this->getRequest()->getParam('id'));
        $resultPage->getConfig()->getTitle()->set(__('Fleet Models'));
        return $resultPage;
    }
	/**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_pageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::supplier');
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
		return true;
       // return $this->_authorization->isAllowed('Synapse_Carrental::supplier');
    }
}
