<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Home;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Search\Model\AutocompleteInterface;
use Magento\Framework\Controller\ResultFactory;
use Synapse\Carrental\Model\WarehouseinfoFactory;
use Synapse\Carrental\Model\WarehousetimingsFactory;
use Synapse\Carrental\Model\VehiclepricelistseasonsFactory;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
use Synapse\Carrental\Model\ServiceLocationFactory;
use Synapse\Carrental\Block\Home;
use Magento\Framework\Registry;

class Search extends Action
{
    protected $resultPageFactory;
	private $warehouseinfoFactory;
	private $warehousetimingsFactory;
	private $vehiclepricelistseasonsFactory;
	private $vehicleseasonalpriceFactory;
	private $home;
	private $_registry;
	private $_servicelocationFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Search\Model\AutocompleteInterface $autocomplete
     */
    public function __construct(
        Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		WarehousetimingsFactory $WarehousetimingsFactory,
		WarehouseinfoFactory $WarehouseinfoFactory,
		VehiclepricelistseasonsFactory $VehiclepricelistseasonsFactory,
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
		Registry $Registry,
		Home $Home,
		ServiceLocationFactory $ServiceLocationFactory
	) {
		$this->resultPageFactory  = $resultPageFactory;
        $this->warehousetimingsFactory = $WarehousetimingsFactory;
        $this->warehouseinfoFactory    = $WarehouseinfoFactory;
        $this->vehiclepricelistseasonsFactory = $VehiclepricelistseasonsFactory;
        $this->vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
		$this->_registry = $Registry; 
		$this->home = $Home;
		$this->_servicelocationFactory = $ServiceLocationFactory;
		parent::__construct($context);
		
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
		$data = $this->getRequest()->getParams();
		$pickup_date = date('Y-m-d',strtotime($data['pickup_date']));
		$pickup_time = $data['pickup_time'];
		$dropoff_date = date('Y-m-d',strtotime($data['dropoff_date']));
		$dropff_time = $data['dropoff_time'];
		//var_dump($pickup_date);
		//var_dump($dropoff_date);
		 
		if($data){
			/* service location
				||
				Timing ranges (checked the pickup and dropoff dates open)
				||
				Price List (got warehouses from the timings and after it get price list using WH)
				||
				got seasons from the price list 
				|| 
				Got rates and models of that seasons.
			
			*/
			
			$serviceModel 	   = $this->_servicelocationFactory->create();
			$serviceCollection = $serviceModel->getCollection();
			$serviceCollection->addFieldToSelect('location_type');
			$serviceCollection->addFieldToSelect('supplier_id');
			$serviceCollection->addFieldToSelect('warehouse_id');
		    $serviceCollection->addFieldToFilter('pickup_location_id',
				[
					['finset'=> $data['pickup_location']
					
					]
				]
			);
			$serviceCollection->addFieldToFilter('dropoff_location_id',
				[
					['finset'=> $data['dropoff_location']
					
					]
				]
			);
			$serviceCollection->getSelect()->joinLeft(
				['timings'=>$serviceCollection->getTable('wais_warehouse_timings_range')],
				'main_table.warehouse_id=timings.warehouse_id',
				[
				'timings.working_date'
				]
		
			);
			$serviceCollection->getSelect()->joinLeft(
				['timingsd'=>$serviceCollection->getTable('wais_warehouse_timings_range')],
				'main_table.warehouse_id=timingsd.warehouse_id',
				[
				'timingsd.working_date as dworking_date','timingsd.dropoff_start_time as ddropoff_start_time','timingsd.dropoff_end_time as ddropoff_end_time'
				]
	
			);
			$serviceCollection->getSelect()->where(
				"timings.working_date = '".$pickup_date."' and timingsd.working_date = '".$dropoff_date."' "
			);
			$serviceCollection->getSelect()->where(
				"timings.pickup_start_time <= '".$pickup_time."' and timings.pickup_end_time >= '".$pickup_time."' "
			);
			$serviceCollection->getSelect()->where(
				"timingsd.dropoff_start_time <= '".$dropff_time."' and timingsd.dropoff_end_time >= '".$dropff_time."' "
			);
			$serviceCollection->getSelect()->joinLeft(
				['pl'=>$serviceCollection->getTable('wais_vehicle_price_list')],
				'main_table.warehouse_id=pl.warehouse_id',
				[
				'pl.id as pricelist_id','pl.rate_code','pl.pickup_fromdate','pl.pickup_todate'
				]
	
			);
			$serviceCollection->getSelect()->joinLeft(
				['seasons'=>$serviceCollection->getTable('wais_pricelist_seasons')],
				'pl.id =seasons.pricelist_id',
				[
					'seasons.id as season_id','seasons.season_from_date','seasons.season_to_date'
				]
	
			);
			$serviceCollection->getSelect()->joinLeft(
				['seasoncars'=>$serviceCollection->getTable('wais_supplier_season_pricelist')],
				'seasons.id =seasoncars.season_id',
				[
					'seasoncars.template_id','seasoncars.sub_template_id','seasoncars.car_model_id','seasoncars.price','seasoncars.product_id'
				]
	
			);
			
			$serviceCollection->getSelect()->where('
				("'.$pickup_date.'" BETWEEN pl.pickup_fromdate AND pickup_todate) 
				 or 
				 ("'.$dropoff_date.'" BETWEEN pl.pickup_fromdate AND pickup_todate)
				 OR 
				 (pl.pickup_fromdate <= "'.$pickup_date.'" AND pickup_todate >= "'.$dropoff_date.'")
				 OR 
				 (pl.pickup_fromdate >= "'.$pickup_date.'" AND pickup_todate <= "'.$dropoff_date.'")
			 ');
						 
			 $serviceCollection->getSelect()->where('
				("'.$pickup_date.'" BETWEEN seasons.season_from_date AND seasons.season_to_date) 
				 or 
				 ("'.$dropoff_date.'" BETWEEN seasons.season_from_date AND seasons.season_to_date)
				 OR 
				 (seasons.season_from_date <= "'.$pickup_date.'" AND seasons.season_to_date >= "'.$dropoff_date.'")
				 OR 
				 (seasons.season_from_date >= "'.$pickup_date.'" AND seasons.season_to_date <= "'.$dropoff_date.'")
			 ');
			 
			$totalsearchRecordData = $serviceCollection;
			
			$productIds = array_unique($serviceCollection->getColumnValues('product_id'));
			$this->_registry->unregister('totalrecords');
			$this->_registry->register('totalrecords',$totalsearchRecordData);
			
			$this->_registry->unregister('product_ids');
			$this->_registry->register('product_ids',$productIds);
			 
		}
		$resultPage = $this->resultPageFactory->create();
		$resultPage->addHandle('carrental_home_search');
		return $resultPage;
               
	  
    }

}
