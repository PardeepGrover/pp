<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Carmodelprices;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class InlineUpdate extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleseasonalpriceFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		JsonFactory $resultJsonFactory,
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		$resultJson = $this->resultJsonFactory->create();
		$error = false;
        $messages = [];
		$postItems = $this->getRequest()->getParam('items', []);
		if (!count($postItems)) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }
		try {
			 
			if(count($postItems)>0){
					$supplierId = $this->session->getcustomer()->getId();
					foreach($postItems as $_val):
					$vehicleseasonalpriceModelFactory = $this->vehicleseasonalpriceFactory->create();
					$vehicleseasonalpriceModelFactory->setId($_val['id']);
					$vehicleseasonalpriceModelFactory->setPrice($_val['price']);
					$vehicleseasonalpriceModelFactory->save();
					endforeach;
				$message = __(
					'updated Record SuccessFully'
				);
				//$this->messageManager->addSuccess($message);
					
			}
		}catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			$error = true;
			
		}
		catch (\Exception $e) {
			  $error = true;
			$message = __(
					'Something went wrong'
				);
		}
		return $resultJson->setData([
            'messages' => $message,
            'error' => $error
        ]);
    }
	
}
