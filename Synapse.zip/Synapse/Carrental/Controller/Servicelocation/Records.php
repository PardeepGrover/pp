<?php 
namespace Synapse\Carrental\Controller\Servicelocation;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Synapse\Carrental\Model\ServiceLocationFactory;
use Synapse\Carrental\Model\LocationFactory;
class Records extends \Magento\Framework\App\Action\Action { 
	
	/**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	protected $resultPageFactory;
	protected $_customerSession;
	protected $_servicelocationFactory;
	protected $_locationFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		DataPersistorInterface $dataPersistor,
		ServiceLocationFactory $ServiceLocationFactory,
		LocationFactory $LocationFactory
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
			$this->dataPersistor = $dataPersistor;
			$this->_servicelocationFactory = $ServiceLocationFactory;
			$this->_locationFactory   = $LocationFactory;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$locationModel = $this->_locationFactory->create();
		$locationCollection = $locationModel->getCollection();
		 
		$responseData = $locationCollection->getData();
		 
		$resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($responseData);
		return $resultJson;
	} 
  
} 


 
