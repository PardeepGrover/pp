<?php 
namespace Synapse\Carrental\Controller\Warehouse;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\UrlInterface ;
use Synapse\Carrental\Helper\Data as Carrentalhelper;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Synapse\Carrental\Model\ServiceLocationFactory;
class Save extends \Magento\Framework\App\Action\Action { 
	
	private $_helper;
    private $_urlInterface;
    private $_servicelocationFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
        FormKeyValidator $formKeyValidator,
        Carrentalhelper $carrentalhelper ,
        UrlInterface $UrlInterface,
		ServiceLocationFactory $ServiceLocationFactory
    )
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
            $this->resultRedirectFactory = $context->getResultRedirectFactory();
            $this->_formKeyValidator = $formKeyValidator;
            $this->_helper =           $carrentalhelper;
            $this->_urlInterface    =  $UrlInterface;
			$this->_servicelocationFactory = $ServiceLocationFactory;
			return parent::__construct($context);
        }
	/**
     * Process  form save
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
       $resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
        $redirectUrl = null;
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
        if (!$this->getRequest()->isPost()) {
           $this->_getSession()->setWarehouseFormData($this->getRequest()->getPostValue());
            return $this->resultRedirectFactory->create()->setUrl(
                $this->_redirect->error($this->_buildUrl('*/*/add'))
            );
        }
        try {
			$warehouseinfo = $this->getRequest()->getParam('info');
			
			/*$data = [];
			$data['warehouse_name'] = $warehouseinfo['warehouse_name'];
			$data['id'] 	= isset($warehouseinfo['id'])?$warehouseinfo['id']:NULL;
			$data['customer_min_age'] = $warehouseinfo['customer_min_age'];
			$data['customer_max_age'] = $warehouseinfo['customer_max_age'];
			$data['address'] 		  = $warehouseinfo['address'];
			$data['city']			  = $warehouseinfo['city'];
			$data['location'] 		  = $warehouseinfo['location'];
			$data['postcode'] 		  = $warehouseinfo['postcode'];
			$data['supplier_billing_profile'] = $warehouseinfo['supplier_billing_profile'];
			$data['desk_availability'] = $warehouseinfo['desk_availability'];
			$data['grace_period'] 	   = $warehouseinfo['grace_period'];
			$data['advanced_reservation'] = $warehouseinfo['advanced_reservation'];*/
		
            $country_id = $this->getRequest()->getParam('country_id');
            $customer = $this->_customerSession;
            $supplier_id = $customer->getCustomer()->getId();
			
           /* saving the Warehouse Information */ 
 		    $warehouseinfoModelFactory = $this->_helper->WarehouseinfoFactory();
            $warehouseinfoModelFactory->setData($warehouseinfo);
            $warehouseinfoModelFactory->setSupplierId($supplier_id);
            $warehouseinfoModelFactory->setCountryId($country_id);
			$warehouseinfoModelFactory->setSupplierContactProfile(implode(',',$warehouseinfo['supplier_contact_profile']));
			$warehouseinfoModelFactory->setSupportedCurrency(implode(',',$warehouseinfo['supported_currency']));
			$warehouseinfoModelFactory->setAssignedFleets(implode(',',$warehouseinfo['assigned_fleets']));
			 
			$warehouseinfodata = $warehouseinfoModelFactory->save();
			unset($warehouseinfoModelFactory);
			/* saving the Warehouse Information */ 
			
			/* saving the Service Location Information */ 
			if(isset($warehouseinfo['service_location'])){
				$serviceLocationModel = $this->_servicelocationFactory->create();
				$slCollection = $serviceLocationModel->getCollection();
				$slCollection->addFieldToFilter('supplier_id',$supplier_id);
				$slCollection->addFieldToFilter('warehouse_id',$warehouseinfodata->getId());
				$pId = $slCollection->getFirstItem()->getId();
				if($pId){
					$serviceLocationModel->load($pId);
				}
				$serviceLocationModel->setPickupLocationId(implode(',',$warehouseinfo['service_location']));
				$serviceLocationModel->setWarehouseId($warehouseinfodata->getId());
				$serviceLocationModel->setSupplierId($warehouseinfodata->getSupplierId());
				$serviceLocationModel->save();
				
				unset($slCollection);
				 
			}
			/* saving the Service Location Information */ 
			
			/* saving the Dropoff service  Location */ 
			if(isset($warehouseinfo['dservice_location'])){
				$serviceLocationModel = $this->_servicelocationFactory->create();
				$dslCollection = $serviceLocationModel->getCollection();
				$dslCollection->addFieldToFilter('supplier_id',$supplier_id);
				$dslCollection->addFieldToFilter('warehouse_id',$warehouseinfodata->getId());
				$dpId = $dslCollection->getFirstItem()->getId();
				if($dpId){
					$serviceLocationModel->load($dpId);
				}
				$serviceLocationModel->setDropoffLocationId(implode(',',$warehouseinfo['dservice_location']));
				$serviceLocationModel->setWarehouseId($warehouseinfodata->getId());
				$serviceLocationModel->setSupplierId($warehouseinfodata->getSupplierId());
				$serviceLocationModel->save();
				
				unset($dslCollection);
				 
			}
			/* saving the Dropoff service  Location */ 
			
            $this->messageManager->addSuccess(__('Record Successfully saved!.'));
            $url = $this->_urlInterface->getUrl('*/*/edit',['id'=>$warehouseinfodata->getId()]);
            return $this->resultRedirectFactory->create()->setUrl($this->_redirect->success($url));
        } catch (InputException $e) {
            $this->messageManager->addError($e->getMessage());
            foreach ($e->getErrors() as $error) {
                $this->messageManager->addError($error->getMessage());
            }
        } catch (\Exception $e) {
			var_dump($e->getMessage());
			die;
			$redirectUrl = $this->_urlInterface->getUrl('*/*/index');
            $this->messageManager->addException($e, __('We can\'t save the data.'));
        }

        $url = $redirectUrl;
        if (!$redirectUrl) {
            $this->_getSession()->setWarehouseFormData($this->getRequest()->getPostValue());
            $url = $this->_urlInterface->getUrl('*/*/index', ['id' => $this->getRequest()->getParam('id')]);
       }

        return $this->resultRedirectFactory->create()->setUrl($this->_redirect->error($url));
    }
    /**
     * @param string $route
     * @param array $params
     * @return string
     */
    protected function _buildUrl($route = '', $params = [])
    {
        /** @var \Magento\Framework\UrlInterface $urlBuilder */
       // $urlBuilder = $this->_objectManager->create(\Magento\Framework\UrlInterface::class);
       // return $urlBuilder->getUrl($route, $params);
    }
  
} 


 
