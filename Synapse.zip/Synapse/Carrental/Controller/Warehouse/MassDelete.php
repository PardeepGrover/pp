<?php

namespace Synapse\Carrental\Controller\Warehouse;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\ResourceModel\Warehouseinfo\CollectionFactory;
use Synapse\Carrental\Model\WarehouseinfoFactory;
use Magento\Customer\Model\Session;
class MassDelete extends \Magento\Framework\App\Action\Action
{
 
    protected $warehouseFactory;
	
	protected $warehouseCollectionFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $resultFactory;
	
	protected $_customerSession;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        WarehouseinfoFactory $WarehouseinfoFactory,
		CollectionFactory $collectionFactory,
		Session $customerSession,		
        Filter $filter
    ) {
		parent::__construct($context);

        $this->_filter = $filter;
        $this->warehouseFactory = $WarehouseinfoFactory;
		$this->warehouseCollectionFactory = $collectionFactory;
		$this->_customerSession   = $customerSession;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->warehouseCollectionFactory->create());
		
		$supplier_id = $this->_customerSession->getCustomer()->getId();
		
        $delete = 0;
        foreach ($collection as $item) {
			$warehouseModel = $this->warehouseFactory->create();
			$warehouseModel->load($item->getId())
			->setId($item->getId())
			->setIsDeleted(1)
			->save();
			unset($warehouseModel);
			//$item->delete();
            $delete++;
        }
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $delete));
		
		/* Dispatch envent */
		$this->_eventManager->dispatch(
			'mass_event_warehouse_delete', ['supplier_id' => $supplier_id, 'action' => 'delete' ,'items'=>$collection]
		);
       
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/warehouse');
    }
}
