<?php 
namespace Synapse\Carrental\Controller\Vdirectory;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
class Index extends \Magento\Framework\App\Action\Action { 
	
	protected $resultPageFactory;
	protected $_customerSession;
	private $_cookieManager;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		\Magento\Framework\Stdlib\CookieManagerInterface $cookieManager
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
			$this->_cookieManager = $cookieManager;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$this->_deleteMessage();
		$resultPage = $this->resultPageFactory->create();
		$resultPage->addHandle('carrental_vdirectory_index');
		 return $resultPage;
               
	}
	private function _deleteMessage() {        
		$this->_cookieManager->deleteCookie('mage-messages');
	}
  
} 


 
