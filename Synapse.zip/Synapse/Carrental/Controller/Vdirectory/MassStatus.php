<?php

namespace Synapse\Carrental\Controller\Vdirectory;

use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\VehicleDirectoryFactory;
use Synapse\Carrental\Model\ResourceModel\VehicleDirectory\CollectionFactory;
use Magento\Customer\Model\Session;

class MassStatus extends \Magento\Framework\App\Action\Action
{
 
    protected $vehicleDirectoryFactory;
	protected $vehicleDirectoryCollectionFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $resultFactory;
	
	protected $_customerSession;

    /**
     * MassFleetStatus constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CollectionFactory $collectionFactory,
		VehicleDirectoryFactory $VehicleDirectoryFactory,
		Session $customerSession,
        Filter $filter
    ) {
		parent::__construct($context);

        $this->_filter = $filter;
		$this->vehicleDirectoryFactory = $VehicleDirectoryFactory;
		$this->vehicleDirectoryCollectionFactory = $collectionFactory;
		$this->_customerSession   = $customerSession ;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->vehicleDirectoryCollectionFactory->create());
		$status = (int) $this->getRequest()->getParam('status');
		$id = (int) $this->getRequest()->getParam('id');
		$supplier_id = $this->_customerSession->getCustomer()->getId();
		if(isset($supplier_id) && $supplier_id!=''){
			$collection = $collection->addFieldToFilter('main_table.supplier_id',$supplier_id);
			$ids = $this->getRequest()->getParam('selected');
			if(isset($ids) && count($ids)>0){
				$collection = $collection->addFieldToFilter('main_table.car_model_id',array('in'=>implode(',',$ids)));	
			}
		}
		$statuscount = 0;
        foreach ($collection as $item) {
				$vehicleDirectoryModel = $this->vehicleDirectoryFactory->create();
				$vehicleDirectoryModel->load($item->getId())
				->setId($item->getId())
				->setStatus($status)
				->save();
				unset($vehicleDirectoryModel);
				$statuscount++;
		}
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been updated.', $statuscount));
       
        
		/* Dispatch envent */
		$this->_eventManager->dispatch(
			'mass_event_vehicle_directory', ['supplier_id' => $supplier_id, 'action' => 'update' ,'items'=>$collection,'status' => $status]
		);
		
		
		$resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/vdirectory');
    }
}

