<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Vdirectory;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehicleDirectoryFactory;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Model\FleetcarmodelsFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Saveindir extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleDirectoryFactory;
	protected $fleetModelFactory;
	protected $fleetcarmodelsFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		VehicleDirectoryFactory $VehicleDirectoryFactory,
		JsonFactory $resultJsonFactory,
		FleetFactory $FleetFactory,
		FleetcarmodelsFactory $FleetcarmodelsFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->vehicleDirectoryFactory = $VehicleDirectoryFactory;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->fleetModelFactory = $FleetFactory;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		
		 
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
			 return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParam('p');
			if($data){
				$data = explode(',',$data);
				array_shift($data);
			 	$supplierId = $this->session->getcustomer()->getId();
				foreach($data as $k=>$_id):
					$vdirectoryModel = $this->vehicleDirectoryFactory->create();
					$vdirectoryModel->setId($_id);
					$vdirectoryModel->setIsActiveInDir(1);
					$vdirectoryModel->save();
					
					$vdirectoryCollection = $vdirectoryModel->getCollection();
					$vdirectoryCollection->addFieldToFilter('main_table.id',$_id);
					$coll = $vdirectoryCollection->getFirstItem();
					
					$fleetCarModel = $this->fleetcarmodelsFactory->create();
					$fleetCarModel->setFleetId($coll->getFleetId());
					$fleetCarModel->setCarModelId($coll->getCarModelId());
					$fleetCarModel->setVehicleTransmission($coll->getVehicleTransmission());
					$fleetCarModel->setVehicleFuel($coll->getVehicleFuel());
					$fleetCarModel->setCarmodelClass($coll->getCarmodelClass());
					$fleetCarModel->setQty($coll->getQty());
					$fleetCarModel->save();
					unset($coll);
					unset($vdirectoryCollection);
				endforeach;
					
				$this->messageManager->addSuccessMessage(__('SuccessFully Added in Directory'));
				return $resultRedirect->setPath('carrental/vdirectory');
 
			}
		}catch (UserLockedException $e) {
			$this->messageManager->addErrorMessage($e->getMessage());
			/** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
			return $resultRedirect->setPath('carrental/vdirectory/add');
 
		}
		catch (\Exception $e) {
			$this->messageManager->addErrorMessage($e->getMessage());
			/** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
			return $resultRedirect->setPath('carrental/vdirectory/add');
		}
		
    }
	
}
