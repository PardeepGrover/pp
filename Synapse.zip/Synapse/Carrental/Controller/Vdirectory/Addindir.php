<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Vdirectory;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehicleDirectoryFactory;
use Synapse\Carrental\Model\FleetFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Addindir extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleDirectoryFactory;
	protected $fleetModelFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		VehicleDirectoryFactory $VehicleDirectoryFactory,
		JsonFactory $resultJsonFactory,
		FleetFactory $FleetFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->vehicleDirectoryFactory = $VehicleDirectoryFactory;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->fleetModelFactory = $FleetFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		
		 
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParam('selected');
			if($data){
				$supplierId = $this->session->getcustomer()->getId();
				$defaultFleetId = $this->getDefaultFleetId($supplierId);
				$alreadyadded = [];
				$recorded = [];
				$message = '';
				foreach($data as $k=>$_carmodelid):
					$vdirectoryModel = $this->vehicleDirectoryFactory->create();
					$isExist = self::IsExistInDirectory($_carmodelid);
					if($isExist && $isExist!=''):
						$alreadyadded[] = $_carmodelid;
						$vdirectoryModel->setId($isExist);
					endif;
					$vdirectoryModel->setSupplierId($supplierId);
					$vdirectoryModel->setCarModelId($_carmodelid);
					$vdirectoryModel->setVehicleTransmission('');
					$vdirectoryModel->setVehicleFuel('');
					$vdirectoryModel->setFleetId($defaultFleetId);
					$vdirectoryModel->save();
					$recorded[] = $_carmodelid;
				 endforeach;
				if(count($recorded)){
					$message =$message. __(
							'Reords are added in the directory',implode(',',$recorded)
					);
					$this->messageManager->addSuccess($message);	
				}else{
					$message =$message. __(
							'"%1" Record(s) are already in directory',implode(',',$alreadyadded)
					);
					$this->messageManager->addError($message);
					
				}
				
					
			}
		}catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			$this->session->logout();
			$this->session->start();
			$this->messageManager->addError($message);
			return $resultRedirect->setPath('customer/account/login');
		}
		catch (\Exception $e) {
			var_dump($e->getMessage());
			die;
			 $this->messageManager->addException($e, __('We can\'t save the Contacts.'));
		}

        
        //}
		//return $resultRedirect->setUrl($this->_redirect('carrental/vdirectory/'));
		return $this->_redirect('carrental/vdirectory/');
		//return $resultRedirect->setPath('carrental/vdirectory/');
    }
	private function getDefaultFleetId($supplierId){
		
		$fleetModel = $this->fleetModelFactory->create();
		$fleetCollection = $fleetModel->getCollection();
		$fleetCollection->addFieldToFilter('main_table.supplier_id',$supplierId);
		$fleetCollection->addFieldToFilter('fleet_name','Default');
		$fleetCollection->addFieldToSelect('id');
		unset($fleetModel);
		return $fleetCollection->getFirstItem()->getId();
	}
	private function IsExistInDirectory($_carmodelid){
		$vdirectoryModel = $this->vehicleDirectoryFactory->create();
		$dircoll = $vdirectoryModel->getCollection();
		$dircoll->addFieldToFilter('car_model_id',$_carmodelid);
		$id = $dircoll->getFirstItem()->getId();
		unset($vdirectoryModel);
		return $id;
	}
	
}
