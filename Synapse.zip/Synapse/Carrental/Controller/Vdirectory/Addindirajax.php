<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Vdirectory;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehicleDirectoryFactory;
use Synapse\Carrental\Model\FleetFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Addindirajax extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleDirectoryFactory;
	protected $fleetModelFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		VehicleDirectoryFactory $VehicleDirectoryFactory,
		JsonFactory $resultJsonFactory,
		FleetFactory $FleetFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->vehicleDirectoryFactory = $VehicleDirectoryFactory;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->fleetModelFactory = $FleetFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		
		 
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		//$resultRedirect = $this->resultRedirectFactory->create();
		$resultJson = $this->resultJsonFactory->create();
		
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParam('data');
			if($data){
				$supplierId = $this->session->getcustomer()->getId();
				$message = '';
				$defaultFleetId = '';
				$fleetModel = $this->fleetModelFactory->create();
				$fleetCollection = $fleetModel->getCollection();
				$fleetCollection->addFieldToFilter('main_table.supplier_id',$supplierId);
				$fleetCollection->addFieldToFilter('fleet_name','Default');
				$fleetCollection->addFieldToSelect('id');
				unset($fleetModel);
				$defaultFleetId = $fleetCollection->getFirstItem()->getId();
				
				$vdirectoryModel = $this->vehicleDirectoryFactory->create();
				$dircoll = $vdirectoryModel->getCollection();
			    $dircoll->addFieldToFilter('main_table.is_active_in_dir',array('eq'=>'0'));
				$dircoll->addFieldToFilter('main_table.supplier_id',$supplierId);
				if($dircoll):
					$dircoll->walk('delete');
					unset($dircoll);
					unset($vdirectoryModel);
				endif;
				foreach($data as $k=>$_carmodelid):
					/*$dircoll = $vdirectoryModel->getCollection();
					$dircoll->addFieldToFilter('main_table.is_active_in_dir',array('eq'=>'0'));
					$dircoll->addFieldToFilter('main_table.car_model_id',$_carmodelid);
					$dircoll->addFieldToSelect('id');
					$id = $dircoll->getFirstItem()->getId();
					if(isset($id) && $id!=''){
						continue;
					}*/
					$vdirectoryModel = $this->vehicleDirectoryFactory->create();
					$vdirectoryModel->setSupplierId($supplierId);
					$vdirectoryModel->setCarModelId($_carmodelid);
					$vdirectoryModel->setVehicleTransmission('');
					$vdirectoryModel->setVehicleFuel('');
					$vdirectoryModel->setFleetId($defaultFleetId);
					$vdirectoryModel->setIsActiveInDir(0);
					$vdirectoryModel->save();
				endforeach;
				 return $resultJson->setData([
						'messages' => [__('Saved SuccessFully')],
						'error' => 0,
					]);
			}
		}catch (UserLockedException $e) {
			return $resultJson->setData([
				'messages' => 'You did not sign in correctly or your account is temporarily disabled',
				'error' =>1 
			]);
		}
		catch (\Exception $e) {
			return $resultJson->setData([
				'messages' => $e->getMessage(),
				'error' => 1
			]);
		
		}
		
    }
	private function getDefaultFleetId($supplierId){
		
		$fleetModel = $this->fleetModelFactory->create();
		$fleetCollection = $fleetModel->getCollection();
		$fleetCollection->addFieldToFilter('main_table.supplier_id',$supplierId);
		$fleetCollection->addFieldToFilter('fleet_name','Default');
		$fleetCollection->addFieldToSelect('id');
		unset($fleetModel);
		return $fleetCollection->getFirstItem()->getId();
	}
	private function IsExistInDirectory($_carmodelid){
		$vdirectoryModel = $this->vehicleDirectoryFactory->create();
		$dircoll = $vdirectoryModel->getCollection();
		$dircoll->addFieldToFilter('car_model_id',$_carmodelid);
		$id = $dircoll->getFirstItem()->getId();
		unset($vdirectoryModel);
		return $id;
	}
	
}
