<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Vdirectory;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Model\FleetcarmodelsFactory;
use Synapse\Carrental\Model\VehicleDirectoryFactory;

use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Massadd extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $fleetFactory;
	protected $fleetcarmodelsFactory;
	protected $vehicleDirectFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		FleetFactory $FleetFactory,
		FleetcarmodelsFactory $FleetcarmodelsFactory,
		JsonFactory $resultJsonFactory,
		VehicleDirectoryFactory $VehicleDirectoryFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->fleetFactory = $FleetFactory;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->vehicleDirectFactory = $VehicleDirectoryFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		 /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParams();
			echo "<pre>";
			var_dump($data);
			die;
			if($data){
				$dirmodel  = $this->vehicleDirectFactory->create();
				if(isset($data['selected']) && count($data['selected'])){
					foreach($data['selected'] as $_cmodelId):
						
						$dircoll   = $dirmodel->getCollection();
						$dircoll->addFieldToFilter('car_model_id',$_cmodelId);
						$dircoll->addFieldToFilter('is_active_in_dir','0');
						$dirresult = $dircoll->getFirstItem();
						echo "<pre>";
						var_dump($dircoll->getSelect()->__toString());
						die;
						echo $dirresult->getId();
						unset($dircoll);
						
						$fleetcarmodel = $this->fleetcarmodelsFactory->create();
						$fleetcarmodelCollection = $fleetcarmodel->getCollection();
						$fleetcarmodelCollection->addFieldToFilter('car_model_id',$_cmodelId);
						$fleetcarmodelCollection->addFieldToFilter('fleet_id',$dirresult->getFleetId());
						$fleetcarmodelId = $fleetcarmodelCollection->getFirstItem()->getId();
						if(isset($fleetcarmodelId) && $fleetcarmodelId!=''){
							$fleetcarmodel->setId($fleetcarmodelId);
							unset($fleetcarmodelCollection);
						}
						
						$fleetcarmodel->setFleetId($dirresult->getFleetId());
						$fleetcarmodel->setCarModelId($dirresult->getCarModelId());
						$fleetcarmodel->setVehicleTransmission($dirresult->getVehicleTransmission());
						$fleetcarmodel->setVehicleFuel($dirresult->getFuel());
						$fleetcarmodel->setCarmodelClass($dirresult->getCarmodelClass());
						$fleetcarmodel->setQty($dirresult->getQty());
						$fleetcarmodel->save();
						
						$dirId = $dirresult->getId();
						if(isset($dirId) && $dirId!=''){
							$dirmodel->setId($dirId);
							$dirmodel->setIsActiveInDir(1);
							$dirmodel->save();
							unset($dircoll);
						}
					endforeach;
					$message = __(
							'Record(s) saved successfully!'
					);
					$this->messageManager->addSuccess($message);
				}
				 
			}
		}catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			$this->session->logout();
			$this->session->start();
			$this->messageManager->addError($message);
			return $resultRedirect->setPath('customer/account/login');
		}
		catch (\Exception $e) {
			var_dump($e->getMessage());
			die;
			$this->messageManager->addException($e, __('We can\'t save the records.'));
		}

		return $resultRedirect->setPath("carrental/vdirectory/");
    }
	
}
