<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Vdirectory;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehicleDirectoryFactory;
use Synapse\Carrental\Model\FleetcarmodelsFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class InlineEditFromListing extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $jsonFactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleDirectoryFactory;
	protected $fleetcarmodelsFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		
		VehicleDirectoryFactory $VehicleDirectoryFactory,
		JsonFactory $resultJsonFactory,
		FleetcarmodelsFactory $FleetcarmodelsFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->vehicleDirectoryFactory = $VehicleDirectoryFactory;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		
		 
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		//$resultRedirect = $this->resultRedirectFactory->create();
		$resultJson = $this->resultJsonFactory->create();
		$error = false;
        $messages = [];
		$postItems = $this->getRequest()->getParam('items', []);
		if (!count($postItems)) {
            return $resultJson->setData([
                'messages' => [__('Please correct the data sent.')],
                'error' => true,
            ]);
        }
		try {
			$data = $this->getRequest()->getParam('items');
			 if($data){
				$supplierId = $this->session->getcustomer()->getId();
				$model = $this->vehicleDirectoryFactory->create();
				$dircollection = $model->getCollection();
				$alreadyadded = [];
				foreach($data as $did=>$_dir):
					/*$dircollection->clear()->getSelect()->reset('where');
					$dircollection->addFieldToFilter('main_table.id',$_dir['id']);
					$dirres = $dircollection->getFirstItem();
					if($dirres->getId()){
						$model->setId($dirres->getId());
					}*/
					$model->load($_dir['id']);
					$model->setVehicleTransmission($_dir['vehicle_transmission']);
					$model->setVehicleFuel($_dir['vehicle_fuel']);
					$model->setCarmodelClass($_dir['carmodel_class']);
					$model->setQty($_dir['qty']);
					$model->setIsActiveInDir(1);
					$model->save();
					
					/*$fleetcarModel = $this->fleetcarmodelsFactory->create();
					$fleetcarModelColl = $fleetcarModel->getCollection();
					$fleetcarModelColl->addFieldToFilter('fleet_id',$dirres->getFleetId());
					$fleetcarModelColl->addFieldToFilter('car_model_id',$dirres->getCarModelId());
					$cmid = $fleetcarModelColl->getFirstItem()->getId();
					if(isset($cmid) && $cmid!=''){
						$fleetcarModel->setId($cmid);
					}
					$fleetcarModel->setFleetId($dirres->getFleetId());
					$fleetcarModel->setCarModelId($dirres->getCarModelId());
					$fleetcarModel->setVehicleTransmission($_dir['vehicle_transmission']);
					$fleetcarModel->setVehicleFuel($_dir['vehicle_fuel']);
					$fleetcarModel->setCarmodelClass($_dir['carmodel_class']);
					$fleetcarModel->setQty($_dir['qty']);
					$fleetcarModel->save();
					unset($dirrecord);
					unset($dirres);*/
				 endforeach;
				$message = __(
					'updated Record added in Your Vehicle Directory',4
				);
				//$this->messageManager->addSuccess($message);
					
			}
		}catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			$error = true;
			
		}
		catch (\Exception $e) {
			var_dump($e->getMessage());
			die;
			  $error = true;
			$message = __(
					'Something went wrong'
				);
		}
		return $resultJson->setData([
            'messages' => $message,
            'error' => $error
        ]);
    }
	
}
