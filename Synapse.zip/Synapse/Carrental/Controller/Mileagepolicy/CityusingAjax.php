<?php 
namespace Synapse\Carrental\Controller\Mileagepolicy;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Synapse\Carrental\Model\CityFactory;
class CityusingAjax extends \Magento\Framework\App\Action\Action { 
	
	protected $resultPageFactory;
	protected $_customerSession;
	protected $_cityfactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		CityFactory $CityFactory
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
            $this->_cityfactory   	  = $CityFactory ;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$data = $this->getRequest()->getParams();
		$responseData = [];
		if(isset($data['region_id']) && $data['region_id']!='0'){
			
			//if(isset($data['region_id'][0]) && $data['region_id'][0]!='0'){
				$regions = [];
				//foreach($data['region_id'] as $_re){
					 //$regn = explode('-',$data['region_id']);
					// $regions[] = @$regn[1];
				//}
				$cityFactory = $this->_cityfactory->create();
				$cityCollection = $cityFactory->getCollection();
				//$cityCollection->addFieldToFilter('region_id',['in'=>$regions]);
				$cityCollection->addFieldToFilter('region_id',['eq'=>$data['region_id']]);
				$responseData = $cityCollection->getData();
			//}
		}
		$resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($responseData);
        return $resultJson;
	} 
  
} 


 
