<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Mileagepolicy;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\MileagePolicyFactory;
use Synapse\Carrental\Model\MileagePolicyCountryFactory;
use Synapse\Carrental\Model\CarmodelsMileagePolicyFactory;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $_mileagePolicyFactory;
	protected $_mileagePolicyCountryFactory;
	protected $_carmodelsMileagePolicyFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		MileagePolicyFactory $MileagePolicyFactory,
		MileagePolicyCountryFactory $MileagePolicyCountryFactory,
		CarmodelsMileagePolicyFactory $CarmodelsMileagePolicyFactory
		
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->_mileagePolicyFactory = $MileagePolicyFactory;
		$this->_mileagePolicyCountryFactory = $MileagePolicyCountryFactory;
		$this->_carmodelsMileagePolicyFactory = $CarmodelsMileagePolicyFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());
		if ($validFormKey && $this->getRequest()->isPost()) {
			try {
				
			$data = $this->getRequest()->getParams();
			if($data){
				
				if(!isset($data['selectedcars'])){
					$this->messageManager->addError(__('No Car Model is selected!'));
					$this->session->setCarrentalFormData($this->getRequest()->getPostValue());
					return $resultRedirect->setPath('carrental/mileagepolicy/add');
					return false;
				}
				$supplierId = $this->session->getCustomer()->getId();
				$policyModel = $this->_mileagePolicyFactory->create();
				$mpdata = $data['info'];
				/*echo "<pre>";
				var_dump($data);
				die;*/
				/*$mp = [];
				$mp['warehouse_id'] 	= $mpdata['warehouse_id'];
				$mp['mileage_fee']		= $mpdata['mileage_fee'];
				$mp['mileage_units'] 	= $mpdata['mileage_units'];
				$mp['mileage_type'] 	= $mpdata['mileage_type'];
				$mp['included_amount']  = $mpdata['included_amount'];
				$mp['included_amount_duration'] = $mpdata['included_amount_duration'];
				$mp['additional_mileage_cost']  = $mpdata['additional_mileage_cost'];
				$mp['additional_mileage_cost_duration'] = $mpdata['additional_mileage_cost_duration'];
				$mp['mileage_duration_fromdays'] = $mpdata['mileage_duration_fromdays'];
				$mp['mileage_duration_todays'] = $mpdata['mileage_duration_todays'];
				 */
				$policyModel->setData($mpdata);
				$policyModel->setSupplierId(
					$supplierId
				);
				if(isset($mpdata['fleet_id']) && $mpdata['fleet_id']!=''){
					$policyModel->setFleetId(
						implode(',',$mpdata['fleet_id'])
					);
				}
				if(isset($mpdata['pricelist_id']) && $mpdata['pricelist_id']!=''){
					$policyModel->setPricelistId(
						implode(',',$mpdata['pricelist_id'])
					);
				}
				if(isset($mpdata['rate_code']) && $mpdata['rate_code']){
					$policyModel->setRateCode(
						implode(',',$mpdata['rate_code'])
					);
				}
				
				/*echo "<pre>";
				var_dump($policyModel->getData());
				die;*/
				$isSaved = $policyModel->save();
				$ccId = [];	
				if($isSaved){
					if(isset($data['csc']) && count($data['csc']) && $data['csc'][0]['country_id']!=''){
						foreach($data['csc'] as $k =>$_arr){
							if(is_array($_arr['city'])){
								foreach($_arr['city'] as $_ct):
									$cntr = $this->_mileagePolicyCountryFactory->create();
									$cntr->setMileageId($isSaved->getId()); 
									$cntr->setSupplierId($supplierId); 
									$cntr->setCountryId($_arr['country_id']); 
									$cntr->setRegionId($_arr['region_id']);
									$cntr->setCityId($_ct);
									$cntr->save();
									unset($cntr); 
									//$ccId[]= $cnObj->getId();
								endforeach;
							}else{
								$cntrobj = $this->_mileagePolicyCountryFactory->create();
								$cntrobj->setMileageId($isSaved->getId()); 
								$cntrobj->setSupplierId($supplierId); 
								$cntrobj->setCountryId($_arr['country_id']); 
								$cntrobj->setRegionId($_arr['region_id']);
								$cntrobj->setCityId((int)$_arr['city']);
								$cntrobj->save();
								//$ccId[]= $cntrobj->getId();
								unset($cntrobj); 
							}
							
						}
						
					}else{
						if(isset($mpdata['apply_on_all_country'])){
							$cntr1 = $this->_mileagePolicyCountryFactory->create();
							$cntr1->setMileageId($isSaved->getId()); 
							$cntr1->setSupplierId($supplierId); 
							$cntr1->setCountryId(0); 
							$cntr1->setRegionId(0);
							$cntr1->setCityId(0);
							$cntr1->save();
							unset($cntr1); 
						}
					}
					 
					if(isset($data['selectedcars']) && count($data['selectedcars'])){
						$p_id = [];
						foreach($data['selectedcars'] as $_cid =>$_carss){
						$mileageAssociatedCarsModel = $this->_carmodelsMileagePolicyFactory->create();
						$mileageAssociatedCarsModel->setMileageId($isSaved->getId()); 
						$mileageAssociatedCarsModel->setSupplierId($supplierId);
						$mileageAssociatedCarsModel->setCarModelId($_carss['car_model_id']);
						$mileageAssociatedCarsModel->setProductId($_carss['product_id']);
						$mileageAssociatedCarsModel->setCId($_cid);
						$mileageAssociatedCarsModel->save();
						}
						$p_id[$_carss['product_id']] = $mpdata['mileage_type'];
						if(isset($p_id) && count($p_id)){
								$this->_eventManager->dispatch('synapse_carrental_product_updateAttr', ['ids' => $p_id,'type'=>'mileage']);
							}
						
					}
					 
				}
				 
			}
			$this->messageManager->addSuccess(__('You saved the  information.'));
			return $resultRedirect->setPath('carrental/mileagepolicy/');
			}catch (UserLockedException $e) {
				$message = __(
					'You did not sign in correctly or your account is temporarily disabled.'
				);
				$this->session->logout();
				$this->session->start();
				$this->messageManager->addError($message);
				return $resultRedirect->setPath('customer/account/login');
			}
			catch (\Exception $e) {
					var_dump($e->getMessage());
					die;
				$this->messageManager->addException($e, __('We can\'t save the Contacts.'.$e->getMessage()));
			}

		   // $this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
		}
		die;
		return $resultRedirect->setPath('carrental/mileagepolicy/edit',['id'=>$isSaved->getId()]);
    }
	
}
