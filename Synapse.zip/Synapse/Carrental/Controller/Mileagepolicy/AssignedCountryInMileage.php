<?php 
namespace Synapse\Carrental\Controller\Mileagepolicy;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
class AssignedCountryInMileage extends \Magento\Framework\App\Action\Action { 
	
	protected $resultPageFactory;
	protected $_customerSession;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
            return parent::__construct($context);
        }
	public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$resultPage = $this->resultPageFactory->create();
		$resultPage->addHandle('carrental_mileagepolicy_assignedcountry');
		 return $resultPage;
               
	} 
  
} 


 
