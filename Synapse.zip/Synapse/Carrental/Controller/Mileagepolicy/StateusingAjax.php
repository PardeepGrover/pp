<?php 
namespace Synapse\Carrental\Controller\Mileagepolicy;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Synapse\Carrental\Model\CityFactory;
use Magento\Directory\Model\ResourceModel\Region\CollectionFactory ;
class StateusingAjax extends \Magento\Framework\App\Action\Action { 
	
	protected $resultPageFactory;
	protected $_customerSession;
	protected $_cityfactory;
	protected $_regCollectionFactory;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $resultPageFactory,
		\Magento\Customer\Model\Session $customerSession,
		CityFactory $CityFactory,
		CollectionFactory $regCollectionFactory
		 
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
            $this->_cityfactory   	  = $CityFactory ;
            $this->_regCollectionFactory   	  = $regCollectionFactory ;
            return parent::__construct($context);
        }
	 public function execute() { 
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$data = $this->getRequest()->getParams();
		$responseData = [];
		if(isset($data['country_id'])){
			$regionCOll = $this->_regCollectionFactory->create();
			$regionCOll->addFieldToFilter('country_id',['in'=>$data['country_id']])->load();
			$responseData = $regionCOll->getData();
			 
		}
		//echo "<pre>";
		//var_dump($regionCOll->getData());
		//var_dump($data['country_id']);
		//die;
		$resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        $resultJson->setData($responseData);
        return $resultJson;
	} 
  
} 


 
