<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Billingprofile;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\WarehousebillingprofilesFactory;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class EditPost extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $warehousebillingprofilesFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		WarehousebillingprofilesFactory $WarehousebillingprofilesFactory
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->warehousebillingprofilesFactory = $WarehousebillingprofilesFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());
		if ($validFormKey && $this->getRequest()->isPost()) {
			try {
				 
				$carrentalBillingprofilesModels = $this->warehousebillingprofilesFactory->create();
				$carrentalBillingprofilesModels->setData($this->getRequest()->getParams());
				$carrentalBillingprofilesModels->setAcceptedPayments(implode(',',$this->getRequest()->getParam('accepted_payments')));
				$carrentalBillingprofilesModels->setSupplierId($this->session->getCustomer()->getId());
				 
				$carrentalBillingprofilesModels->save();
				$this->messageManager->addSuccess(__('Billing profile saved successfully!.'));
                return $resultRedirect->setPath('carrental/billingprofile/');
            }catch (UserLockedException $e) {
                $message = __(
                    'You did not sign in correctly or your account is temporarily disabled.'
                );
                $this->session->logout();
                $this->session->start();
                $this->messageManager->addError($message);
                return $resultRedirect->setPath('customer/account/login');
            }
            catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t save the Contacts.'));
            }
			//$this->session->setCarrentalBillingprofileFormData($this->getRequest()->getPostValue());
        }
		return $resultRedirect->setPath('carrental/billingprofile/edit');
    }
	
}
