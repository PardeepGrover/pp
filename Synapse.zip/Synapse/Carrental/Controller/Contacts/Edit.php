<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Contacts;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\WarehousecontactsFactory;
use Magento\Framework\Registry ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Edit extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $warehousecontactsFactory;
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;
	protected $registry;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		WarehousecontactsFactory $WarehousecontactsFactory,
		PageFactory $resultPageFactory,
		Registry $registry
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->warehousecontactsFactory = $WarehousecontactsFactory;
		$this->resultPageFactory = $resultPageFactory;
		$this->registry = $registry;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
       /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		
		/** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
		
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		$this->session->getCarrentalContactFormData(true);
		$contactModel = $this->warehousecontactsFactory->create();
		$contactCollection = $contactModel->getCollection();
		$contactCollection->addFieldToFilter('id',$this->getRequest()->getParam('id'));
		$contactCollection->addFieldToSelect('id','contact_id');
		$contactCollection->addFieldToSelect('profile_name');
		$contactCollection->addFieldToSelect('contact_email');
		$contactCollection->addFieldToSelect('contact_person');
		$contactCollection->addFieldToSelect('contact_code');
		$contactCollection->addFieldToSelect('contact_phone');
		$contactCollection->addFieldToSelect('contact_fax');
		$contactCollection->addFieldToSelect('contacts_city');
		$contactCollection->addFieldToSelect('contacts_region');
		$contactCollection->addFieldToSelect('contacts_region_id');
		$contactCollection->addFieldToSelect('contacts_postcode');
		$contactCollection->addFieldToSelect('contacts_country_id');
		$contactCollection->addFieldToSelect('contacts_location');
		$contactCollection->addFieldToSelect('created_at');
		$contactCollection->addFieldToSelect('updated_at');
		$this->session->setCarrentalContactFormData($contactCollection);
		$this->registry->register('CarrentalContactProfile',$contactCollection->getFirstItem());
		$resultPage->addHandle('carrental_contacts_edit');
        return $resultPage;
    }
	
	
}
