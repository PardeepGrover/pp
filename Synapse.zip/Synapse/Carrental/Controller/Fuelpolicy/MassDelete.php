<?php

namespace Synapse\Carrental\Controller\Fuelpolicy;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\ResourceModel\FuelPolicy\CollectionFactory;
use Magento\Customer\Model\Session;
class MassDelete extends \Magento\Framework\App\Action\Action
{
 
    protected $fuelPolicyCollectionFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $resultFactory;
	
	protected $_customerSession;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CollectionFactory $fuelPolicyCollectionFactory,
		Session $customerSession,
        Filter $filter
    ) {
		parent::__construct($context);

        $this->_filter = $filter;
        $this->fuelPolicyCollectionFactory = $fuelPolicyCollectionFactory;
		$this->_customerSession   = $customerSession;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->fuelPolicyCollectionFactory->create());
		
		$supplier_id = $this->_customerSession->getCustomer()->getId();
		if(isset($supplier_id) && $supplier_id!=''){
			$collection = $collection->addFieldToFilter('supplier_id',$supplier_id);
		}
				
        $delete = 0;
         foreach ($collection as $item) {
			$item->delete();
            $delete++;
        } 
		
		 
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $delete));
       
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/fuelpolicy');
    }
}
