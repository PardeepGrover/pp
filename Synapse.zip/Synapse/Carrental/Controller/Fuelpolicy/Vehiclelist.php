<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\FuelPolicy;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\VehiclepricelistFactory;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
use Magento\Framework\Controller\Result\JsonFactory ;
/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Vehiclelist extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $vehicleDirectoryFactory;
	protected $vehicleseasonalpriceFactory;
	protected $warehouseinfoFactory;
	protected $_vehiclepricelistFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		VehiclepricelistFactory $VehiclepricelistFactory,
		JsonFactory $resultJsonFactory,
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->resultJsonFactory = $resultJsonFactory;
		$this->vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
		//$this->warehouseinfoFactory = $warehouseinfoFactory;
		$this->_vehiclepricelistFactory = $VehiclepricelistFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		/** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		//$resultRedirect = $this->resultRedirectFactory->create();
		$resultJson = $this->resultJsonFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParams();
			$finalarr = [];
			if($data){
				$supplierId = $this->getCustomerId();
				$vModel 	= $this->_vehiclepricelistFactory->create();
				if($data['warehouse_id'] && $data['fleet_id']){
					$collection = $vModel->getCollection();
					$collection->addFieldToSelect('id');
					$collection->addFieldToSelect(['fl_id'=>'fleet_id']);
					$collection->getSelect()->joinLeft(
						['cars'=>$collection->getTable('wais_supplier_season_pricelist')
						],
						'cars.pricelist_id=main_table.id',
						[
						 'cars.*'
						]
					);
					$collection->getSelect()->joinLeft(
						['carmodel'=>$collection->getTable('wais_carmodel')
						],
						'carmodel.id=cars.car_model_id',
						[
						 'carmodel.vehicle_name as v_name'
						]
					);
					$collection->addFieldToFilter(
						'main_table.supplier_id',
						['eq'=>$this->getCustomerId()]
					);
					$collection->addFieldToFilter(
						'main_table.warehouse_id',
						['eq'=>$data['warehouse_id']]
					);
					$collection->addFieldToFilter(
						'main_table.fleet_id',
						['in'=>$data['fleet_id']]
					);
					$collection->getSelect()->group('cars.car_model_id');
				}elseif($data['rate_code'] && $data['pricelist_id']){
					$collection = $vModel->getCollection();
					$collection->addFieldToSelect(['fl_id'=>'fleet_id']);
					$collection->getSelect()->joinLeft(
						['cars'=>$collection->getTable('wais_supplier_season_pricelist')
						],
						'cars.pricelist_id=main_table.id',
						[
						 'cars.*'
						]
					);
					$collection->getSelect()->joinLeft(
						['carmodel'=>$collection->getTable('wais_carmodel')
						],
						'carmodel.id=cars.car_model_id',
						[
						 'carmodel.vehicle_name as v_name'
						]
					);
					$collection->addFieldToFilter(
						'main_table.supplier_id',
						['eq'=>$this->getCustomerId()]
					);
					$collection->addFieldToFilter(
						'main_table.rate_code',
						['eq'=>$data['rate_code']]
					);
					$collection->addFieldToFilter(
						'main_table.id',
						['in'=>$data['pricelist_id']]
					);
					$collection->getSelect()->group('cars.car_model_id');
				}
				if($collection->getSize()){
					$finalarr = [];
					if($collection){
						foreach($collection as $_cars):
							$finalarr[$_cars->getFlId()]['fleet_name'] = $_cars->getFleetName();
							$finalarr[$_cars->getFlId()]['cars'][] = $_cars->getData();
						endforeach;
						
					}
					
				}
				return $resultJson->setData([
					'messages' => [__('Saved SuccessFully')],
					'error' => 0,
					'result'=>array_values($finalarr)
				]);
			}
		}catch (UserLockedException $e) {
			return $resultJson->setData([
				'messages' => 'You did not sign in correctly or your account is temporarily disabled',
				'error' =>1 
			]);
		}
		catch (\Exception $e) {
			return $resultJson->setData([
				'messages' => $e->getMessage(),
				'error' => 1
			]);
		
		}
		
    }
	public function getCustomerId(){
		return $this->session->getCustomer()->getId();
	}
	 
	 
	
}
