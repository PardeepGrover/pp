<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Fuelpolicy;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\FuelPolicyFactory;
use Synapse\Carrental\Model\MileagePolicyFactory;
use Synapse\Carrental\Model\MileagePolicyCountryFactory;
use Synapse\Carrental\Model\CarmodelsMileagePolicyFactory;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $_fuelPolicyFactory;
	protected $_mileagePolicyFactory;
	protected $_mileagePolicyCountryFactory;
	protected $_carmodelsMileagePolicyFactory;
	protected $_productModelFactory;
	public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		\Magento\Catalog\Model\ProductFactory $productModelFactory,
		MileagePolicyFactory $MileagePolicyFactory,
		MileagePolicyCountryFactory $MileagePolicyCountryFactory,
		CarmodelsMileagePolicyFactory $CarmodelsMileagePolicyFactory,
		FuelPolicyFactory $FuelPolicyFactory
		
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->_fuelPolicyFactory = $FuelPolicyFactory;
		$this->_mileagePolicyFactory = $MileagePolicyFactory;
		$this->_mileagePolicyCountryFactory = $MileagePolicyCountryFactory;
		$this->_carmodelsMileagePolicyFactory = $CarmodelsMileagePolicyFactory;
		$this->_productModelFactory = $productModelFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());
		if ($validFormKey && $this->getRequest()->isPost()) {
			try {
				
				$data = $this->getRequest()->getParams();
				$policyModel = $this->_fuelPolicyFactory->create();
				$fp = $data['info'];
				//echo "<pre>";
				//var_dump($data);
				//die;
				if($data){
					
					if(!isset($data['selectedcars'])){
						$this->messageManager->addError(__('No Car Model is selected!'));
						$this->session->setCarrentalFormData($this->getRequest()->getPostValue());
						return $resultRedirect->setPath('carrental/fuelpolicy/add');
						return false;
					}
					$supplierId = $this->session->getCustomer()->getId();
					
					$policyModel->setData($fp);
					if(isset($fp['fleet_id']) && $fp['fleet_id']!=''){
						$policyModel->setFleetId(
							implode(',',$fp['fleet_id'])
						);
					}
					if(isset($fp['pricelist_id']) && $fp['pricelist_id']!=''){
						$policyModel->setPricelistId(
							implode(',',$fp['pricelist_id'])
						);
					}
					if(isset($fp['rate_code']) && $fp['rate_code']){
						$policyModel->setRateCode(
							implode(',',$fp['rate_code'])
						);
					}
					$policyModel->setSupplierId($supplierId);
					$isSaved  = $policyModel->save();
					if($isSaved){
						if(isset($data['selectedcars']) && count($data['selectedcars'])){
							$p_id = [];
							foreach($data['selectedcars'] as $_cid =>$_carss)
							{
								$mileageAssociatedCarsModel = $this->_carmodelsMileagePolicyFactory->create();
								$mileageAssociatedCarsModel->setFuelId($isSaved->getId()); 
								$mileageAssociatedCarsModel->setSupplierId($supplierId);
								$mileageAssociatedCarsModel->setCarModelId($_carss['car_model_id']);
								$mileageAssociatedCarsModel->setProductId($_carss['product_id']);
								$mileageAssociatedCarsModel->setCId($_cid);
								$mileageAssociatedCarsModel->save();
								$p_id[$_carss['product_id']] = $fp['fuel_type'];
							}
							if(isset($p_id) && count($p_id)){
								$this->_eventManager->dispatch('synapse_carrental_product_updateAttr', ['ids' => $p_id]);
							}
						}
					}
							
				} 
					 
			
				 
			 
			$this->messageManager->addSuccess(__('You saved the  information.'));
			return $resultRedirect->setPath('carrental/fuelpolicy/');
			}catch (UserLockedException $e) {
				$message = __(
					'You did not sign in correctly or your account is temporarily disabled.'
				);
				$this->session->logout();
				$this->session->start();
				$this->messageManager->addError($message);
				return $resultRedirect->setPath('customer/account/login');
			}
			catch (\Exception $e) {
					var_dump($e->getMessage());
					die;
				$this->messageManager->addException($e, __('We can\'t save the Contacts.'.$e->getMessage()));
			}

		   // $this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
		}
		die;
		return $resultRedirect->setPath('carrental/mileagepolicy/edit',['id'=>$isSaved->getId()]);
    }
	
}
