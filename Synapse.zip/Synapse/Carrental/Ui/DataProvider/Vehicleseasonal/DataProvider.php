<?php
/**
* Copyright 2018 . All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Ui\DataProvider\Vehicleseasonal;

use Synapse\Carrental\Model\ResourceModel\Vehicleseasonalprice\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Customer\Model\Session;

/**
 * Class FormDataProvider
 *
 * @package Aheadworks\Rma\Ui\DataProvider\Request
 */
class DataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	
	protected $_customerSession;
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param RequestInterface $request
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request,
        DataPersistorInterface $dataPersistor,
		Session $customerSession,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
        $this->request = $request;
        $this->dataPersistor = $dataPersistor;
		$this->_customerSession   = $customerSession ;
    }

    /**
     * {@inheritdoc}
     */
    public function getData()
    {
		$collection =  $this->getCollection();
		/* echo $collection->getSelect()->__toString();*/


		// join
		$collection->getSelect()->joinLeft(
			['secondTable' => 'magwais_pricelist_seasons'],
			'main_table.season_id= secondTable.id', 
			[
			 'secondTable.season_name',
			 'secondTable.season_from_date',
			 'secondTable.season_to_date'
			  
			] 
		)->joinLeft(
			['thirdTable' => 'magwais_vehicle_price_list'],
			'main_table.pricelist_id= thirdTable.id', 
			[
			 'thirdTable.pricelist_name'
			] 
		)->joinLeft(
			['fourthTable' => 'magwais_fleet'],
			'thirdTable.fleet_id= fourthTable.id', 
			[
			 'fourthTable.fleet_name'
			] 
		)->joinLeft(
			['fifthTable' => 'magwais_carmodel'],
			'main_table.car_model_id= fifthTable.id', 
			[
			 'fifthTable.vehicle_name'
			] 
		);

		
		if($this->_customerSession->isLoggedIn()){
			$supplierId = $this->_customerSession->getCustomer()->getId();
			$collection->addFieldToFilter('main_table.supplier_id', $supplierId);
		}
		/* echo "<pre>";
		print_r($collection->getData()); die; */
		
		$data = parent::getData();
		return $data;
	}

    
}
