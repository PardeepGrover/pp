<?php
/**
* Copyright 2018 . All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Ui\DataProvider\Mileagepolicy;

use Synapse\Carrental\Model\ResourceModel\MileagePolicy\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Customer\Model\Session;

/**
 * Class FormDataProvider
 *
 * @package Aheadworks\Rma\Ui\DataProvider\Request
 */
class DataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	
	protected $_customerSession;
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param RequestInterface $request
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request,
        DataPersistorInterface $dataPersistor,
		Session $customerSession,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
        $this->request = $request;
        $this->dataPersistor = $dataPersistor;
		$this->_customerSession   = $customerSession ;
    }

    /**
     * {@inheritdoc}
     */
    public function getData()
    {
		
		$collection = $this->getCollection();
		$collection->getSelect()->joinLeft(
			['cntry'=>$collection->getTable('wais_supplier_mileage_policy_country')],
			'cntry.mileage_id = main_table.id',
			['cntry.country_id','cntry.region_id','cntry.city_id']
		
		);
		$collection->getSelect()->group('main_table.id');
		$supplierId = $this->_customerSession->getCustomer()->getId();
		if($this->_customerSession->isLoggedIn()){
			$collection->addFieldToFilter('main_table.supplier_id', $supplierId);
			$collection->getSelect()->where('is_deleted="0" or is_deleted IS NULL');
		}
		if($id = $this->dataPersistor->get('admin_supplier_mileage')){
			$collection->addFieldToFilter('main_table.supplier_id', $id);
			
		}
		$data = parent::getData();
		return $data;
	}

    
}
