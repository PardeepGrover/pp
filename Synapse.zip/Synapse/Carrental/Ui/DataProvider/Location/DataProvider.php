<?php
/**
* Copyright 2018 . All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Ui\DataProvider\Location;

use Synapse\Carrental\Model\ResourceModel\Location\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Backend\Model\Session;

/**
 * Class FormDataProvider
 *
 * @package Aheadworks\Rma\Ui\DataProvider\Request
 */
class DataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	
	protected $_customerSession;
	protected $session;
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param RequestInterface $request
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request,
        DataPersistorInterface $dataPersistor,
		Session $Session,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
        $this->request = $request;
        $this->dataPersistor = $dataPersistor;
		$this->session   = $Session ;
    }

    /**
     * {@inheritdoc}
     */
	public function getData()
    {
		 
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
		/*$this->collection->getSelect()->joinLeft(
			[
			'cityt' =>$collection->getTable('directory_country_region_city'),
			],
			'cityt.city_id=main_table.city_id',
			[
				'cityt.city_name'
			]
		);*/
		$items = $this->collection->getItems();
		$this->loadedData = array();
        foreach ($items as $_item) {
			$this->loadedData[$_item->getLocalityId()] = $_item->getData();
        }
		$data = $this->session->getFormData();
		if (!empty($data)) {
            $segment = $this->collection->getNewEmptyItem();
            $segment->setData($data);
            $this->loadedData[$segment->getId()] = $segment->getData();
           
        }
		$this->session->unsetFormData();
		return $this->loadedData;
	
	}

    
}
