<?php
/**
* Copyright 2018 . All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Ui\DataProvider\Warehouse;

use Synapse\Carrental\Model\ResourceModel\Warehouseinfo\CollectionFactory;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Ui\DataProvider\AbstractDataProvider;
use Magento\Customer\Model\Session;

/**
 * Class FormDataProvider
 *
 * @package Aheadworks\Rma\Ui\DataProvider\Request
 */
class DataProvider extends AbstractDataProvider
{
    /**
     * @var Collection
     */
    protected $collection;

    /**
     * @var RequestInterface
     */
    private $request;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	
	protected $_customerSession;
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $collectionFactory
     * @param RequestInterface $request
     * @param DataPersistorInterface $dataPersistor
     * @param array $meta
     * @param array $data
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $collectionFactory,
        RequestInterface $request,
        DataPersistorInterface $dataPersistor,
		Session $customerSession,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
        $this->collection = $collectionFactory->create();
        $this->request = $request;
        $this->dataPersistor = $dataPersistor;
		$this->_customerSession   = $customerSession ;
    }

    /**
     * {@inheritdoc}
     */
    public function getData()
    {
		$collection = $this->getCollection();
		$collection->getSelect()->joinLeft(
			[
			'city'=>$collection->getTable('directory_country_region_city')
			
			],
			'city.city_id=main_table.city',
			[
				'city.city_name as city'
			]
		);
		$collection->getSelect()->joinLeft(
			[
			'location'=>$collection->getTable('directory_city_loctions')
			
			],
			'location.locality_id=main_table.location',
			[
				'location.location_name as location'
			]
		);
		$collection->getSelect()->joinLeft(
			[
			'pricelist'=>$collection->getTable('wais_vehicle_price_list')
			
			],
			'pricelist.warehouse_id=main_table.id',
			[
				'pricelist.pricelist_name as pricelist_name'
			]
		);
		$collection->getSelect()->group('main_table.id');
		if($this->_customerSession->isLoggedIn()){
			$supplierId = $this->_customerSession->getCustomer()->getId();
			$this->getCollection()->addFieldToFilter('main_table.supplier_id', $supplierId);
		}
		//var_dump($this->dataPersistor->get('admin_warehouse_id'));
		//die;
		if($id = $this->dataPersistor->get('admin_warehouse_id')){
			$this->getCollection()->addFieldToFilter('main_table.supplier_id', $id);
			
		}
		$this->getCollection()->addFieldToFilter('is_deleted', 0);
		$data = parent::getData();
		return $data;
	}

    
}
