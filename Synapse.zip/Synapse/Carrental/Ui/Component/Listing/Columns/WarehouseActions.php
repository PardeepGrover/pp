<?php
/**
 * Copyright © 2015 Magenest. All rights reserved.
 *
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Ui\Component\Listing\Columns\Column;

class WarehouseActions extends Column
{
    /**
     * URL builder
     *
     * @var UrlInterface
     */
    protected $_urlBuilder;

    /**
     * constructor
     *
     * @param UrlInterface $urlBuilder
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param array $components
     * @param array $data
     */
    public function __construct(
        UrlInterface $urlBuilder,
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        array $components = [],
        array $data = []
    ) {
        $this->_urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
			$fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item['supplier_id'])) {
                    $viewUrlPath = $this->getData('config/viewUrlPath') ?: '#';
                    $urlEntityParamName = $this->getData('config/urlEntityParamName') ?: 'id';
                    $item[$this->getData('name')] = [
						'Contact' => [
                            'href' => $this->_urlBuilder->getUrl('carrental/warehouse/contacts'
                                ,
                                [
                                    $urlEntityParamName => $item['supplier_billing_profile']
                                ]
                            ),
                            'target'=>'_blank',
                            'label' => __('Assign Contact')
                        ],
						'Billing' => [
                            'href' => $this->_urlBuilder->getUrl('carrental/warehouse/billing/'
                                ,
                                [
                                    $urlEntityParamName => $item['supplier_billing_profile']
                                ]
                            ),
                            'target'=>'_blank',
                            'label' => __('Assign Billing)')
                        ]
                    ];

                    
                }
            }
        }

        return $dataSource;
    }
}
