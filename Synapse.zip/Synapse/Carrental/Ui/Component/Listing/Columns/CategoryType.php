<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Class LocationActions
 * @package Synapse\Carrental\Ui\Component\Listing\Columns
 */
class CategoryType extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;
	
	 /**
     * @var UrlInterface
     */
     private $_countryCollectionFactory;
	 
	 private $_helper;

    /**
     * CustomerActions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
		\Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
		\Synapse\Carrental\Helper\Data $helper,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
		$this->_helper = $helper;
		$this->_countryCollectionFactory = $countryCollectionFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
				$newarr = [];
                if(!empty($item[$fieldName])){
                    $categorytype = $this->getCategoryType();
					$key = array_search($item['vehicle_category_type'], array_column($categorytype, 'value'));
					$item[$fieldName] = $categorytype[$key]['label'];
				}
                 
               
            }
        }
		  return $dataSource;
       
    }
	public function getCategoryType()
	{
		$categoryType =  $this->_helper->getCategoryType();
		return $categoryType;
	}
}
