<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Class LocationActions
 * @package Synapse\Carrental\Ui\Component\Listing\Columns
 */
class Transmission extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;
	
	 /**
     * @var _helper
     */
     
	 private $_helper;

    /**
     * CustomerActions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
		\Synapse\Carrental\Helper\Data $helper,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
		$this->_helper = $helper;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
				$newarr = [];
                if(!empty($item[$fieldName])){
                    $transmission = $this->getTransmission();
					$key = array_search($item['vehicle_transmission'], array_column($transmission, 'value'));
					$item[$fieldName] = $transmission[$key]['label'];
				}else{
					$item[$fieldName] = '----------';
				}
                 
                
            }
        }
		  return $dataSource;
       
    }
	public function getTransmission()
	{
		$VehicleFuel =  $this->_helper->getTransmission();
		return $VehicleFuel;
	}
}
