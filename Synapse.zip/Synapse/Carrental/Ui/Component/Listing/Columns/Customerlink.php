<?php

namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;

class Customerlink extends \Magento\Ui\Component\Listing\Columns\Column
{
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
                if (isset($item[$fieldName])) {
                    $html = "<a target='_blank' href='" . $this->context->getUrl('customer/index/edit/',['id'=>$item[$fieldName]]) . "'>";
                    $html .= $item[$fieldName];
                    $html .= "</a>";
                    $item[$fieldName] = $html;
                }
            }
        }
        return $dataSource;
    }
}

?>