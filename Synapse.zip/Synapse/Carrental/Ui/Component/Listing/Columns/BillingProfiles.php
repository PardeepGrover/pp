<?phpnamespace Synapse\Carrental\Ui\Component\Listing\Columns;use Magento\Framework\View\Element\UiComponentFactory;use Magento\Framework\View\Element\UiComponent\ContextInterface;use Synapse\Carrental\Model\WarehousebillingprofilesFactory;class BillingProfiles extends \Magento\Ui\Component\Listing\Columns\Column{
    private $_warehousebillingprofilesFactory;		/**	 * Prepare Data Source	 *	 * @param array $dataSource	 * @return array	 */	/**     * CustomerActions constructor.     * @param ContextInterface $context     * @param UiComponentFactory $uiComponentFactory     * @param UrlInterface $urlBuilder     * @param array $components     * @param array $data     */    public function __construct(        ContextInterface $context,        UiComponentFactory $uiComponentFactory,		WarehousebillingprofilesFactory $WarehousebillingprofilesFactory,       array $components = [],        array $data = []    ) {		parent::__construct($context, $uiComponentFactory, $components, $data);		$this->_warehousebillingprofilesFactory = $WarehousebillingprofilesFactory;    }
    public function prepareDataSource(array $dataSource)	{	
        if (isset($dataSource['data']['items'])) {			$fieldName = $this->getData('name');						foreach ($dataSource['data']['items'] as &$item) {				if (isset($item[$fieldName])) {					$html = '';					$billingProfileModel = $this->_warehousebillingprofilesFactory->create();					$cntres = $billingProfileModel->load($item[$fieldName]);					$html.= "<a target='_blank' href='" . $this->context->getUrl('carrental/billingprofile/edit/',['id'=>$item[$fieldName]]) . "'>";					$html .= $cntres->getProfileName();					$html .= "</a>";					$html .= " ";					unset($billingProfileModel);					unset($cntres);				   $item[$fieldName] = $html;
                }
            }
        }		return $dataSource;
    }
}

?>