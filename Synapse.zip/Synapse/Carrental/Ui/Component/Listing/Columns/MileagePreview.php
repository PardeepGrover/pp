<?php
namespace Synapse\Carrental\Ui\Component\Listing\Columns;
 
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
 
class MileagePreview extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;
    protected $_listproduct;
    protected $_mileagePolicyColl;
 
    /**
     * Constructor
     *
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
		\Synapse\Carrental\Block\Product\ListProduct $listProductBlock,
		\Synapse\Carrental\Model\ResourceModel\MileagePolicy\CollectionFactory $mileageCollection,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        $this->_listproduct = $listProductBlock;
        $this->_mileagePolicyColl = $mileageCollection;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
 
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
        $blockObjt = $this->_listproduct;
		
		
		if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {

				$Mileagecollection = $this->_mileagePolicyColl->create();
				$Mileagecollection->addFieldToFilter('id',$item['id']);
				$content = $blockObjt->getMileagePolicyContents($Mileagecollection);
				 //var_dump($content);
                $item[$fieldName . '_html'] = "<button class='button'><span>Preview</span></button>";
                $item[$fieldName . '_title'] = __('Mileage Policy');
               // $item[$fieldName . '_submitlabel'] = __('');
                //$item[$fieldName . '_cancellabel'] = __('');
                $item[$fieldName . '_content'] = $content;
				$item[$fieldName . '_formaction'] = '#';
            }
        }
 
        return $dataSource;
    }
}