<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Eav\Model\Entity\Attribute\Source\AbstractSource;
//use Magento\Framework\View\Element\UiComponent\ContextInterface;
//use Magento\Framework\View\Element\UiComponentFactory;
//use Magento\Ui\Component\Listing\Columns\Column;
//use Magento\Framework\UrlInterface;

/**
 * Class LocationActions
 * @package Magenest\RentalAndBookingSystem\Ui\Component\Listing\Columns
 */
class EventTypes extends AbstractSource implements OptionSourceInterface
{
    
	const EVENT_TYPE1 = 1;
	const EVENT_TYPE2 = 2;
	/**
     * Retrieve option array
     *
     * @return string[]
     */
    public static function getOptionArray()
    {
        return [self::EVENT_TYPE1 => __('Working Hours'), self::EVENT_TYPE2 => __('Holiday')];
    }

    /**
     * Retrieve option array with empty value
     *
     * @return string[]
     */
    public function getAllOptions()
    {
        $result = [];

        foreach (self::getOptionArray() as $index => $value) {
            $result[] = ['value' => $index, 'label' => $value];
        }

        return $result;
    }

    /**
     * Retrieve option text by option value
     *
     * @param string $optionId
     * @return string
     */
    public function getOptionText($optionId)
    {
        $options = self::getOptionArray();

        return isset($options[$optionId]) ? $options[$optionId] : null;
    }
}


