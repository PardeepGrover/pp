<?phpnamespace Synapse\Carrental\Ui\Component\Listing\Columns;use Magento\Framework\View\Element\UiComponentFactory;use Magento\Framework\View\Element\UiComponent\ContextInterface;use Synapse\Carrental\Model\WarehousecontactsFactory;class ContactProfiles extends \Magento\Ui\Component\Listing\Columns\Column{
    private $_warehousecontactsFactory;		/**	 * Prepare Data Source	 *	 * @param array $dataSource	 * @return array	 */	/**     * CustomerActions constructor.     * @param ContextInterface $context     * @param UiComponentFactory $uiComponentFactory     * @param UrlInterface $urlBuilder     * @param array $components     * @param array $data     */    public function __construct(        ContextInterface $context,        UiComponentFactory $uiComponentFactory,		WarehousecontactsFactory $WarehousecontactsFactory,       array $components = [],        array $data = []    ) {		parent::__construct($context, $uiComponentFactory, $components, $data);		$this->_warehousecontactsFactory = $WarehousecontactsFactory;    }
    public function prepareDataSource(array $dataSource)	{	
        if (isset($dataSource['data']['items'])) {			$fieldName = $this->getData('name');						foreach ($dataSource['data']['items'] as &$item) {				if (isset($item[$fieldName])) {					$html = '';					$idarr = explode(',',$item[$fieldName]);					foreach($idarr as $_id){						$contactProfileModel = $this->_warehousecontactsFactory->create();						$cntres = $contactProfileModel->load($_id);						$html.= "<a target='_blank' href='" . $this->context->getUrl('carrental/contacts/edit/',['id'=>$_id]) . "'>";						$html .= $cntres->getProfileName();						$html .= "</a>";						$html .= " ";						unset($contactProfileModel);						unset($cntres);					}
                    
                    $item[$fieldName] = $html;
                }
            }
        }		return $dataSource;
    }
}

?>