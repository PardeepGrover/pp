<?phpnamespace Synapse\Carrental\Ui\Component\Listing\Columns;use Magento\Framework\View\Element\UiComponentFactory;use Magento\Framework\View\Element\UiComponent\ContextInterface;class YesNo extends \Magento\Ui\Component\Listing\Columns\Column{		const ONE = 'Yes';	const ZERO = 'No';		/**     * CustomerActions constructor.     * @param ContextInterface $context     * @param UiComponentFactory $uiComponentFactory     * @param UrlInterface $urlBuilder     * @param array $components     * @param array $data     */    public function __construct(        ContextInterface $context,        UiComponentFactory $uiComponentFactory,       array $components = [],        array $data = []    ) {		parent::__construct($context, $uiComponentFactory, $components, $data);    }	
    public function prepareDataSource(array $dataSource)	{	
        if (isset($dataSource['data']['items'])) {			$fieldName = $this->getData('name');						foreach ($dataSource['data']['items'] as &$item) {				if ($item[$fieldName] == 1) {						$content = self::ONE;				}else{					 $content = self::ZERO;										}				$container='';
                $container='<div class="fueltypes" style="width:102px !important;">';				$container.=$content;				$container.='</div>';				$item[$fieldName] = $container;
            }			
        }		return $dataSource;
    }
}

?>