<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

class FuelPType extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;
	
	 /**
     * @var UrlInterface
     */
    protected $_carrentalhelper;

    /**
     * CustomerActions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
		\Synapse\Carrental\Helper\Data $Helper,
	    array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
		$this->_carrentalhelper = $Helper;
		parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
			$types = $this->_carrentalhelper->getFuelPType();
			foreach ($dataSource['data']['items'] as & $item) {
				$newarr = [];
                if(!empty($item[$fieldName])){
					$key = array_search($item[$fieldName], array_column($types, 'value'));
					$container='<div class="fueltypes" style="width:102px !important;">';
					$container.=$types[$key]['label'];
					$container.='</div>';
					$item[$fieldName] = $container;
				} 
            }
		}
		return $dataSource;
       
    }
	 
}
