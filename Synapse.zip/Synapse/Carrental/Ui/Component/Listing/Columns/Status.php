<?phpnamespace Synapse\Carrental\Ui\Component\Listing\Columns;use Magento\Framework\View\Element\UiComponentFactory;use Magento\Framework\View\Element\UiComponent\ContextInterface;class Status extends \Magento\Ui\Component\Listing\Columns\Column{		const DISABLE = 'Disable';	const ENABLE = 'Enable';		/**     * CustomerActions constructor.     * @param ContextInterface $context     * @param UiComponentFactory $uiComponentFactory     * @param UrlInterface $urlBuilder     * @param array $components     * @param array $data     */    public function __construct(        ContextInterface $context,        UiComponentFactory $uiComponentFactory,       array $components = [],        array $data = []    ) {		parent::__construct($context, $uiComponentFactory, $components, $data);    }	
    public function prepareDataSource(array $dataSource)	{	
        if (isset($dataSource['data']['items'])) {			$fieldName = $this->getData('name');						foreach ($dataSource['data']['items'] as &$item) {				if (isset($item[$fieldName])) {					if ($item[$fieldName] == 0) {						$item[$fieldName] = self::DISABLE;					}					if ($item[$fieldName] == 1) {						$item[$fieldName] = self::ENABLE;					}
                }
            }
        }		return $dataSource;
    }
}

?>