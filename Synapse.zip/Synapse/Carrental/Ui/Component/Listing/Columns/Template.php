<?php
namespace Synapse\Carrental\Ui\Component\Listing\Columns;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
 
class Template extends \Magento\Ui\Component\Listing\Columns\Column
{
    const NAME = 'template';
 
    const ROW_FIELD = 'template_id';
 
 
    private $_getModel;
    /**
     * @var string
     */
    private $editUrl;
 
    private $_objectManager = null;
	protected $_carrentalhelper;
	protected $subTemplateId;
 
    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param \Webkul\Hello\Model\Image\Image $imageHelper
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        \Magento\Framework\UrlInterface $urlBuilder,
		\Synapse\Carrental\Helper\Data $carrentalHelper,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->urlBuilder = $urlBuilder;
		$this->_carrentalhelper = $carrentalHelper;
    }
 
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    
	public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {  
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
				$_templateId = $this->getRow($item) ?: '';
				$label = $this->getDailyRangesUsingTemplateId($_templateId,$item[$fieldName]);
                $item[$fieldName]= $label;	    			
			}
			 
        }
        return $dataSource;
    }
   /**
   * @param array $row
   *
   * @return null|string
   */
 protected function getRow($row)
 {
   $rowField = self::ROW_FIELD;
   return isset($row[$rowField]) ? $row[$rowField] : null;
 }
 public function getDailyRangesUsingTemplateId($template_id,$sub_template_id){
		$sub_template_id = (int)$sub_template_id;
		//echo $this->subTemplateId = $sub_template_id+1; die;
		$dailyranges = $this->_carrentalhelper->getDailyRanges();
		
		$dailyranges = $dailyranges[$template_id][$sub_template_id];
		return $dailyranges['label'];
		
	}
}