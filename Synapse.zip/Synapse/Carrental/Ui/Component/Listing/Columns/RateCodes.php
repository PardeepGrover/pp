<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;

/**
 * Class RateCodes
 * @package Magenest\RentalAndBookingSystem\Ui\Component\Listing\Columns
 */
class RateCodes extends Column
{
   
	private $_helper;

    /**
     * CustomerActions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
		\Synapse\Carrental\Helper\Data $carrentalhelper,
		array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
		$this->_helper = $carrentalhelper;
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
		
		if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
			
			foreach ($dataSource['data']['items'] as & $item) {
				if(!empty($item[$fieldName])){
					$ratecodes = [];
					$reatecodecoll = $this->_helper->getRateCodes();
					$reatecodecoll->addFieldToFilter('id',array('in'=>$item['assigned_rate_codes']));
					if($reatecodecoll){
						foreach($reatecodecoll as $_val):
							$ratecodes[] = $_val->getRatecodeName();
						endforeach;
						$item[$fieldName] = implode(',', $ratecodes);
					}
				}else{
					$item[$fieldName] ='----------';
					
				}
				 
            }
			unset($reatecodecoll);
			 
        }
		  return $dataSource;
       
    }
}
