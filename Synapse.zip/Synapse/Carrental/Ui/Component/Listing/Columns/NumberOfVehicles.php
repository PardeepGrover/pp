<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;
use Synapse\Carrental\Model\FleetcarmodelsFactory;

/**
 * Class NumberOfVehicles
 * @package  
 */
class NumberOfVehicles extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;
	/**
     * @var fleetcarmodelsFactory
     */
	protected $fleetcarmodelsFactory;
	

    /**
     * CustomerActions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
		FleetcarmodelsFactory $FleetcarmodelsFactory,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
	if (isset($dataSource['data']['items'])) {
		$fieldName = $this->getData('name');
		$count = '';
		foreach ($dataSource['data']['items'] as & $item) {
		   if(!empty($item[$fieldName])){
				$collection = $this->fleetcarmodelsFactory->create()->getCollection();
				$collection->addFieldToFilter('fleet_id',$item[$fieldName]);
				$collection->getSelect()->columns('count(car_model_id) as total');
				$collection->getSelect()->reset('group');
				$collection->getSelect()->group('main_table.fleet_id');
				$count = $collection->getFirstItem()->getTotal();
			}
			$item[$fieldName] = $count;
		}
		
	}
	return $dataSource;
       
    }
}
