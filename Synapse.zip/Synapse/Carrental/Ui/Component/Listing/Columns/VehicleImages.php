<?php
namespace Synapse\Carrental\Ui\Component\Listing\Columns;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
 
class VehicleImages extends \Magento\Ui\Component\Listing\Columns\Column
{
    const NAME = 'thumbnail';
 
    const ALT_FIELD = 'name';
 
 
    private $_getModel;
    /**
     * @var string
     */
    private $editUrl;
 
    private $_objectManager = null;
	private $_carmodelImages;
	private $_carmodelImagescoll;
    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param \Webkul\Hello\Model\Image\Image $imageHelper
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        \Synapse\Carrental\Model\CarModelImagesFactory $CarModelImagesFactory,
        \Magento\Framework\UrlInterface $urlBuilder,
       // \Magento\Framework\ObjectManagerInterface $objectManager,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->_carmodelImages = $CarModelImagesFactory;
        $this->urlBuilder = $urlBuilder;
		$this->_carmodelImagescoll = $this->_carmodelImages->create()->getCollection();
		$this->_carmodelImagescoll->getSelect()->joinLeft(
						['secondTable' => $this->_carmodelImagescoll->getTable('wais_carmodel')],
							'main_table.carmodel_id= secondTable.id', 
						['vehicle_name'] 
		);
      
    }
 
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
   
	public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {  
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
                $badgeArray=array();
				if(!empty($item[$fieldName])){
					$imagesContainer='<div class="vimages" style="width:150px !important;height:150px !important;">';
					$images = $this->_carmodelImagescoll->addFieldToFilter('carmodel_id',array('in'=> $item[$fieldName]));
					foreach ($images as $image) {
						$imageUrl = $image->getUrl();
						if(!$imageUrl){
							$imageUrl = $this->urlBuilder->getBaseUrl().'/pub/static/adminhtml/Magento/backend/en_US/Synapse_Carrental/images/noimage.gif';
						}
						$imagesContainer = $imagesContainer."<div class='' style='width:70px!important;float:left!important'><img src=". $imageUrl ."   style='display:inline-block;margin:2px;width:60px!important;height:60px !important;'/>";
						 $imagesContainer = $imagesContainer."<span>".$image->getVehicleName()."</span>";
						 $imagesContainer = $imagesContainer."</div>";
					}
					$imagesContainer = $imagesContainer.'</div>'; 
					$item[$fieldName]=$imagesContainer;
					$item[$fieldName.'_src'] = $imageUrl;
					$item[$fieldName.'_alt'] = $this->getAlt($item) ?: '';
					$item[$fieldName.'_orig_src'] = $imageUrl;
					$item[$fieldName . '_link'] = '#';
				}
            }
			 
        }
        return $dataSource;
    }
   /**
   * @param array $row
   *
   * @return null|string
   */
 protected function getAlt($row)
 {
   $altField = self::ALT_FIELD;
   return isset($row[$altField]) ? $row[$altField] : null;
 }
}