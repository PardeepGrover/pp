<?phpnamespace Synapse\Carrental\Ui\Component\Listing\Columns;use Magento\Framework\View\Element\UiComponentFactory;use Magento\Framework\View\Element\UiComponent\ContextInterface;use Synapse\Carrental\Model\FleetFactory;class AssignedFleets extends \Magento\Ui\Component\Listing\Columns\Column{
    private $_fleetFactory;		/**	 * Prepare Data Source	 *	 * @param array $dataSource	 * @return array	 */	/**     * CustomerActions constructor.     * @param ContextInterface $context     * @param UiComponentFactory $uiComponentFactory     * @param UrlInterface $urlBuilder     * @param array $components     * @param array $data     */    public function __construct(        ContextInterface $context,        UiComponentFactory $uiComponentFactory,		FleetFactory $FleetFactory,        array $components = [],        array $data = []    ) {		parent::__construct($context, $uiComponentFactory, $components, $data);		$this->_fleetFactory = $FleetFactory;    }
    public function prepareDataSource(array $dataSource)	{	
        if (isset($dataSource['data']['items'])) {			$fieldName = $this->getData('name');						foreach ($dataSource['data']['items'] as &$item) {				if (isset($item[$fieldName])) {					$html = '';					$idarr = explode(',',$item[$fieldName]);					foreach($idarr as $_id){						$fleetModel = $this->_fleetFactory->create();						$cntres = $fleetModel->load($_id);						$html.= "<a target='_blank' href='" . $this->context->getUrl('carrental/fleet/view/',['id'=>$_id]) . "'>";						$html .= $cntres->getFleetName();						$html .= "</a>";						$html .= "\n";						unset($fleetModel);						unset($cntres);					}
                    
                    $item[$fieldName] = $html;
                }
            }
        }		return $dataSource;
    }
}

?>