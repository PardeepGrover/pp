<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;
use Magento\Framework\Data\OptionSourceInterface;
use Magento\Framework\App\RequestInterface;
use Synapse\Carrental\Helper\Data as CarRentalHelper;


/**
 * Options tree for "regions" field
 */
class RegionOptions implements OptionSourceInterface
{
    /**
     * @var 
     */
    protected $categoryCollectionFactory;

    /**
     * @var RequestInterface
     */
    protected $request;

	protected $carrentalHelper;

    /**
     * 
     * @param RequestInterface $request
     */
    public function __construct(
		CarRentalHelper $CarRentalHelper,
        RequestInterface $request
    ) {
        $this->request = $request;
		$this->carrentalHelper = $CarRentalHelper;
    }

    /**
     * {@inheritdoc}
     */
    public function toOptionArray()
    {
	   return $this->carrentalHelper->getRegions();
    }

    
}
