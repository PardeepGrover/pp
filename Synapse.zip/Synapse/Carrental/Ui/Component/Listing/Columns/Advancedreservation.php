<?php

namespace Synapse\Carrental\Ui\Component\Listing\Columns;

class Advancedreservation implements \Magento\Framework\Option\ArrayInterface
{
    //Here you can __construct Model

    public function toOptionArray()
    {
		for($i=1;$i<=5;$i++):
				$arr[]['value'] = $i;
				$arr[]['label'] = $i.' day';
		endfor;
		
		return $arr;
    }
}