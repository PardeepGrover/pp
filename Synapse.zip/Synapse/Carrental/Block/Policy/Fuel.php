<?php
namespace Synapse\Carrental\Block\Policy;
use Synapse\Carrental\Model\WarehouseinfoFactory;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Model\RateCodeFactory;
use Synapse\Carrental\Model\VehiclepricelistFactory;
use Synapse\Carrental\Model\CarmodelsMileagePolicyFactory;
use Synapse\Carrental\Model\MileagePolicyCountryFactory;
use Synapse\Carrental\Model\CityFactory;
use Magento\Customer\Model\Session;
class Fuel extends  \Magento\Framework\View\Element\Template
{
	private $_warehouseInfoFactory;
	private $_fleetFactory;
	private $_rateCodeFactory;
	private $_customerSession;
	private $_vehiclepricelistFactory;
	/**
     * @var \Magento\Framework\App\Cache\Type\Config
     */
    protected $_configCacheType;
	/**
     * @var \Magento\Directory\Model\ResourceModel\Country\CollectionFactory
     */
    protected $_countryCollectionFactory;
	
	 /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;
	private $_cityFactory;
	private $_carmodelsPolicyFactory;
	private $_mileagePolicyCountryFactory;
	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
		\Magento\Framework\App\Cache\Type\Config $configCacheType,
		 \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
		WarehouseInfoFactory $WarehouseInfoFactory,
		Session $Session,
		FleetFactory $FleetFactory,
		RateCodeFactory $RateCodeFactory,
		VehiclepricelistFactory $VehiclepricelistFactory,
		CityFactory $CityFactory,
		CarmodelsMileagePolicyFactory $CarmodelsMileagePolicyFactory,
		MileagePolicyCountryFactory $MileagePolicyCountryFactory,
		 array $data = []
	){
		$this->_configCacheType = $configCacheType;
		$this->_customerSession = $Session;
		$this->_warehouseInfoFactory = $WarehouseInfoFactory;
		$this->_fleetFactory = $FleetFactory;
		$this->_rateCodeFactory = $RateCodeFactory;
		$this->_vehiclepricelistFactory = $VehiclepricelistFactory;
		$this->_countryCollectionFactory = $countryCollectionFactory;
		$this->_cityFactory = $CityFactory;
		$this->_carmodelsPolicyFactory = $CarmodelsMileagePolicyFactory;
		$this->_mileagePolicyCountryFactory = $MileagePolicyCountryFactory;
		parent::__construct($context, $data);
	
	}
	
	public function getSupplierWarehouses(){
		$warehouseInfoModel = $this->_warehouseInfoFactory->create();
		$collection = $warehouseInfoModel->getCollection();
		$collection->addFieldToFilter(
			'supplier_id',['eq'=>$this->getCustomerId()]
		);
		return $collection->getData();
	}
	public function getSupplierFleets(){
		$fleetModel = $this->_fleetFactory->create();
		$fleetCollection = $fleetModel->getCollection();
		$fleetCollection->addFieldToFilter(
			'main_table.supplier_id',['eq'=> $this->getCustomerId()]
		);
		return $fleetCollection->getData();
	}
	public function getCustomerId(){
		 
		return $this->_customerSession->getCustomer()->getId();
	}
	public function getSupplierRateCodes(){
		$ratecodeModel = $this->_rateCodeFactory->create();
		$collection =  $ratecodeModel->getCollection();
		$collection->addFieldToFilter(
			'supplier_id',['eq'=> $this->getCustomerId()]
		);
		return $collection->getData();
	}
	public function getSupplierPricelist(){
		$model = $this->_vehiclepricelistFactory->create();
		$collection = $model->getCollection();
		$collection->addFieldToFilter(
			'main_table.supplier_id',['eq'=> $this->getCustomerId()]
		);
		return $collection->getData();
	}
	public function getCountryHtmlSelect($defValue = null, $name = 'csc[0][country_id]', $id = 'country_id', $title = 'Country')
    {
        \Magento\Framework\Profiler::start('TEST: ' . __METHOD__, ['group' => 'TEST', 'method' => __METHOD__]);
        if ($defValue === null) {
            $defValue = $this->getCountryId();
        }
        $cacheKey = 'DIRECTORY_COUNTRY_SELECT_STORE_' . $this->_storeManager->getStore()->getCode();
        $cache = $this->_configCacheType->load($cacheKey);
        if ($cache) {
            $options = $this->getSerializer()->unserialize($cache);
        } else {
            $options = $this->getCountryCollection()
                ->setForegroundCountries($this->getTopDestinations())
                ->toOptionArray();
            $this->_configCacheType->save($this->getSerializer()->serialize($options), $cacheKey);
        }
        $html = $this->getLayout()->createBlock(
            \Magento\Framework\View\Element\Html\Select::class
        )->setName(
            $name
        )->setId(
            $id
        )->setClass(
            $id
        )->setTitle(
            __($title)
        )->setValue(
            $defValue
        )->setOptions(
            $options
        )->setExtraParams(
           // 'data-validate="{\'validate-select\':true}"'
		    
        )->getHtml();

        \Magento\Framework\Profiler::stop('TEST: ' . __METHOD__);
        return $html;
    }
	  /**
     * @return \Magento\Directory\Model\ResourceModel\Country\Collection
     */
    public function getCountryCollection()
    {
        $collection = $this->getData('country_collection');
        if ($collection === null) {
            $collection = $this->_countryCollectionFactory->create()->loadByStore();
            $this->setData('country_collection', $collection);
        }

        return $collection;
    }
	 /**
     * Get serializer
     *
     * @return \Magento\Framework\Serialize\SerializerInterface
     * @deprecated 100.2.0
     */
    private function getSerializer()
    {
        if ($this->serializer === null) {
            $this->serializer = \Magento\Framework\App\ObjectManager::getInstance()
                ->get(\Magento\Framework\Serialize\SerializerInterface::class);
        }
        return $this->serializer;
    }
	public function addMileagePolicyUrl(){
		
		return $this->getUrl('carrental/Mileagepolicy/add');
	}
	public function addFuelPolicyUrl(){
		return $this->getUrl('carrental/Fuelpolicy/add');
	}
	
	public function getActionUrl(){
		return $this->getUrl('carrental/mileagepolicy/save');
	}
	
	public function getFuelActionUrl(){
		return $this->getUrl('carrental/fuelpolicy/save');
	}
	public function getAssignedCarsInPolicy(){
		$carMileagemodel = $this->_carmodelsPolicyFactory->create();
		$collection      = $carMileagemodel->getCollection();
		$collection->addFieldToFilter('supplier_id',['eq'=>$this->getCustomerId()]);
		$collection->addFieldToFilter(
			'mileage_id',
			['eq'=>$this->getRequest()->getParam('id')]
		);
		
		
		$collection->addFieldToSelect('id');
		$collection->addFieldToSelect('mileage_id');
		$collection->addFieldToSelect('car_model_id');
		$collection->getSelect()->joinLeft(
			['cartable'=>$collection->getTable('wais_carmodel')],
			'cartable.id =main_table.car_model_id',
			['cartable.vehicle_name']
		
		);
		$collection->getSelect()->joinLeft(
			['carimages'=>$collection->getTable('wais_carmodel_images')],
			'carimages.carmodel_id =main_table.car_model_id',
			['carimages.url']
		
		);
		return $collection;
		
	}
	public function getAssignedCountryInPolicy(){
		$countryMileagemodel = $this->_mileagePolicyCountryFactory->create();
		$collection      = $countryMileagemodel->getCollection();
		$collection->addFieldToSelect('country_id');
		$collection->addFieldToSelect('region_id');
		$collection->addFieldToSelect('city_id');
		$collection->addFieldToSelect('mileage_id');
		$collection->addFieldToFilter('supplier_id',['eq'=>$this->getCustomerId()]);
		$collection->addFieldToFilter(
			'mileage_id',
			['eq'=>$this->getRequest()->getParam('id')]
		);
		$collection->getSelect()->joinLeft(
			['regionname'=>$collection->getTable('directory_country_region_name')],
			'regionname.region_id =main_table.region_id',
			['regionname.name']
		
		);
		$collection->getSelect()->joinLeft(
			['city'=>$collection->getTable('directory_country_region_city')],
			'city.city_id =main_table.city_id',
			['city.city_id']
		
		); 
		$collection->getSelect()->columns(
			[
				'city_name' => 'IF(city.city_id != "0",city_name, "ALL")',
				'country_id' => 'IF(main_table.country_id != "0",main_table.country_id, "ALL")',
				'region_name' => 'IF(regionname.region_id != "0",regionname.region_id, "ALL")'
			]
		);
		return $collection;
		
	}
	public function getBackUrlToMileage(){
		return $this->getUrl('carrental/mileagepolicy/');
	}
	
	
}
