<?php
namespace Synapse\Carrental\Block\Adminhtml\CarModel;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
class Fuel extends Template implements  \Magento\Framework\Data\OptionSourceInterface
{
	private $_helper;
	public function __construct(
		Context $context,
		\Synapse\Carrental\Helper\Data $helper,
		array $data = []
	) {
	
		parent::__construct($context, $data);
		$this->_helper = $helper;
        }
    public function toOptionArray()
    {
        return $this->getFuel();
	}
	public function getFuel()
	{
		return $this->_helper->getFuel(); 
	}
 
}

