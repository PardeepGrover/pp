<?php
namespace Synapse\Carrental\Block\Adminhtml\CarModel;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
class Category extends Template implements  \Magento\Framework\Data\OptionSourceInterface
{
	private $_helper;
	private $_carModelImagesFactory;
	private $_categoriesoptions;
	public function __construct(
		Context $context,
		\Synapse\Carrental\Helper\Data $helper,
		\Synapse\Carrental\Model\CarModelImagesFactory $CarModelImagesFactory,
		\Magento\Catalog\Ui\Component\Product\Form\Categories\Options $categoriesOptions,
		array $data = []
	) {
	
		parent::__construct($context, $data);
		$this->_helper = $helper;
		$this->_carModelImagesFactory = $CarModelImagesFactory;
		$this->_categoriesoptions = $categoriesOptions;
        }
    public function toOptionArray()
    {
        return $this->getCategory();
	}
	public function getCategory()
	{
		return $this->_helper->getCategory(); 
	}
	public function getImages(){
		$id = $this->getRequest()->getParam('id');
		$imageCollection = '';
		$model = $this->_carModelImagesFactory->create();
		$imageCollection = $model->getCollection();
		$imageCollection->addFieldToFilter('carmodel_id',$id);
		return $imageCollection;
		
	}
	public function getAjaxUrl(){
		 return $this->getUrl("carrental/carmodel/deleteimages"); // Controller Url
	}
	public function getAjaxBaseImageUrl(){
		 return $this->getUrl("carrental/carmodel/setbaseimage"); // Controller Url
		
	}
	public function getRegions(){
	  return $this->_helper->getRegions();
	}
	public function getCategories(){
		$model = $this->_categoriesoptions;
		return $model->toOptionArray();
	}
 
}

