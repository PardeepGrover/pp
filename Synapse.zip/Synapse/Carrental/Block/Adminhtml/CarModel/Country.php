<?php
namespace Synapse\Carrental\Block\Adminhtml\CarModel;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
class Country extends Template implements  \Magento\Framework\Data\OptionSourceInterface
{
	private $_helper;
	private $_countryCollectionFactory;
	public function __construct(
		Context $context,
		\Synapse\Carrental\Helper\Data $helper,
		\Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
		array $data = []
	) {
	
		parent::__construct($context, $data);
		$this->_helper = $helper;
		$this->_countryCollectionFactory = $countryCollectionFactory;
        }
    public function toOptionArray()
    {
        return $this->getCountryCollection();
	}
	 
	public function getCountryCollection()
	{
		$collection = $this->_countryCollectionFactory->create()->loadByStore();
		$options = $collection
                ->setForegroundCountries($this->getTopDestinations())
                ->toOptionArray();
		return $options;
	}
}

