<?php
namespace Synapse\Carrental\Block\Adminhtml\CarModel;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
class VehicleType extends Template implements  \Magento\Framework\Data\OptionSourceInterface
{
	private $_helper;
	public function __construct(
		Context $context,
		\Synapse\Carrental\Helper\Data $helper,
		array $data = []
	) {
	
		parent::__construct($context, $data);
		$this->_helper = $helper;
        }
    public function toOptionArray()
    {
        return $this->getVehicleType();
	}
	public function getVehicleType()
	{
		return $this->_helper->getVehicleType(); 
	}
 
}

