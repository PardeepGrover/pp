<?php 
namespace Synapse\Carrental\Block\Adminhtml\Location;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
class Updater extends Template
{
	private $_helper;
	protected $_jsonhelper;
	public function __construct(
		Context $context,
		\Synapse\Carrental\Helper\Data $helper,
		\Magento\Framework\Json\Helper\Data $jsonHelper,
		array $data = []
	){
	
		parent::__construct($context, $data);
		$this->_helper = $helper;
		$this->_jsonhelper = $jsonHelper;
    }
	public function cityJson(){
		$finalarr =  [];
		$cityCollection =  $this->_helper->getCityJson();
		if($cityCollection){
			foreach($cityCollection as $_val){
				$finalarr[$_val->getCountryId()][] = $_val->getData();
			}
		} 
		//$encoder = $this->_jsonhelper->jsonEncode($finalarr);
		//return $encoder;
		return $finalarr;
	}
	
}