<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Synapse\Carrental\Block\Product;

use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Block\Product\ProductList\Toolbar;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\Config;
use Magento\Catalog\Model\Layer;
use Magento\Catalog\Model\Layer\Resolver;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Catalog\Pricing\Price\FinalPrice;
use Magento\Eav\Model\Entity\Collection\AbstractCollection;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\Config\Element;
use Magento\Framework\Data\Helper\PostHelper;
use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Pricing\Render;
use Magento\Framework\Url\Helper\Data;
use Magento\Framework\Registry;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;

/**
 * Product list
 * @api
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 100.0.2
 */
class Map  extends \Magento\Catalog\Block\Product\AbstractProduct implements IdentityInterface
{
     /**
     * Default toolbar block name
     *
     * @var string
     */
    protected $_defaultToolbarBlock = Toolbar::class;

    /**
     * Product Collection
     *
     * @var AbstractCollection
     */
    protected $_productCollection;

    /**
     * Catalog layer
     *
     * @var Layer
     */
    protected $_catalogLayer;

    /**
     * @var PostHelper
     */
    protected $_postDataHelper;

    /**
     * @var Data
     */
    protected $urlHelper;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;
	protected $productCol;
	/**
     * @var ImageBuilder
     * @since 101.1.0
     */
    protected $imageBuilder;
	
	protected $_coreRegistry;
	
	protected $vehicleseasonalpriceFactory;
	
	/**
     * @var _mapCountry
     */
    protected $_mapCountry = 'UK';
	
		/**
     * @var _mapCity
     */
    protected $_mapCity = 'London';
	
	
		/**
     * @var _mapCity
     */
    protected $locationFactory;
	
	
		/**
     * @var _mapCity
     */
    protected $vehicleFactory;
	
	protected $urlInterface;
	
	protected $request;
	
	protected $_searchLocations;
    /**
     * @param Context $context
     * @param PostHelper $postDataHelper
     * @param Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @param Data $urlHelper
     * @param array $data
     */
    public function __construct(
		\Magento\Catalog\Block\Product\Context $context,
        PostHelper $postDataHelper,
        Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository,
        Data $urlHelper,
		Collection $productCollection,
		\Magento\Catalog\Block\Product\ImageBuilder $ImageBuilder,
		Registry $Registry,
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
		\Synapse\Carrental\Model\LocationFactory $location,
		\Synapse\Carrental\Model\VehicleDirectory $vehicle,
		 \Magento\Framework\UrlInterface $urlInterface, 
		\Magento\Framework\App\Request\Http $request,
        array $data = []
    ) {
        $this->_catalogLayer = $layerResolver->get();
        $this->_postDataHelper = $postDataHelper;
        $this->categoryRepository = $categoryRepository;
        $this->urlHelper = $urlHelper;
		$this->productCol = $productCollection;
		$this->imageBuilder = $ImageBuilder;
		$this->_coreRegistry   =  $Registry;
		$this->locationFactory   = $location;
		$this->vehicleFactory   = $vehicle;
		$this->request   = $request;
		$this->vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
		$this->urlInterface = $urlInterface;
		
		
        parent::__construct(
            $context,
            $data
        );
    }

	
	public function getCurrentCountry(){
		return $this->_mapCountry;
	}
	
	
	public function getCurrentCity(){
		return $this->_mapCity;
	}
	
	
	public function _getCarsCount($location_id = null){
		if($location_id){
			
			
			/*SELECT count(magwaissupplier_vehicle_direrctory.supplier_id) as cars_count, magwais_supplier_service_location.pickup_location_id  FROM `magwaissupplier_vehicle_direrctory` LEFT JOIN `magwais_supplier_service_location` ON FIND_IN_SET(magwaissupplier_vehicle_direrctory.supplier_id, magwais_supplier_service_location.supplier_id) WHERE magwais_supplier_service_location.pickup_location_id = 1 */
			
			$vehiclesCollection = $this->vehicleFactory->getCollection();
		
	//	echo $vehicleFactory->getSelect()->__toString(); die;		
		      //$vehiclesCollection->getSelect()->reset();
		
		
			$vehiclesCollection->getSelect()->joinLeft(
				['magwais_supplier_service_location'=>$vehiclesCollection->getTable('magwais_supplier_service_location')],
				'FIND_IN_SET(main_table.supplier_id, magwais_supplier_service_location.supplier_id)',
				['count(*) as car_count']
		
			);
			$vehiclesCollection->getSelect()->where('pickup_location_id = ?',$location_id);
			
			return $vehiclesCollection->count();
			
		}
		return null;
	}
	
	public function getAvailableLocations(){
		
		
		
		
		
		if(!$this->_searchLocations){
				$searchLocations = $this->locationFactory->create()->getCollection();
				$searchLocations->getSelect()->joinRight(
					['services'=>$searchLocations->getTable('magwais_supplier_service_location')],
					'FIND_IN_SET(main_table.locality_id, services.pickup_location_id)',
					[
					'count(services.supplier_id) as supplier_count','pickup_location_id'
					]
			
				);
				$searchLocations->getSelect()->group('main_table.locality_id');

			
				//echo $searchLocations->getSelect()->__toString(); die;		
				$city = $this->request->getParam('city');
				//TODO add city filter
				
				if($city!=''){
					//echo $city; die; 
					//$locationCollection->addFieldToFilter('city','London');
				}
				$this->_searchLocations = $searchLocations;
		}
	
			
			
			
		return $this->_searchLocations;
	}
	
	public function getLocationListJson(){
		
		if($_SERVER['REMOTE_ADDR']=='121.242.47.194'){
			
			
		
			
		}
		$locations = array();
		$locationCollection = $this->getAvailableLocations();
		
		foreach($locationCollection as $_location){
			
			$url =  $this->urlInterface->getUrl('carrental/home/search',array('location_id'=>$_location->getId()));
			
			$locations[] =  array(
				"name"=>$_location->getLocationName(),
				"lat"=>$_location->getLatitude(),
				"lon"=> $_location->getLongitude(),
				"closed"=>false,
				"locType"=>$_location->getLocationType(),
				"address"=>$_location->getAddress(),
				"fromPrice"=>"$46.21",
				"cars_count"=>$this->_getCarsCount(),
				"supplier_count"=>$_location->getSupplierCount(),
				"action"=>$url
			);
		}
		
		/*
		
		$locations[] =  array(
			"name"=>"London Luton Airport 2",
			"lat"=> 51.87993,
			"lon"=> -0.377165,
			"closed"=>false,
			"locType"=>"AIRPORT",
			"address"=>"President Way, London, UK, LU2 9LY",
			"fromPrice"=>"$36,21",
			"action"=>""
		);
		
		$locations[] =  array(
			"name"=>"London Luton Airport 3",
			"lat"=> 51.87993,
			"lon"=> -0.377165,
			"closed"=>false,
			"locType"=>"AIRPORT",
			"address"=>"President Way, London, UK, LU2 9LY",
			"fromPrice"=>"$36,21",
			"action"=>""
		);
		*/
		return json_encode($locations);
	}
	
	
	
	public function getSuppliersCountForLocation(){
		
		return 6;
	}
	
    /**
     * Retrieve loaded product collection
     *
     * The goal of this method is to choose whether the existing collection should be returned
     * or a new one should be initialized.
     *
     * It is not just a caching logic, but also is a real logical check
     * because there are two ways how collection may be stored inside the block:
     *   - Product collection may be passed externally by 'setCollection' method
     *   - Product collection may be requested internally from the current Catalog Layer.
     *
     * And this method will return collection anyway,
     * even when it did not pass externally and therefore isn't cached yet
     *
     * @return AbstractCollection
     */
    protected function _getProductCollection()
    {
        if ($this->_productCollection === null) {
		 
           $this->_productCollection = $this->initializeProductCollection();
		   /*$collection = $this->_productCollection;
		   $productIds =  $this->_coreRegistry->registry('product_ids');
		   $productIds = '46';
		   $collection->addAttributeToFilter('entity_id',array('in'=>$productIds));
		  
		   $this->_productCollection =$collection*/;
        }

        return $this->_productCollection;
    }

    /**
     * Get catalog layer model
     *
     * @return Layer
     */
    public function getLayer()
    {
        return $this->_catalogLayer;
    }

    /**
     * Retrieve loaded category collection
     *
     * @return AbstractCollection
     */
    public function getLoadedProductCollection()
    {
        return $this->_getProductCollection();
    }

    /**
     * Retrieve current view mode
     *
     * @return string
     */
    public function getMode()
    {
        if ($this->getChildBlock('toolbar')) {
            return $this->getChildBlock('toolbar')->getCurrentMode();
        }

        return $this->getDefaultListingMode();
    }

    /**
     * Get listing mode for products if toolbar is removed from layout.
     * Use the general configuration for product list mode from config path catalog/frontend/list_mode as default value
     * or mode data from block declaration from layout.
     *
     * @return string
     */
    private function getDefaultListingMode()
    {
        // default Toolbar when the toolbar layout is not used
        $defaultToolbar = $this->getToolbarBlock();
        $availableModes = $defaultToolbar->getModes();

        // layout config mode
        $mode = $this->getData('mode');

        if (!$mode || !isset($availableModes[$mode])) {
            // default config mode
            $mode = $defaultToolbar->getCurrentMode();
        }

        return $mode;
    }

    /**
     * Need use as _prepareLayout - but problem in declaring collection from
     * another block (was problem with search result)
     * @return $this
     */
    protected function _beforeToHtml()
    {
        $collection = $this->_getProductCollection();
		$this->addToolbarBlock($collection);
		$collection->load();

        return parent::_beforeToHtml();
    }

    /**
     * Add toolbar block from product listing layout
     *
     * @param Collection $collection
     */
    private function addToolbarBlock(Collection $collection)
    {
        $toolbarLayout = $this->getToolbarFromLayout();

        if ($toolbarLayout) {
            $this->configureToolbar($toolbarLayout, $collection);
        }
    }

    /**
     * Retrieve Toolbar block from layout or a default Toolbar
     *
     * @return Toolbar
     */
    public function getToolbarBlock()
    {
        $block = $this->getToolbarFromLayout();

        if (!$block) {
            $block = $this->getLayout()->createBlock($this->_defaultToolbarBlock, uniqid(microtime()));
        }

        return $block;
    }

    /**
     * Get toolbar block from layout
     *
     * @return bool|Toolbar
     */
    private function getToolbarFromLayout()
    {
        $blockName = $this->getToolbarBlockName();

        $toolbarLayout = false;

        if ($blockName) {
            $toolbarLayout = $this->getLayout()->getBlock($blockName);
        }

        return $toolbarLayout;
    }

    /**
     * Retrieve additional blocks html
     *
     * @return string
     */
    public function getAdditionalHtml()
    {
        return $this->getChildHtml('additional');
    }

    /**
     * Retrieve list toolbar HTML
     *
     * @return string
     */
    public function getToolbarHtml()
    {
        return $this->getChildHtml('toolbar');
    }

    /**
     * @param AbstractCollection $collection
     * @return $this
     */
    public function setCollection($collection)
    {
        $this->_productCollection = $collection;
        return $this;
    }

    /**
     * @param array|string|integer| Element $code
     * @return $this
     */
    public function addAttribute($code)
    {
        $this->_getProductCollection()->addAttributeToSelect($code);
        return $this;
    }

    /**
     * @return mixed
     */
    public function getPriceBlockTemplate()
    {
        return $this->_getData('price_block_template');
    }

    /**
     * Retrieve Catalog Config object
     *
     * @return Config
     */
    protected function _getConfig()
    {
        return $this->_catalogConfig;
    }

    /**
     * Prepare Sort By fields from Category Data
     *
     * @param Category $category
     * @return $this
     */
    public function prepareSortableFieldsByCategory($category)
    {
        if (!$this->getAvailableOrders()) {
            $this->setAvailableOrders($category->getAvailableSortByOptions());
        }
        $availableOrders = $this->getAvailableOrders();
        if (!$this->getSortBy()) {
            $categorySortBy = $this->getDefaultSortBy() ?: $category->getDefaultSortBy();
            if ($categorySortBy) {
                if (!$availableOrders) {
                    $availableOrders = $this->_getConfig()->getAttributeUsedForSortByArray();
                }
                if (isset($availableOrders[$categorySortBy])) {
                    $this->setSortBy($categorySortBy);
                }
            }
        }

        return $this;
    }

    /**
     * Return identifiers for produced content
     *
     * @return array
     */
    public function getIdentities()
    {
        $identities = [];

        $category = $this->getLayer()->getCurrentCategory();
        if ($category) {
            $identities[] = Product::CACHE_PRODUCT_CATEGORY_TAG . '_' . $category->getId();
        }

        //Check if category page shows only static block (No products)
        if ($category->getData('display_mode') == Category::DM_PAGE) {
            return $identities;
        }

        foreach ($this->_getProductCollection() as $item) {
            $identities = array_merge($identities, $item->getIdentities());
        }

        return $identities;
    }

    /**
     * Get post parameters
     *
     * @param Product $product
     * @return string
     */
    public function getAddToCartPostParams(Product $product)
    {
        $url = $this->getAddToCartUrl($product);
        return [
            'action' => $url,
            'data' => [
                'product' => $product->getEntityId(),
                ActionInterface::PARAM_NAME_URL_ENCODED => $this->urlHelper->getEncodedUrl($url),
            ]
        ];
    }

    /**
     * @param Product $product
     * @return string
     */
    public function getProductPrice(Product $product)
    {
        $priceRender = $this->getPriceRender();

        $price = '';
        if ($priceRender) {
            $price = $priceRender->render(
                FinalPrice::PRICE_CODE,
                $product,
                [
                    'include_container' => true,
                    'display_minimal_price' => true,
                    'zone' => Render::ZONE_ITEM_LIST,
                    'list_category_page' => true
                ]
            );
        }

        return $price;
    }

    /**
     * Specifies that price rendering should be done for the list of products
     * i.e. rendering happens in the scope of product list, but not single product
     *
     * @return Render
     */
    protected function getPriceRender()
    {
        return $this->getLayout()->getBlock('product.price.render.default')
            ->setData('is_product_list', true);
    }

    /**
     * Configures product collection from a layer and returns its instance.
     *
     * Also in the scope of a product collection configuration, this method initiates configuration of Toolbar.
     * The reason to do this is because we have a bunch of legacy code
     * where Toolbar configures several options of a collection and therefore this block depends on the Toolbar.
     *
     * This dependency leads to a situation where Toolbar sometimes called to configure a product collection,
     * and sometimes not.
     *
     * To unify this behavior and prevent potential bugs this dependency is explicitly called
     * when product collection initialized.
     *
     * @return Collection
     */
    private function initializeProductCollection()
    {
        $layer = $this->getLayer();
        /* @var $layer Layer */
        if ($this->getShowRootCategory()) {
            $this->setCategoryId($this->_storeManager->getStore()->getRootCategoryId());
        }

        // if this is a product view page
        /*if ($this->_coreRegistry->registry('product')) {
            // get collection of categories this product is associated with
            $categories = $this->_coreRegistry->registry('product')
                ->getCategoryCollection()->setPage(1, 1)
                ->load();
            // if the product is associated with any category
            if ($categories->count()) {
                // show products from this category
                $this->setCategoryId(current($categories->getIterator())->getId());
            }
        }*/

        $origCategory = null;
		$this->setCategoryId(4);
        if ($this->getCategoryId()) {
			 
            try {
                $category = $this->categoryRepository->get($this->getCategoryId());
            } catch (NoSuchEntityException $e) {
                $category = null;
            }

            if ($category) {
                $origCategory = $layer->getCurrentCategory();
                $layer->setCurrentCategory($category);
            }
        }
        $collection = $layer->getProductCollection();
		$productIds =  $this->_coreRegistry->registry('product_ids');
		$collection->addAttributeToFilter('entity_id',array('in'=>$productIds));
		  
        //$this->prepareSortableFieldsByCategory($layer->getCurrentCategory());

        if ($origCategory) {
           // $layer->setCurrentCategory($origCategory);
        }
        
        $this->addToolbarBlock($collection);

        $this->_eventManager->dispatch(
            'catalog_block_product_list_collection',
            ['collection' => $collection]
        );

        return $collection;
    }

    /**
     * Configures the Toolbar block with options from this block and configured product collection.
     *
     * The purpose of this method is the one-way sharing of different sorting related data
     * between this block, which is responsible for product list rendering,
     * and the Toolbar block, whose responsibility is a rendering of these options.
     *
     * @param ProductList\Toolbar $toolbar
     * @param Collection $collection
     * @return void
     */
    private function configureToolbar(Toolbar $toolbar, Collection $collection)
    {
        // use sortable parameters
        $orders = $this->getAvailableOrders();
        if ($orders) {
            $toolbar->setAvailableOrders($orders);
        }
        $sort = $this->getSortBy();
        if ($sort) {
            $toolbar->setDefaultOrder($sort);
        }
        $dir = $this->getDefaultDirection();
        if ($dir) {
            $toolbar->setDefaultDirection($dir);
        }
        $modes = $this->getModes();
        if ($modes) {
            $toolbar->setModes($modes);
        }
        // set collection to toolbar and apply sort
        $toolbar->setCollection($collection);
        $this->setChild('toolbar', $toolbar);
    }
	 public function getImage($product, $imageId, $attributes = [])
    {
		if ($this->_coreRegistry->registry('product')) {
			
		}
        return $this->imageBuilder->setProduct($product)
            ->setImageId($imageId)
            ->setAttributes($attributes)
            ->create();
    }
	public function getCarModelDetails($productId){
		if($productId){
				$seasonlpriceModel 		=  $this->vehicleseasonalpriceFactory->create();
				$seasonlpriceCollection =  $seasonlpriceModel->getCollection();
				$seasonlpriceCollection->addFieldToFilter('main_table.product_id',array('eq'=>$productId));
				$seasonlpriceCollection->getSelect()->joinLeft(
					['carmodelatt'=>$seasonlpriceCollection->getTable('wais_carmodel_attributes')],
					'carmodelatt.carmodel_id=main_table.car_model_id',
					['carmodelatt.*','main_table.*']
				);
				$seasonlpriceCollection->getSelect()->joinLeft(
					['carmodel'=>$seasonlpriceCollection->getTable('wais_carmodel')],
					'carmodelatt.carmodel_id=carmodel.id',
					['carmodelatt.*','main_table.*','carmodel.vehicle_category_type','carmodel.vehicle_type']
				);
				$seasonlpriceCollection->getSelect()->group('main_table.product_id');
				//var_dump($seasonlpriceCollection->getSelect()->__toString());
			return $seasonlpriceCollection;
		}
		return false;
	}
}