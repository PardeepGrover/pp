<?php
/**
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Synapse\Carrental\Block\Product;

use Magento\Catalog\Api\CategoryRepositoryInterface;
use Magento\Catalog\Block\Product\ProductList\Toolbar;
use Magento\Catalog\Model\Category;
use Magento\Catalog\Model\Config;
use Magento\Catalog\Model\Layer;
use Magento\Catalog\Model\Layer\Resolver;
use Magento\Catalog\Model\Product;
use Magento\Catalog\Model\ResourceModel\Product\Collection;
use Magento\Catalog\Pricing\Price\FinalPrice;
use Magento\Eav\Model\Entity\Collection\AbstractCollection;
use Magento\Framework\App\ActionInterface;
use Magento\Framework\App\Config\Element;
use Magento\Framework\Data\Helper\PostHelper;
use Magento\Framework\DataObject\IdentityInterface;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Pricing\Render;
use Magento\Framework\Url\Helper\Data;
use Magento\Framework\Registry;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
use Synapse\Carrental\Model\CarmodelsMileagePolicyFactory;

/**
 * Product list
 * @api
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 * @since 100.0.2
 */
class ListProduct  extends \Magento\Catalog\Block\Product\AbstractProduct implements IdentityInterface
{
    /**
     * Default toolbar block name
     *
     * @var string
     */
    protected $_defaultToolbarBlock = Toolbar::class;

    /**
     * Product Collection
     *
     * @var AbstractCollection
     */
    protected $_productCollection;

    /**
     * Catalog layer
     *
     * @var Layer
     */
    protected $_catalogLayer;

    /**
     * @var PostHelper
     */
    protected $_postDataHelper;

    /**
     * @var Data
     */
    protected $urlHelper;

    /**
     * @var CategoryRepositoryInterface
     */
    protected $categoryRepository;
	protected $productCol;
	/**
     * @var ImageBuilder
     * @since 101.1.0
     */
    protected $imageBuilder;
	
	protected $_coreRegistry;
	
	protected $vehicleseasonalpriceFactory;
	private $_carmodelsMileagePolicyFactory;
	private $_carrentalelper;

    /**
     * @param Context $context
     * @param PostHelper $postDataHelper
     * @param Resolver $layerResolver
     * @param CategoryRepositoryInterface $categoryRepository
     * @param Data $urlHelper
     * @param array $data
     */
    public function __construct(
		\Magento\Catalog\Block\Product\Context $context,
        PostHelper $postDataHelper,
        Resolver $layerResolver,
        CategoryRepositoryInterface $categoryRepository,
        Data $urlHelper,
		Collection $productCollection,
		\Magento\Catalog\Block\Product\ImageBuilder $ImageBuilder,
		Registry $Registry,
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
		CarmodelsMileagePolicyFactory $CarmodelsMileagePolicyFactory,
		\Synapse\Carrental\Helper\Data $Helper,
        array $data = []
    ) {
        $this->_catalogLayer = $layerResolver->get();
        $this->_postDataHelper = $postDataHelper;
        $this->categoryRepository = $categoryRepository;
        $this->urlHelper = $urlHelper;
		$this->productCol = $productCollection;
		$this->imageBuilder = $ImageBuilder;
		$this->_coreRegistry   = $Registry;
		$this->vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
		$this->_carmodelsMileagePolicyFactory = $CarmodelsMileagePolicyFactory;
		$this->_carrentalelper = $Helper;
        parent::__construct(
            $context,
            $data
        );
    }

    /**
     * Retrieve loaded product collection
     *
     * The goal of this method is to choose whether the existing collection should be returned
     * or a new one should be initialized.
     *
     * It is not just a caching logic, but also is a real logical check
     * because there are two ways how collection may be stored inside the block:
     *   - Product collection may be passed externally by 'setCollection' method
     *   - Product collection may be requested internally from the current Catalog Layer.
     *
     * And this method will return collection anyway,
     * even when it did not pass externally and therefore isn't cached yet
     *
     * @return AbstractCollection
     */
    protected function _getProductCollection()
    {
        if ($this->_productCollection === null) {
		 
           $this->_productCollection = $this->initializeProductCollection();
		   /*$collection = $this->_productCollection;
		   $productIds =  $this->_coreRegistry->registry('product_ids');
		   $productIds = '46';
		   $collection->addAttributeToFilter('entity_id',array('in'=>$productIds));
		  
		   $this->_productCollection =$collection*/;
        }

        return $this->_productCollection;
    }

    /**
     * Get catalog layer model
     *
     * @return Layer
     */
    public function getLayer()
    {
        return $this->_catalogLayer;
    }

    /**
     * Retrieve loaded category collection
     *
     * @return AbstractCollection
     */
    public function getLoadedProductCollection()
    {
        return $this->_getProductCollection();
    }

    /**
     * Retrieve current view mode
     *
     * @return string
     */
    public function getMode()
    {
        if ($this->getChildBlock('toolbar')) {
            return $this->getChildBlock('toolbar')->getCurrentMode();
        }

        return $this->getDefaultListingMode();
    }

    /**
     * Get listing mode for products if toolbar is removed from layout.
     * Use the general configuration for product list mode from config path catalog/frontend/list_mode as default value
     * or mode data from block declaration from layout.
     *
     * @return string
     */
    private function getDefaultListingMode()
    {
        // default Toolbar when the toolbar layout is not used
        $defaultToolbar = $this->getToolbarBlock();
        $availableModes = $defaultToolbar->getModes();

        // layout config mode
        $mode = $this->getData('mode');

        if (!$mode || !isset($availableModes[$mode])) {
            // default config mode
            $mode = $defaultToolbar->getCurrentMode();
        }

        return $mode;
    }

    /**
     * Need use as _prepareLayout - but problem in declaring collection from
     * another block (was problem with search result)
     * @return $this
     */
    protected function _beforeToHtml()
    {
        $collection = $this->_getProductCollection();
		$this->addToolbarBlock($collection);
		$collection->load();

        return parent::_beforeToHtml();
    }

    /**
     * Add toolbar block from product listing layout
     *
     * @param Collection $collection
     */
    private function addToolbarBlock(Collection $collection)
    {
        $toolbarLayout = $this->getToolbarFromLayout();

        if ($toolbarLayout) {
            $this->configureToolbar($toolbarLayout, $collection);
        }
    }

    /**
     * Retrieve Toolbar block from layout or a default Toolbar
     *
     * @return Toolbar
     */
    public function getToolbarBlock()
    {
        $block = $this->getToolbarFromLayout();

        if (!$block) {
            $block = $this->getLayout()->createBlock($this->_defaultToolbarBlock, uniqid(microtime()));
        }

        return $block;
    }

    /**
     * Get toolbar block from layout
     *
     * @return bool|Toolbar
     */
    private function getToolbarFromLayout()
    {
        $blockName = $this->getToolbarBlockName();

        $toolbarLayout = false;

        if ($blockName) {
            $toolbarLayout = $this->getLayout()->getBlock($blockName);
        }

        return $toolbarLayout;
    }

    /**
     * Retrieve additional blocks html
     *
     * @return string
     */
    public function getAdditionalHtml()
    {
        return $this->getChildHtml('additional');
    }

    /**
     * Retrieve list toolbar HTML
     *
     * @return string
     */
    public function getToolbarHtml()
    {
        return $this->getChildHtml('toolbar');
    }

    /**
     * @param AbstractCollection $collection
     * @return $this
     */
    public function setCollection($collection)
    {
        $this->_productCollection = $collection;
        return $this;
    }

    /**
     * @param array|string|integer| Element $code
     * @return $this
     */
    public function addAttribute($code)
    {
        $this->_getProductCollection()->addAttributeToSelect($code);
        return $this;
    }

    /**
     * @return mixed
     */
    public function getPriceBlockTemplate()
    {
        return $this->_getData('price_block_template');
    }

    /**
     * Retrieve Catalog Config object
     *
     * @return Config
     */
    protected function _getConfig()
    {
        return $this->_catalogConfig;
    }

    /**
     * Prepare Sort By fields from Category Data
     *
     * @param Category $category
     * @return $this
     */
    public function prepareSortableFieldsByCategory($category)
    {
        if (!$this->getAvailableOrders()) {
            $this->setAvailableOrders($category->getAvailableSortByOptions());
        }
        $availableOrders = $this->getAvailableOrders();
        if (!$this->getSortBy()) {
            $categorySortBy = $this->getDefaultSortBy() ?: $category->getDefaultSortBy();
            if ($categorySortBy) {
                if (!$availableOrders) {
                    $availableOrders = $this->_getConfig()->getAttributeUsedForSortByArray();
                }
                if (isset($availableOrders[$categorySortBy])) {
                    $this->setSortBy($categorySortBy);
                }
            }
        }

        return $this;
    }

    /**
     * Return identifiers for produced content
     *
     * @return array
     */
    public function getIdentities()
    {
        $identities = [];

        $category = $this->getLayer()->getCurrentCategory();
        if ($category) {
            $identities[] = Product::CACHE_PRODUCT_CATEGORY_TAG . '_' . $category->getId();
        }

        //Check if category page shows only static block (No products)
        if ($category->getData('display_mode') == Category::DM_PAGE) {
            return $identities;
        }

        foreach ($this->_getProductCollection() as $item) {
            $identities = array_merge($identities, $item->getIdentities());
        }

        return $identities;
    }

    /**
     * Get post parameters
     *
     * @param Product $product
     * @return string
     */
    public function getAddToCartPostParams(Product $product)
    {
        $url = $this->getAddToCartUrl($product);
        return [
            'action' => $url,
            'data' => [
                'product' => $product->getEntityId(),
                ActionInterface::PARAM_NAME_URL_ENCODED => $this->urlHelper->getEncodedUrl($url),
            ]
        ];
    }

    /**
     * @param Product $product
     * @return string
     */
    public function getProductPrice(Product $product)
    {
        $priceRender = $this->getPriceRender();

        $price = '';
        if ($priceRender) {
            $price = $priceRender->render(
                FinalPrice::PRICE_CODE,
                $product,
                [
                    'include_container' => true,
                    'display_minimal_price' => true,
                    'zone' => Render::ZONE_ITEM_LIST,
                    'list_category_page' => true
                ]
            );
        }

        return $price;
    }

    /**
     * Specifies that price rendering should be done for the list of products
     * i.e. rendering happens in the scope of product list, but not single product
     *
     * @return Render
     */
    protected function getPriceRender()
    {
        return $this->getLayout()->getBlock('product.price.render.default')
            ->setData('is_product_list', true);
    }

    /**
     * Configures product collection from a layer and returns its instance.
     *
     * Also in the scope of a product collection configuration, this method initiates configuration of Toolbar.
     * The reason to do this is because we have a bunch of legacy code
     * where Toolbar configures several options of a collection and therefore this block depends on the Toolbar.
     *
     * This dependency leads to a situation where Toolbar sometimes called to configure a product collection,
     * and sometimes not.
     *
     * To unify this behavior and prevent potential bugs this dependency is explicitly called
     * when product collection initialized.
     *
     * @return Collection
     */
    private function initializeProductCollection()
    {
        $layer = $this->getLayer();
        /* @var $layer Layer */
        if ($this->getShowRootCategory()) {
            $this->setCategoryId($this->_storeManager->getStore()->getRootCategoryId());
        }

        // if this is a product view page
        /*if ($this->_coreRegistry->registry('product')) {
            // get collection of categories this product is associated with
            $categories = $this->_coreRegistry->registry('product')
                ->getCategoryCollection()->setPage(1, 1)
                ->load();
            // if the product is associated with any category
            if ($categories->count()) {
                // show products from this category
                $this->setCategoryId(current($categories->getIterator())->getId());
            }
        }*/

        $origCategory = null;
		$this->setCategoryId(4);
        if ($this->getCategoryId()) {
			 
            try {
                $category = $this->categoryRepository->get($this->getCategoryId());
            } catch (NoSuchEntityException $e) {
                $category = null;
            }

            if ($category) {
                $origCategory = $layer->getCurrentCategory();
                $layer->setCurrentCategory($category);
            }
        }
        $collection = $layer->getProductCollection();
		$productIds =  $this->_coreRegistry->registry('product_ids');
		$collection->addAttributeToFilter('entity_id',array('in'=>$productIds));
		 
        //$this->prepareSortableFieldsByCategory($layer->getCurrentCategory());

        if ($origCategory) {
           // $layer->setCurrentCategory($origCategory);
        }
        
        $this->addToolbarBlock($collection);

        $this->_eventManager->dispatch(
            'catalog_block_product_list_collection',
            ['collection' => $collection]
        );

        return $collection;
    }

    /**
     * Configures the Toolbar block with options from this block and configured product collection.
     *
     * The purpose of this method is the one-way sharing of different sorting related data
     * between this block, which is responsible for product list rendering,
     * and the Toolbar block, whose responsibility is a rendering of these options.
     *
     * @param ProductList\Toolbar $toolbar
     * @param Collection $collection
     * @return void
     */
    private function configureToolbar(Toolbar $toolbar, Collection $collection)
    {
        // use sortable parameters
        $orders = $this->getAvailableOrders();
        if ($orders) {
            $toolbar->setAvailableOrders($orders);
        }
        $sort = $this->getSortBy();
        if ($sort) {
            $toolbar->setDefaultOrder($sort);
        }
        $dir = $this->getDefaultDirection();
        if ($dir) {
            $toolbar->setDefaultDirection($dir);
        }
        $modes = $this->getModes();
        if ($modes) {
            $toolbar->setModes($modes);
        }
        // set collection to toolbar and apply sort
        $toolbar->setCollection($collection);
        $this->setChild('toolbar', $toolbar);
    }
	 public function getImage($product, $imageId, $attributes = [])
    {
		if ($this->_coreRegistry->registry('product')) {
			
		}
        return $this->imageBuilder->setProduct($product)
            ->setImageId($imageId)
            ->setAttributes($attributes)
            ->create();
    }
	public function getCarModelDetails($productId){
		if($productId){
				$seasonlpriceModel 		=  $this->vehicleseasonalpriceFactory->create();
				$seasonlpriceCollection =  $seasonlpriceModel->getCollection();
				$seasonlpriceCollection->addFieldToFilter('main_table.product_id',array('eq'=>$productId));
				$seasonlpriceCollection->getSelect()->joinLeft(
					['carmodelatt'=>$seasonlpriceCollection->getTable('wais_carmodel_attributes')],
					'carmodelatt.carmodel_id=main_table.car_model_id',
					['carmodelatt.*','main_table.*']
				);
				$seasonlpriceCollection->getSelect()->joinLeft(
					['carmodel'=>$seasonlpriceCollection->getTable('wais_carmodel')],
					'carmodelatt.carmodel_id=carmodel.id',
					['carmodelatt.*','main_table.*','carmodel.vehicle_category_type','carmodel.vehicle_type']
				);
				$seasonlpriceCollection->getSelect()->group('main_table.product_id');
				//var_dump($seasonlpriceCollection->getSelect()->__toString());
			return $seasonlpriceCollection;
		}
		return false;
	}
	public function getPolicyDetails($productId){
		$data  = $this->getRequest()->getParams();
		if($productId && isset($data['country_id'])){
				 $carModelPolicy = $this->_carmodelsMileagePolicyFactory->create();
				 $carModelPolicyColl = $carModelPolicy->getCollection();
				 $carModelPolicyColl->addFieldToFilter('product_id',$productId);
				 $carModelPolicyColl->addFieldToSelect('product_id');
				 $carModelPolicyColl->getSelect()->joinLeft(
					[
					'mileagep'=>$carModelPolicyColl->getTable('wais_supplier_mileage_policy')
					],
					'mileagep.id=main_table.mileage_id',
					['mileagep.*','main_table.product_id']
				);
				$carModelPolicyColl->getSelect()->joinLeft(
					[
					'policycountry'=>$carModelPolicyColl->getTable('wais_supplier_mileage_policy_country')
					],
					'policycountry.mileage_id=mileagep.id',
					['policycountry.*']
				);
				$cntry_id = $data['country_id'];
				$carModelPolicyColl->getSelect()->where(
					"policycountry.country_id='".$cntry_id."' or policycountry.country_id='0'"
				);
				$carModelPolicyColl->getSelect()->order('mileage_id DESC');
				$carModelPolicyColl->getSelect()->limit('1');
				 
				return 	$carModelPolicyColl;
				 
		}
		 
	}
	
	public function getMileagePolicyContents($carModelPolicyColl){
		if(isset($carModelPolicyColl)){
			$item = $carModelPolicyColl->getFirstItem();
			$_helper = $this->_carrentalelper;
			$mileageType 	= $_helper->mileageTypes();
			$fuelTaxType 	= $_helper->getFuelTaxType();
			$durationTypes 	= $_helper->durationTypes();
			
			$str = $limitedstr =$includeamt = $addtionalcost = $includetax  = $excludeTax = $excludeTaxPercentage = $durationdays = '';
			
			if($item->getMileageType()==2){
				$str='Your rental includes unlimited';
			}elseif($item->getMileageType()==1){
				$str='Limited mileage,'; 
			}
			$duration = $item->getIncludedAmountDuration();
			$durationLabel = '';
			if($duration){
				$key = array_search($duration, array_column($durationTypes, 'value'));
				$durationLabel = $durationTypes[$key]['label'];
			}
			if($item->getIncludedAmount() && $item->getIncludedAmount()!='0.00'){
				$amt = $item->getIncludedAmount();
				$includeamt="included mileage is $amt km $durationLabel"; 
			}
			if($item->getAdditionalMileageCost() && $item->getAdditionalMileageCost()!='0.00'){
				$addtionalcost = $item->getAdditionalMileageCost();
				$addtionalcost="Additional mileage charge is ". $addtionalcost.' '.$durationLabel;
			}
			if($includeTax = $item->getMileageFee()==1){
				$includetax = '( includes Tax )';
			}
			if($excludeTax = $item->getMileageFee()==2){
				$excludeTaxPercentage = $item->getExcludedPercentage();
				$excludeTax = '(excludes '.$excludeTaxPercentage. '% Tax)';
			}
			$durationfromdays = $item->getMileageDurationFromdays();
			$durationtodays = $item->getMileageDurationTodays();
			if($durationfromdays && $durationtodays){
				$durationdays = " for rentals lasting $durationfromdays to $durationtodays days";
			}
			$finalstr = $str.$includeamt.$addtionalcost.$includetax.$excludeTax.$durationdays;
			
			return $finalstr;
			
		}
	}
	public function getFuelPolicy($productId){
			$data  = $this->getRequest()->getParams();
			if($productId){
				 $carModelPolicy = $this->_carmodelsMileagePolicyFactory->create();
				 $carModelPolicyColl = $carModelPolicy->getCollection();
				 $carModelPolicyColl->addFieldToFilter('product_id',$productId);
				 $carModelPolicyColl->addFieldToSelect('product_id');
				 $carModelPolicyColl->getSelect()->joinLeft(
					[
					'fuelp'=>$carModelPolicyColl->getTable('wais_supplier_fuel_policy')
					],
					'fuelp.id=main_table.fuel_id',
					['fuelp.*','main_table.product_id']
				);
				$carModelPolicyColl->getSelect()->order('fuel_id DESC');
				$carModelPolicyColl->getSelect()->limit('1');
				return   $carModelPolicyColl;
			}
			 
			
			
	}
	public function getFuelPolicyContents($carModelPolicyColl){
		 $finalstr = $fuelType = $prePay = $nonrefundable = $taxType = $depositAtPickup = $partialRefund = $nonrefundableadminfee ='';
		if(isset($carModelPolicyColl)){
			$item = $carModelPolicyColl->getFirstItem();
			$_helper = $this->_carrentalelper;
			$nonrefundablelocation = '';
			if($item->getTaxType()==1)
				$taxType = '<li>Refuelling and Service Charge include tax</li>';
			elseif($item->getTaxType()==2)
			$taxType = '<li>Refuelling and Service Charge Excluding tax</li>';
			
			if($item->getIsDepositAtPickup()==1){
				//$depositAtPickup = 'Up-front Fuel Deposit required at pick-up';
				if($item->getPickupAmountType()==1){ 
					//fix Amount
					 $depositAtPickup = "<li>Fixed amount ".$item->getPickupFixAmount()." is required at pick-up</li>";
				}else{
					//Min and Max Amount
					$depositAtPickup = "<li>Min ".$item->getPickupMinAmount()." and Max ".$item->getPickupMaxAmount()." is required at pick-up</li>";
				}
			}elseif($item->getIsDepositAtPickup()==2){
				$depositAtPickup = '<li>No Fuel Deposit required at the time of pick-up</li>';
			}
			
			
			if($item->getFuelType()==1){ //fuel to fuel
				$fuelType = '<li>The vehicle is provided with a full tank of fuel and just before you return the vehicle, please replace the used fuel in order to avoid any refuelling charges.</li>';
			}elseif($item->getFuelType()==2){ //same to same
				if($item->getFuelTypeSs()=='same_to_same'){
					 $fuelType = '<li>The vehicle is provided with less than a full tank of fuel  and just before you return the vehicle, please replace the used fuel in order to avoid any refuelling charges.</li>'; 
				}else if($item->getFuelTypeSs()=='3-4_to_3-4'){
					$fuelType = '<li>The vehicle is provided with less than a full tank of fuel (3/4) and just before you return the vehicle, please replace the used fuel in order to avoid any refuelling charges.</li>';
				}else if($item->getFuelTypeSs()=='1-2_to_1-2"'){
					$fuelType = '<li>The vehicle is provided with less than a full tank of fuel (1/2) and just before you return the vehicle, please replace the used fuel in order to avoid any refuelling charges.</li>';
				}else if($item->getFuelTypeSs()=='1-4_to_1-4'){
					$fuelType = '<li>The vehicle is provided with less than a full tank of fuel (1/4) and just before you return the vehicle, please replace the used fuel in order to avoid any refuelling charges.</li>';
				}
			}elseif($item->getFuelType()==3){ // Free Tank
				$fuelType ='<li>The vehicle is provided with a FULL tank free of any additional charge, and return the vehicle with or without any fuel at your own option.Fuel is included in the rate. Please�do not�fill up before you drop your car off, as you will not be refunded for any fuel left in the tank</li>';
			}elseif($item->getFuelType()==4){ //Empty
				$fuelType ='<li>The vehicle is provided with EMPTY tank of fuel and must be returned EMPTY Please note if the vehicle has more fuel than initially provided there will be no refund.</li>';
			}elseif($item->getFuelType()==5){ //Pre Pay Fuel
				$fuelType ='<li>The vehicle is provided with EMPTY tank of fuel and must be returned EMPTY Please note if the vehicle has more fuel than initially provided there will be no refund.</li>';
				
			}
			
			if($item->getIsPrepayFuel()==1){
				if($item->getPrepayFuelPriceType()=='At the average national price'){
					$prePay = '<li>Pay for the fuel in the tank with price '.$item->getPrepayFuelPriceType().'</li>' ;
					
				}elseif($item->getPrepayFuelPriceType()=='Significantly higher than national price'){
					$prePay = '<li>Pay for the fuel in the tank with price at'.$item->getPrepayFuelPriceType().'</li>' ;
				}
				 
			}
			if($item->getPrepayFuelPriceType()){
				
			}
			if($item->getIsPrepayPartialRefund()=='yes'){
				$partialRefund = '<li>Partial refund will be given for unused fuel ';
				if($item->getPrepayPartialRefundHireDaysType()=='More'){
				 $partialRefund.='if the hire days >';
				 $partialRefund.=$item->getPrepayPartialRefundHireDays();
				}
				if($item->getPrepayPartialRefundHireDaysType()=='less'){
				 $partialRefund.='if the hire days <';
				 $partialRefund.=$item->getPrepayPartialRefundHireDays();
				}
				$partialRefund.= '</li>';
			}
			if($item->getRefuelChargeDaysTo() && 
				$item->getRefuelChargeMeasureType()
			){
				$nonrefundable = '<li>Non-refundable fuel service charge of ';
				$nonrefundable .= $item->getRefuelChargeDaysTo();
				$tp = $this->getMeasureType($item->getRefuelChargeMeasureType());
				$nonrefundable .= ' '.$tp.'</li>';
				
			}
			if($item->getRefuelChargeDaysTo() && 
				$item->getRefuelChargeDaysFrom()
			){
				$nonrefundable = '<li>Non-refundable fuel service charge of between ';
				$nonrefundable .=$item->getRefuelChargeDaysFrom().' and '.$item->getRefuelChargeDaysTo().'</li>';
			}
			if($item->getRefuelLocationChargeTo() && 
				$item->getRefuelLocationMeasureType()
			){
				$nonrefundablelocation = '<li>Non-refundable location charge of ';
				$tp = $this->getMeasureType($item->getRefuelLocationMeasureType());
				$nonrefundablelocation .= $tp.'</li>';
			}
			if($item->getRefuelLocationChargeFrom() && 
				$item->getRefuelLocationChargeTo()
			){
				$nonrefundablelocation = '<li>Non-refundable location charge of between ';
				$nonrefundablelocation .=$item->getRefuelLocationChargeFrom().' and '.$item->getRefuelLocationChargeTo().'</li>';
			}
			if($item->getRefuelAdminFee() && 
				$item->getRefuelAdminFeeMeasureType()
			){
				$nonrefundableadminfee = '<li>Non-refundable admin fee of ';
				$nonrefundableadminfee .=$item->getRefuelLocationChargeFrom().' and '.$item->getRefuelLocationChargeTo();
				$nonrefundableadminfee .$this->getMeasureType($item->getRefuelAdminFeeMeasureType()).'</li>';
			}
			
			if($fuelType!=''):
				$finalstr = '<ul class="f-policy">';
				$finalstr  .= $taxType; 
				$finalstr .= $depositAtPickup;
				$finalstr .= $fuelType;
				$finalstr .= $prePay;
				$finalstr .= $partialRefund;
				$finalstr .= $nonrefundable;
				$finalstr .= $nonrefundablelocation;
				$finalstr .= $nonrefundableadminfee;
				$finalstr .= '</ul>';
			endif;
			
		  return $finalstr;
			
		}
	}
	private function getMeasureType($type){
		if($type==1)
			return 'Fixed'; 
		if($type==2)
			return 'Per Litre'; 
		if($type==3)
			return 'Per Gallon'; 
	}
	public  function getFuelType($type){
		$label = '';
		$allTypes = $this->_carrentalelper->getFuelPType();
		$key = array_search($type, array_column($allTypes, 'value'));
		if($key):
			$label = $allTypes[$key]['label'];
		endif;
		
		return $label; 
	}
	public function getMileage($type){
		$allTypes = $this->_carrentalelper->mileageTypes();
		$label = '';
		$key = array_search($type, array_column($allTypes, 'value'));
		if($key):
			$label = $allTypes[$key]['label'];
		endif;
		
		return $label; 
	}
	 
}
