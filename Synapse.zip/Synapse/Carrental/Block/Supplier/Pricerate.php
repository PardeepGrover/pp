<?php
namespace Synapse\Carrental\Block\Supplier;
class Pricerate extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    private $directoryHelper;
    /**
     * @var \Magento\Framework\App\Cache\Type\Config
     */
    protected $_configCacheType;
    
     /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;
    /**
     * @var \Magento\Directory\Model\ResourceModel\Region\CollectionFactory
     */
    protected $_regionCollectionFactory;

    /**
     * @var \Magento\Directory\Model\ResourceModel\Country\CollectionFactory
     */
    protected $_countryCollectionFactory;
    protected $_carrentalhelper;
	protected $_registry;
	protected $_fleetcarmodelFactory;
	protected $_fleetmodelFactory;
	protected $_rateCodeFactory;
	protected $_vehiclepricelistFactory;
	protected $_vehiclepricelistseasonsFactory;
	protected $_vehicleseasonalpriceFactory;
	
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Directory\Helper\Data $directoryHelper,
        \Magento\Framework\App\Cache\Type\Config $configCacheType,
        \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory,
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
        \Synapse\Carrental\Helper\Data $carrentalHelper,
		\Synapse\Carrental\Model\FleetcarmodelsFactory $FleetcarmodelsFactory,
		\Synapse\Carrental\Model\FleetFactory $FleetModelFactory,
		\Synapse\Carrental\Model\RateCodeFactory $RateCodeFactory,
		\Synapse\Carrental\Model\VehiclepricelistFactory $VehiclepricelistFactory,
		\Synapse\Carrental\Model\VehiclepricelistseasonsFactory $VehiclepricelistseasonsFactory,
		\Synapse\Carrental\Model\VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
		\Magento\Framework\Registry $registry,
        array $data = []
    )
    {
        parent::__construct($context, $data);
		$this->_customerSession = $customerSession;
        $this->directoryHelper = $directoryHelper;
        $this->_configCacheType = $configCacheType;
        $this->_regionCollectionFactory = $regionCollectionFactory;
        $this->_countryCollectionFactory = $countryCollectionFactory;
        $this->_carrentalhelper = $carrentalHelper;
		$this->_registry = $registry; 
		$this->_fleetcarmodelFactory = $FleetcarmodelsFactory;
		$this->_fleetmodelFactory = $FleetModelFactory;
		$this->_rateCodeFactory = $RateCodeFactory;
		$this->_vehiclepricelistFactory = $VehiclepricelistFactory;
		$this->_vehiclepricelistseasonsFactory = $VehiclepricelistseasonsFactory;
		$this->_vehicleseasonalpriceFactory = $VehicleseasonalpriceFactory;
	 
    }
   
    public function getSaveUrl(){
         return $this->getUrl('carrental/pricerate/save');
    }
	public function getInlineSaveUrl(){
         return $this->getUrl('carrental/pricerate/Inlinesave');
    }
    
    public function addRateCodeUrl(){
        
        return $this->getUrl('carrental/ratecode/add');
    }
    public function getBackUrl(){
		
		return $this->getUrl('carrental/pricerate/');
		
	}
	public function createPriceListUrl(){
		return $this->getUrl('carrental/pricerate/add');
		 
	}
	public function getPricingMethods(){
		$dailyranges = $this->_carrentalhelper->getDailyRanges();
		$arr = [];
		foreach($dailyranges as $tempid=>$val):
			$str = '';
			foreach($val as $k=>$subarr):
					 $str = $str.','.$subarr['label'];
			 endforeach;
			$arr[$tempid] = trim($str,",");
		endforeach;
		return  $arr;
	}
	public function getCustomerId(){
		return $this->_customerSession->getCustomer()->getId();
	}
	public function getWarehouses(){
		$warehouses = $this->_carrentalhelper->getWarehouses();
		$warehouses->addFieldToFilter('supplier_id',['eq'=>$this->getCustomerId()]);
		return $warehouses;
	}
	public function createSeasons($wid){
		 return json_encode($wid);
	}
	/* no usage*/ 
	public function getCarmodelTemplateData(){
		$dailyranges = $this->_carrentalhelper->getDailyRanges();
		$fleetModel = $this->_fleetmodelFactory->create();
		$fleetCollection = $fleetModel->getCollection();
		$fleetCollection->addFieldToFilter('main_table.supplier_id',$this->_customerSession->getCustomer()->getId());
		$fleetCollection->addFieldToSelect('supplier_id');
		$fleetCollection->getSelect()->joinLeft(
					['carmodel'=>$fleetCollection->getTable('wais_fleetcarmodels')],
					'carmodel.fleet_id=main_table.id and carmodel.status="1"',
					[
						'carmodel.fleet_id',
						'carmodel.car_model_id',
						'carmodel.qty'
					]
				);
		$final = [];		
		if($fleetCollection){
			foreach($fleetCollection as $k=>$_val):
					foreach($dailyranges as $tempid=>$val):
						foreach($val as $k=>$subarr):
							$final[$tempid][$_val->getCarModelId()][$k] = [
												'sub_temp_id' => $subarr['value'],
												'label' => $subarr['label'],
												];	 
						endforeach;
					endforeach;
			endforeach;		
		}
		return  json_encode($final);
	}
	public function getRequestDataforseasonlist(){
		$data = $this->_registry->registry('seasontemplaterequestdata');
		$fleetcarmodelsFactory = $this->_fleetcarmodelFactory->create();
		$collection = $fleetcarmodelsFactory->getCollection();
		$collection->addFieldToFilter('main_table.fleet_id',$data['fleet_id']);
		$collection->addFieldToSelect('fleet_id');
		$collection->addFieldToSelect('car_model_id');
		$collection->addFieldToSelect('carmodel_class');
		$collection->getSelect()->joinLeft(
			[
				'carmodel' =>$collection->getTable('wais_carmodel')
			]
			,'carmodel.id=main_table.car_model_id',
			[
				'carmodel.vehicle_name'
			]
		);
		$dailyranges = $this->_carrentalhelper->getDailyRanges();
		$dailyranges = $dailyranges[$data['pricing_method']];
		
		$final = [];		
		$final['carmodels'] = $collection;
		return $final;
		
	}
	public function getDailyRangesLabels(){
		$dailyranges = [];
		$data = $this->_registry->registry('seasontemplaterequestdata');
		if($data['pricing_method']){
			$dailyranges = $this->_carrentalhelper->getDailyRanges();
			$dailyranges = $dailyranges[$data['pricing_method']];
		}
		return $dailyranges;
	}
	public function getRequestData(){
		$data = $data = $this->_registry->registry('seasontemplaterequestdata');
		return $data;
	}
	public function getRateCodes(){
		$ratecodeModel = $this->_rateCodeFactory->create();
		
		$ratecodeCollection = $ratecodeModel->getCollection();
		$ratecodeCollection->addFieldToFilter('supplier_id',$this->_customerSession->getCustomer()->getId());
		$ratecodeCollection->addFieldToSelect('ratecode_name');
		$ratecodeCollection->addFieldToSelect('id');
		return $ratecodeCollection;
	}
	public function getPriceListDetails(){
		$id = $this->getRequest()->getParam('id');
		$pricelistModel = $this->_vehiclepricelistFactory->create();
		$collection  = $pricelistModel->getCollection();
		$collection->addFieldToFilter('main_table.id',$id);
		return $collection->getFirstItem();
	}
	public function getDailyRangesUsingTemplateId($template_id){
		$dailyranges = $this->_carrentalhelper->getDailyRanges();
		$dailyranges = $dailyranges[$template_id];
		return $dailyranges;
		
	}
	public function getSeasonalPrices(){
		$arr = [] ;
		$id = $this->getRequest()->getParam('id');
		$seasonlistModel = $this->_vehiclepricelistseasonsFactory->create();
		$collection  = $seasonlistModel->getCollection();
		$collection->addFieldToSelect('season_name');
		$collection->addFieldToSelect('season_from_date');
		$collection->addFieldToSelect('season_to_date');
		$collection->addFieldToFilter('main_table.pricelist_id',$id);
		foreach($collection as $_coll){
			$arr[$_coll->getSeasonId()]['template_id'] = $_coll->getTemplateId();
			$arr[$_coll->getSeasonId()]['season_name']= $_coll->getSeasonName();
			$arr[$_coll->getSeasonId()]['season_date']= $_coll->getSeasonFromDate().' - '.$_coll->getSeasonToDate();
			$arr[$_coll->getSeasonId()]['carmodels'][$_coll->getCarModelId()][]= $_coll->getData();
		}
		return $arr;
	}
	
 
	 
	
	
}