<?php
namespace Synapse\Carrental\Block\Supplier;
class Configurations extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    protected $_carrentalhelper;
    protected $_configurationsFactory;
	protected $_registry;
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Synapse\Carrental\Helper\Data $carrentalHelper,
        \Synapse\Carrental\Model\ConfigurationsFactory $configurationsFactory,
		\Magento\Framework\Registry $registry,
		\Magento\Framework\Json\EncoderInterface $jsonEncoder,
		 array $data = []
    )
    {
        parent::__construct($context, $data);
		$this->_customerSession = $customerSession;
        $this->_carrentalhelper = $carrentalHelper;
		$this->_registry = $registry; 
		$this->_configurationsFactory = $configurationsFactory; 
	}
    public function getHelper(){
        return $this->_carrentalhelper; 
    }
	public function getSaveUrl(){
		return $this->getUrl('carrental/configurations/save');
	}
	public function getDriverAge(){
		$model = $this->_configurationsFactory->create();
		return $model->load(1);
	}
 
	 
	
	
}