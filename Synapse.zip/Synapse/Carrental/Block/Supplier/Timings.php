<?php
namespace Synapse\Carrental\Block\Supplier;
class Timings extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    private $directoryHelper;
    /**
     * @var \Magento\Framework\App\Cache\Type\Config
     */
    protected $_configCacheType;
    
     /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;
    /**
     * @var \Magento\Directory\Model\ResourceModel\Region\CollectionFactory
     */
    protected $_regionCollectionFactory;

    /**
     * @var \Magento\Directory\Model\ResourceModel\Country\CollectionFactory
     */
    protected $_countryCollectionFactory;
    protected $_carrentalhelper;
	protected $_holidaysFactory;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Directory\Helper\Data $directoryHelper,
        \Magento\Framework\App\Cache\Type\Config $configCacheType,
        \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory,
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
        \Synapse\Carrental\Helper\Data $carrentalHelper,
		\Synapse\Carrental\Model\HolidaysFactory $holidaysFactory,
        array $data = []
    )
    {
        parent::__construct($context, $data);
		$this->_customerSession = $customerSession;
        $this->directoryHelper = $directoryHelper;
        $this->_configCacheType = $configCacheType;
        $this->_regionCollectionFactory = $regionCollectionFactory;
        $this->_countryCollectionFactory = $countryCollectionFactory;
        $this->_carrentalhelper = $carrentalHelper;
		$this->_holidaysFactory = $holidaysFactory;
	 
    }
    public function getPostActionUrl(){
        return $this->getUrl('carrental/timings/add');
    }
    public function getItems(){
        return [];
        
    }
    public function getSaveUrl(){
         return $this->getUrl('carrental/timings/save');
    }
    
    public function addTimingUrl(){
        
        return $this->getUrl('carrental/timings/add');
    }
    public function getHelper(){
        return $this->_carrentalhelper; 
    }
	public function getBackUrl(){
		return $this->getUrl('carrental/timings/');
		
	}
	public function getSupplierHolidays(){
		$holidays = [];
		$holidaysCollection = $this->_holidaysFactory->create()->getCollection();
		$holidaysCollection->getSelect()->columns('Year(holiday_date) as year');
		$holidaysCollection->getSelect()->order('year asc');
		//foreach($holidaysCollection as $_val){
			//$holidays[$_val->getYear()][] =  $_val->getData();
		//}
		return $holidaysCollection->getData();
		//return $holidays;
	}
	public function getSupplierWarehouses(){
		$collection =  $this->getHelper()->getWarehouses();
		$collection->addFieldToFilter('supplier_id',['eq'=>$this->getCustomerId()]);
		return $collection;
	}
	public function getCustomerId(){
		return $this->_customerSession->getCustomer()->getId();
		
	}
	 
	 
	
	
}