<?php
namespace Synapse\Carrental\Block\Supplier;
class Driverage extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    protected $_carrentalhelper;
    protected $_driverageFactory;
	protected $_registry;
	public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Synapse\Carrental\Helper\Data $carrentalHelper,
        //\Synapse\Carrental\Model\DriverageFactory $DriverageFactory,
		\Magento\Framework\Registry $registry,
		\Magento\Framework\Json\EncoderInterface $jsonEncoder,
		 array $data = []
    )
    {
        parent::__construct($context, $data);
		$this->_customerSession = $customerSession;
        $this->_carrentalhelper = $carrentalHelper;
		$this->_registry = $registry; 
		//$this->_driverageFactory = $DriverageFactory; 
	}
    public function getHelper(){
        return $this->_carrentalhelper; 
    }
	public function getSaveUrl(){
		return $this->getUrl('carrental/driverage/save');
	}
	
 
	 
	
	
}