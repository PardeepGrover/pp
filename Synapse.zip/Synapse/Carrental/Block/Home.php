<?php
namespace Synapse\Carrental\Block;
class Home extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    private $directoryHelper;
    /**
     * @var \Magento\Framework\App\Cache\Type\Config
     */
    protected $_configCacheType;
    
     /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;
    /**
     * @var \Magento\Directory\Model\ResourceModel\Region\CollectionFactory
     */
    protected $_regionCollectionFactory;

    /**
     * @var \Magento\Directory\Model\ResourceModel\Country\CollectionFactory
     */
    protected $_countryCollectionFactory;
    protected $_carrentalhelper;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Directory\Helper\Data $directoryHelper,
        \Magento\Framework\App\Cache\Type\Config $configCacheType,
        \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory,
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
        \Synapse\Carrental\Helper\Data $carrentalHelper,
        array $data = []
    )
    {
        parent::__construct($context, $data);
		$this->_customerSession = $customerSession;
        $this->directoryHelper = $directoryHelper;
        $this->_configCacheType = $configCacheType;
        $this->_regionCollectionFactory = $regionCollectionFactory;
        $this->_countryCollectionFactory = $countryCollectionFactory;
        $this->_carrentalhelper = $carrentalHelper;
	 
    }
    public function getActionUrl(){
        return $this->getUrl('carrental/home/search');
    }
	public function getWeekdays($weekday){
		$weekDayNames = [
				'SUN'=>'1',
				'MON'=>'2',
				'TUE'=>'3',
				'WED'=>'4',
				'THU'=>'5',
				'FRI'=>'6',
				'SAT'=>'7'
			];
		 //var_dump($weekday);
		return $weekDayNames[$weekday];
	}
	
	
   
	
	
}