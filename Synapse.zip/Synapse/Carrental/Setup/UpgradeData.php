<?php

 /**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Synapse\Carrental\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Framework\Setup\UpgradeDataInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Synapse\Carrental\Helper\Data as Helper;



/**
 * Upgrade the Catalog module DB scheme
 */
class UpgradeData implements UpgradeDataInterface
{
	
	protected $eavSetupFactory;

	 public function __construct(EavSetupFactory $eavSetupFactory)
	 {
		$this->eavSetupFactory = $eavSetupFactory;
	 }
 
 
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     * @SuppressWarnings(PHPMD.CyclomaticComplexity)
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
   public function upgrade( ModuleDataSetupInterface $setup, ModuleContextInterface $context ) {
        $setup->startSetup();

        /* if (version_compare($context->getVersion(), '1.0.1', '<')) {
           
		 }*/
		$this->addSupplierAttributes($setup);
		$this->templateIds($setup);
		$this->VehicleTransmission($setup);
		$this->VehicleFuel($setup);
		$this->VehicleCategory($setup);
		$this->VehicleType($setup);
		$this->FuelPolicy($setup);
		$this->MileagePolicy($setup);
		$setup->endSetup();
    }

    
    /**
     * @param SchemaSetupInterface $setup
     * @return void
     */
    private function addSupplierAttributes(ModuleDataSetupInterface  $setup)
    {
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'supplier_id');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'supplier_id',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => ' Supplier',
                'input' => 'select',
                'class' => '',
                'source' => 'Synapse\Carrental\Model\Source\Options\Supplier',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'visible_on_front' => true,
                'used_in_product_listing' => true,
                'unique' => false,
				'apply_to' => '',
				'is_used_in_grid' => true,
				'is_visible_in_grid' => false,
				'is_filterable_in_grid' => true,
            ]
        );
		 
     
    }
	private function templateIds(ModuleDataSetupInterface  $setup){
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'template_id');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'template_id',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Template Id',
                'input' => 'select',
                'class' => '',
                'source' => 'Synapse\Carrental\Model\Source\Options\TemplateIds',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => false,
                'filterable' => true,
                'comparable' => false,
                'visible_on_front' => false,
                'used_in_product_listing' => false,
                'unique' => false
            ]
        );
		
	}
	private function VehicleTransmission(ModuleDataSetupInterface  $setup){
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'vehicle_transmission');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'vehicle_transmission',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Vehicle Transmission',
                'input' => 'select',
                'class' => '',
                'source' => '\Synapse\Carrental\Model\Source\Options\VehicleTransmission',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'visible_on_front' => true,
                'used_in_product_listing' => true,
                'unique' => false,
				'apply_to' => '',
				'is_used_in_grid' => true,
				'is_visible_in_grid' => false,
				'is_filterable_in_grid' => true,
            ]
        );
		 
		
	}
	private function VehicleFuel(ModuleDataSetupInterface  $setup){
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'vehicle_fuel');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'vehicle_fuel',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Vehicle Fuel',
                'input' => 'select',
                'class' => '',
                'source' => '\Synapse\Carrental\Model\Source\Options\VehicleFuel',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'visible_on_front' => true,
                'used_in_product_listing' => true,
                'unique' => false,
				'apply_to' => '',
				'is_used_in_grid' => true,
				'is_visible_in_grid' => false,
				'is_filterable_in_grid' => true,
            ]
        );
		
	}
	private function VehicleCategory(ModuleDataSetupInterface  $setup){
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'vehicle_category');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'vehicle_category',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Vehicle Category',
                'input' => 'select',
                'class' => '',
                'source' => '\Synapse\Carrental\Model\Source\Options\VehicleCategory',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'visible_on_front' => true,
                'used_in_product_listing' => true,
                'unique' => false,
				'apply_to' => '',
				'is_used_in_grid' => true,
				'is_visible_in_grid' => false,
				'is_filterable_in_grid' => true,
            ]
        );
		
	}
	private function VehicleType(ModuleDataSetupInterface  $setup){
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'vehicle_type');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'vehicle_type',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Vehicle Type',
                'input' => 'select',
                'class' => '',
                'source' => '\Synapse\Carrental\Model\Source\Options\VehicleType',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'visible_on_front' => true,
                'used_in_product_listing' => true,
                'unique' => false,
				'apply_to' => '',
				'is_used_in_grid' => true,
				'is_visible_in_grid' => false,
				'is_filterable_in_grid' => true,
            ]
        );
		
	}
	private function FuelPolicy(ModuleDataSetupInterface  $setup){
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'vehicle_fuel_policy');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'vehicle_fuel_policy',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Fuel Policy',
                'input' => 'select',
                'class' => '',
                'source' => '\Synapse\Carrental\Model\Source\Options\FuelPolicy',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'visible_on_front' => true,
                'used_in_product_listing' => true,
                'unique' => false,
				'apply_to' => '',
				'is_used_in_grid' => true,
				'is_visible_in_grid' => false,
				'is_filterable_in_grid' => true,
            ]
        );
		
	}
	private function MileagePolicy(ModuleDataSetupInterface  $setup){
		/** @var EavSetup $eavSetup */
        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
         
        /**
         * Add attributes to the eav/attribute
         */
        $eavSetup->removeAttribute(\Magento\Catalog\Model\Product::ENTITY,'vehicle_mileage_policy');
        $eavSetup->addAttribute(
            \Magento\Catalog\Model\Product::ENTITY,
            'vehicle_mileage_policy',
            [
                'group' => 'Product Details',
                'type' => 'int',
                'backend' => 'Magento\Eav\Model\Entity\Attribute\Backend\ArrayBackend',
                'frontend' => '',
                'label' => 'Mileage Policy',
                'input' => 'select',
                'class' => '',
                'source' => '\Synapse\Carrental\Model\Source\Options\MileagePolicy',
                'global' => \Magento\Eav\Model\Entity\Attribute\ScopedAttributeInterface::SCOPE_GLOBAL,
                'visible' => true,
                'required' => false,
                'user_defined' => true,
                'default' => '',
                'searchable' => true,
                'filterable' => true,
                'comparable' => true,
                'visible_on_front' => true,
                'used_in_product_listing' => true,
                'unique' => false,
				'apply_to' => '',
				'is_used_in_grid' => true,
				'is_visible_in_grid' => false,
				'is_filterable_in_grid' => true,
            ]
        );
		
	}
	

   
}
