<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 02/04/2017
 * Time: 10:24
 */
namespace Synapse\Carrental\Observer\Customer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Synapse\Carrental\Model\SupplierinfoFactory;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Model\RateCodeFactory;

/**
 * Class Update
 * @package Magenest\RentalAndBookingSystem\Observer\Frontend\Option
 */
class Updategroup implements ObserverInterface
{
    
    /**
     * 
     * @var type
     * request object
     */
    private $_request;
    protected $_customerRepositoryInterface;
    protected $_supplierinfoFactory;
	private   $_fleetModelFactory;
	private $_rateCodeFactory;
    const CUSTOMER_GROUP_ID = 4;
	const FLEET_NAME = 'Default';
	const RATECODE_NAME = 'Default';
    /**
     * Update constructor.
    
     */
    public function __construct(
       RequestInterface $request,
       \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        SupplierinfoFactory $SupplierinfoFactory,
		FleetFactory $FleetFactory,
		RateCodeFactory $RateCodeFactory
    ) {
            $this->_request = $request;
            $this->_customerRepositoryInterface = $customerRepositoryInterface;
            $this->_supplierinfoFactory = $SupplierinfoFactory;
			$this->_fleetModelFactory = $FleetFactory;
			$this->_rateCodeFactory = $RateCodeFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
         $customer = $observer->getEvent()->getCustomer();
         $is_supplier = $this->_request->getParam('is_supplier');
         if($is_supplier):
               $customer->setGroupId(self::CUSTOMER_GROUP_ID);
               $this->_customerRepositoryInterface->save($customer);
               $supplierinfoFactory = $this->_supplierinfoFactory->create();
               $supplierinfoFactory->setSupplierId($customer->getId());
               $supplierinfoFactory->save();
			   
			   $fleetModel = $this->_fleetModelFactory->create();
			   $fleetModel->setSupplierId($customer->getId());
			   $fleetModel->setFleetName(self::FLEET_NAME);
			   $fleetModel->save();
			   
			   $ratecodeModel = $this->_rateCodeFactory->create();
			   $ratecodeModel->setSupplierId($customer->getId());
			   $ratecodeModel->setRatecodeName(self::RATECODE_NAME);
			   $ratecodeModel->save();
         endif;
        
    }
}
