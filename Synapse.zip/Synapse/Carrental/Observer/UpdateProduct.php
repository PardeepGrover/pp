<?php

namespace Synapse\Carrental\Observer;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Catalog\Controller\Adminhtml\Product\Builder;
use Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper;
use Magento\Customer\Model\Session; 
class UpdateProduct implements \Magento\Framework\Event\ObserverInterface
{
	 
	 /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
	
	private $productTypeManager;
	
	
	
	/**
     * @var Initialization\Helper
     */
    protected $initializationHelper;
	/**
     * @var app/request
     */
	protected $_request;
	
	/**
     * @var return product model
     */
	protected $productModel;
	protected $_logger;
	protected $_productModelFactory;
	
	

	 /**
     * Save constructor.
     *
     * @param Action\Context $context
     * @param Builder $productBuilder
     * @param Initialization\Helper $initializationHelper
     */
    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
		StoreManagerInterface $StoreManagerInterface,
		RequestInterface $request,
		DataPersistorInterface $DataPersistorInterface,
		\Magento\Catalog\Model\Product $productModel,
		\Magento\Catalog\Model\ProductFactory $productModelFactory,
		\Psr\Log\LoggerInterface $logger,
		\Magento\Framework\App\Filesystem\DirectoryList $DirectoryList,
		Session $customerSession
    ) {
      
        $this->productRepository = $productRepository;
		$this->storeManager = $StoreManagerInterface;
		$this->_request  = $request;
		$this->productModel = $productModel;
		$this->_logger = $logger;
		$this->directoryList = $DirectoryList;
		$this->_customerSession = $customerSession;
		$this->_productModelFactory = $productModelFactory;
         
    }
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$customerId = $this->_customerSession->getCustomer()->getId();
		$p_ids = $observer->getData('ids');
		$type = $observer->getData('type');
		if ($p_ids) {
			try {
				$product = '';
				foreach($p_ids as $_pid=>$_policyId):
				$product = $this->_productModelFactory->create(); 
				$product = $product->load($_pid);
				if(isset($type) && $type=='mileage' && $product):
				$product->addData(array('vehicle_mileage_policy' =>$_policyId));
				else:
				$product->addData(array('vehicle_fuel_policy' =>$_policyId));
				endif;
				
				$product->save();
				endforeach;
			}catch(Exception $e){
				$this->_logger->addDebug('updating products....'.$e->getMessage()."<br/>");
					 
			}
		

		}	
		
		return $this;
	}
	 	
}