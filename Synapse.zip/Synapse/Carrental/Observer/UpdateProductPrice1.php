<?php

namespace Synapse\Carrental\Observer;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Catalog\Controller\Adminhtml\Product\Builder;
use Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper;

use Synapse\Carrental\Model\CarModelImagesFactory;
use Synapse\Carrental\Model\VehiclepricelistFactory;
use Synapse\Carrental\Model\VehiclepricelistseasonsFactory;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
use Magento\Framework\Session\SessionManagerInterface;
class UpdateProductPrice1 implements \Magento\Framework\Event\ObserverInterface
{
	 
	 /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
	
	private $productTypeManager;
	
	private $pricelistFactory;
	private $pricelistseasonsFactory;
	private $seasonalpriceFactory;
	
	/**
     * @var Initialization\Helper
     */
    protected $initializationHelper;
	/**
     * @var app/request
     */
	protected $_request;
	
	/**
     * @var return product model
     */
	protected $productModel;
	protected $_logger;
	protected $carModelImagesFactory;
	protected $directoryList;
	protected $_registry;
	protected  $_session;

	 /**
     * Save constructor.
     *
     * @param Action\Context $context
     * @param Builder $productBuilder
     * @param Initialization\Helper $initializationHelper
     */
    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
		StoreManagerInterface $StoreManagerInterface,
		RequestInterface $request,
		DataPersistorInterface $DataPersistorInterface,
		VehiclepricelistFactory $VehiclepricelistFactory,
		VehiclepricelistseasonsFactory $VehiclepricelistseasonsFactory, 
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
		\Magento\Catalog\Model\Product $productModel,
		\Psr\Log\LoggerInterface $logger,
		\Magento\Framework\App\Filesystem\DirectoryList $DirectoryList,
		CarModelImagesFactory $CarModelImagesFactory,
		\Magento\Framework\Registry $registry,
		SessionManagerInterface $SessionManagerInterface
    ) {
      
        $this->productRepository = $productRepository;
		$this->storeManager = $StoreManagerInterface;
		$this->pricelistFactory = $VehiclepricelistFactory;
		$this->pricelistseasonsFactory = $VehiclepricelistseasonsFactory;
		$this->seasonalpriceFactory = $VehicleseasonalpriceFactory;
		$this->_request  = $request;
		$this->productModel = $productModel;
		$this->_logger = $logger;
		$this->carModelImagesFactory = $CarModelImagesFactory;
		$this->directoryList = $DirectoryList;
		$this->_registry = $registry;
		$this->_session = $SessionManagerInterface;
         
    }
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$item    = $observer->getEvent()->getData('quote_item');
		$product = $observer->getEvent()->getData('product');
		//$price = $this->calculatePrice($product);
		 $price = $this->_session->getData('product-'.$product->getId());
		$product->setPrice($price);
		return $this;
		 
	}
	public function calculatePrice($product){
		
		$calculatedP = '';
		 $this->_session->getData('product-'.$product->getId());
		if(!isset($request['pickup_date'])){
			return;
		}
		$pickup_date = date('Y-m-d',strtotime($request['pickup_date']));
		$pickup_time = $request['pickup_time'];
		$dropoff_date = date('Y-m-d',strtotime($request['dropoff_date']));
		$dropff_time = $request['dropoff_time'];
		
		 
		$totalrecordCollection =  $this->_registry->registry('totalrecords');
		 
		$totalrecordCollection->addFieldToFilter(
						'product_id',['eq'=>$product->getId()]
					);
		$totalrecordCollection->getSelect()->group('season_from_date');
		$price = 0;
		$records = $totalrecordCollection->getData();
		if($records){
				 
				foreach($records as $_rec):
						if(strtotime($_rec['season_from_date']) <=strtotime($pickup_date ))
							$d_1 = $pickup_date;
						else
							$d_1 = $_rec['season_from_date']; 
				
						if (strtotime($_rec['season_to_date']) >= strtotime($dropoff_date))
							$d_2 = $dropoff_date;
						else
							$d_2 = $_rec['season_to_date'];
					
					$d_1 = strtotime($d_1 . $pickup_time);
					$d_2 = strtotime($d_2 . $dropff_time);
					 
					$totaldaysofbookinginSeason = (($d_2 - $d_1)/86400);
				
					$totaldaysofbookinginSeason =ceil($totaldaysofbookinginSeason);
					$templateId = 	$_rec['template_id'];
					 
					$sub_template_id = $this->subTemplateId($templateId,		$totaldaysofbookinginSeason);
					$subtemparr = explode('-',$sub_template_id);
					$sub_template_id = $subtemparr[0];
					$type = $subtemparr[1];
					$price += $this->getPrice($templateId,$sub_template_id,$type,$_rec,$totaldaysofbookinginSeason,$product->getId());
					
				endforeach;
				$totalrecordCollection->clear()->getSelect()->reset('where');	
				unset($totalrecordCollection);
				unset($totalrecordCollection);
				
			}
		
		return $price;
	}
	public function getPrice($templateId,$sub_template_id,$type,$_rec,$totaldaysofbookinginSeason,$productId){
		$seasonalPriceModel = $this->seasonalpriceFactory->create(); 
		$coll = $seasonalPriceModel->getCollection();
		$coll->addFieldToFilter('template_id',array('eq'=>$templateId));
		$coll->addFieldToFilter('product_id',array('eq'=>$productId));
		$coll->addFieldToFilter('season_id',array('eq'=>$_rec['season_id']));
		$coll->addFieldToFilter('sub_template_id',array('eq'=>$sub_template_id));
		$coll->addFieldToSelect('price');
		$coll->addFieldToSelect('sub_template_id');
		 
		$price = $coll->getFirstItem()->getPrice();
		$calculatedP = '';
		if($type=='daily'){
			$calculatedP = $price*$totaldaysofbookinginSeason;
		}else if ($type=='fixed'){
			$calculatedP = $price;
		}else if ($type=='weekly'){
			$week_count = (int) ($totaldaysofbookinginSeason / 7);
			$calculatedP = $price*$week_count;
			$remaining_day = ( $totaldaysofbookinginSeason % 7);
			if($remaining_day>0) {
				 
				$subtemp1 =  $this->subTemplateId($templateId,$remaining_day);
				$subtemparr1 = explode('-',$subtemp1);
				$sub_template_id1 = $subtemparr1[0];
				
				$seasonalPriceModel = $this->seasonalpriceFactory->create(); 
				$colls = $seasonalPriceModel->getCollection();
				$colls->addFieldToFilter('template_id',array('eq'=>$templateId));
				$colls->addFieldToFilter('product_id',array('eq'=>$productId));
				$colls->addFieldToFilter('season_id',array('eq'=>$_rec['season_id']));
				$colls->addFieldToFilter('sub_template_id',array('eq'=>$sub_template_id1));
				$colls->addFieldToSelect('price');
				$colls->addFieldToSelect('sub_template_id');
				$price = $colls->getFirstItem()->getPrice();
				$calculatedP += $price*$remaining_day;
			}
			
		}
		 
		return $calculatedP;
	}
	public function subTemplateId($templateId,$days){
		if ($templateId == 1) {
			if ($days < 3) {
				//  '1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			}
			elseif ($days > 2 && $days < 5)
			{
				// '2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} elseif($days > 4 && $days < 8)
			{
				// '3' => '5-7 daily',
				$sub_template_id = 2;
				$rate_type = 'fixed';
			}else if ($days > 7 && $days < 14)
			{
				//  '4' => '8-13 daily',
				$sub_template_id = 3;
				$rate_type = 'daily';
			}else if ($days == 14)
			{
					// '5' => '14 fixed',
				$sub_template_id = 4;
				$rate_type = 'fixed';
			} else if ($days > 14)
			{
				//   '6' => '14+ daily',
				$sub_template_id = 5;
				$rate_type = 'daily';
			}

        } else
			// template_id 2
		if ($templateId == 2) {
			if ($days < 3) {
				// '1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} elseif ($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} elseif ($days > 4 && $days < 7) {
				//'3' => '5-6 daily',
				$sub_template_id = 2;
				$rate_type = 'daily';
			} else if ($days == 7) {
					//'4' => '7 fixed',
				$sub_template_id =3;
				$rate_type = 'fixed';
			} else if (7 < $days && $days < 14) {
					// '5' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';

            } else if ($days == 14) {
				$sub_template_id = 5;
				//'6' => '14 fixed',
				$rate_type = 'fixed';
			} else if ($days > 14) {
				//'7' => '14+ daily',
				$sub_template_id = 6;
				$rate_type = 'daily';

            }
		}
		// template_id 3
		if ($templateId == 3) {
			if ($days < 3) {
				//'1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} else if ($days > 4 && $days < 7) {
				//'3' => '5-6 daily',
				$sub_template_id = 2;
				$rate_type = 'daily';
			} else if ($days == 7) {
				//'4' => '7 fixed',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			} else if ($days > 7 && $days < 14) {
				//'5' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'7' => '14 fixed',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			} else if ($days > 14) {
				//'8' => '14+  daily',
				$sub_template_id = 6;
				$rate_type = 'daily';
			}
		}
		// template_id 4
		if ($templateId == 4) {
			if ($days < 3) {
				// '1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if ($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} else if ($days > 4 && $days < 7) {
				//  '3' => '5-6 daily',
				$sub_template_id = 2;
				$rate_type = 'daily';
			} else if ($days == 7) {
				//'4' => '7 fixed',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			} else if ($days > 7 && $days < 14) {
				//'5' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'6' => '14 fixed',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			} else if ($days > 14 && $days < 21) {
				//'7' => '15-20 daily',
				$sub_template_id = 6;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'8' => '21 fixed',
				$sub_template_id = 7;
				$rate_type = 'fixed';
			} else if ($days == 21) {
				//'9' => '21+ daily',
				$sub_template_id = 8;
				$rate_type = 'daily';
			}
		}
		// template_id 5
		if ($templateId == 5) {
			if ($days==1) {
				$sub_template_id =0;
				$rate_type = 'fixed';
			}else if ($days == 2) {
				//'8' => '8-13 daily',
				$sub_template_id = 1;
				$rate_type = 'fixed';
			}else if ($days==3) {
				$sub_template_id = 2;
				$rate_type = 'fixed';
			}else if ($days==4) {
				//'8' => '8-13 daily',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			}else if ($days==5) {
				//'8' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'fixed';
			}else if ($days==6) {
				//'8' => '8-13 daily',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			}else if ($days==7) {
				//'8' => '8-13 daily',
				$sub_template_id = 6;
				$rate_type = 'fixed';
			}
			else if ($days > 7 && $days < 14) {
				//'8' => '8-13 daily',
				$sub_template_id = 7;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'9' => '14 fixed',
				$sub_template_id = 8;
				$rate_type = 'fixed';
			} else if ($days > 15 && $days < 21) {
				//'10' => '15-20 daily',
				$sub_template_id = 9;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'11' => '21 fixed',
				$sub_template_id = 10;
				$rate_type = 'fixed';
			} else if ($days > 21) {
				//'12' => '21+ daily',
				$sub_template_id =11 ;
				$rate_type = 'daily';
			}
		}
		// template_id 6
		if ($templateId == 6) {
			if ($days==1) {
				$sub_template_id =0;
				$rate_type = 'fixed';
			}else if ($days == 2) {
				//'8' => '8-13 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			}else if ($days==3) {
				$sub_template_id = 2;
				$rate_type = 'daily';
			}else if ($days==4) {
				//'8' => '8-13 daily',
				$sub_template_id = 3;
				$rate_type = 'daily';
			}else if ($days==5) {
				//'8' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';
			}else if ($days==6) {
				//'8' => '8-13 daily',
				$sub_template_id = 5;
				$rate_type = 'daily';
			}else if ($days==7) {
				//'8' => '8-13 daily',
				$sub_template_id = 6;
				$rate_type = 'daily';
			}else if ($days > 7 && $days < 14) {
				//'8' => '8-13 daily',
				$sub_template_id = 7;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'9' => '14 fixed',
				$sub_template_id = 8;
				$rate_type = 'fixed';
			} else if ($days > 15 && $days < 21) {
				//'10' => '15-20 daily',
				$sub_template_id = 9;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'11' => '21 fixed',
				$sub_template_id = 10;
				$rate_type = 'fixed';
			} else if ($days >= 20 && $days <= 26) {
				//'12' => '22-26 daily'
				$sub_template_id = 11;
				$rate_type = 'daily';
			} else if ($days == 27) {
				//'13' => '27 fixed',
				$sub_template_id = 12;
				$rate_type = 'fixed';
			} else if ($days > 27) {
				//'14' => '27+  daily',
				$sub_template_id = 13;
				$rate_type = 'daily';
			}
		}

		// template_id 7
		if ($templateId == 7) {
			if ($days==1) {
				$sub_template_id =0;
				$rate_type = 'fixed';
			}else if ($days == 2) {
				//'8' => '8-13 fixed',
				$sub_template_id = 1;
				$rate_type = 'fixed';
			}else if ($days==3) {
				$sub_template_id = 2;
				$rate_type = 'fixed';
			}else if ($days==4) {
				//'8' => '8-13 fixed',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			}else if ($days==5) {
				//'8' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'fixed';
			}else if ($days==6) {
				//'8' => '8-13 fixed',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			}else if ($days==7) {
				//'8' => '8-13 fixed',
				$sub_template_id = 6;
				$rate_type = 'daily';
			}else if ($days==8) {
				//'8' => '8-13 fixed',
				$sub_template_id = 7;
				$rate_type = 'fixed';
			}else if ($days==9) {
				//'8' => '8-13 fixed',
				$sub_template_id = 8;
				$rate_type = 'fixed';
			}else if ($days==10) {
				//'8' => '8-13 fixed',
				$sub_template_id = 9;
				$rate_type = 'fixed';
			}
			else if ($days==11) {
				//'8' => '8-13 fixed',
				$sub_template_id = 10;
				$rate_type = 'fixed';
			}
			else if ($days==12) {
				//'8' => '8-13 fixed',
				$sub_template_id = 11;
				$rate_type = 'fixed';
			}
			else if ($days==13) {
				//'8' => '8-13 fixed',
				$sub_template_id = 12;
				$rate_type = 'fixed';
			}
			else if ($days==14) {
				//'8' => '8-13 fixed',
				$sub_template_id = 13;
				$rate_type = 'fixed';
			}
			else if ($days > 15 && $days < 21) {
				//'15' => '15-20 fixed',
				$sub_template_id = 15;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'16' => '21 fixed',
				$sub_template_id = 16;
				$rate_type = 'fixed';
			} else if ($days >= 20 && $days <= 26) {
					//'17' => '22-26 daily'
				$sub_template_id = 17;
				$rate_type = 'daily';
			} else if ($days == 27) {
				//'18' => '27 fixed',
				$sub_template_id = 18;
				$rate_type = 'fixed';
			} else if ($days > 27) {
				//'19' => '27+  daily',
				$sub_template_id = 27;
				$rate_type = 'daily';
			}
		}
		// template_id 8
		if ($templateId == 8) {
			if ($days < 7) {
				//'1' => 'daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if ($days == 7) {
				//'2' => 'weekly',
				$sub_template_id = 1;
				$rate_type = 'weekly';
			}
		}
		// template_id 9
		if ($templateId == 9) {
			if ($days < 3) {
				//'1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if ($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} else if ($days == 7) {
					//'3' => 'weekly',
				$sub_template_id = 2;
				$rate_type = 'weekly';
			} else if ($days > 4 && $days < 7) {
				//'4' => '+ daily',
				$sub_template_id = 3;
				$rate_type = 'daily';
			}
		}
	
		return $sub_template_id.'-'.$rate_type;
	
	}
	
	
	
	
	
}