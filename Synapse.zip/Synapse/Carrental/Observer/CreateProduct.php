<?php

namespace Synapse\Carrental\Observer;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Catalog\Controller\Adminhtml\Product\Builder;
use Magento\Catalog\Controller\Adminhtml\Product\Initialization\Helper;

use Synapse\Carrental\Model\CarModelImagesFactory;
use Synapse\Carrental\Model\VehiclepricelistFactory;
use Synapse\Carrental\Model\VehiclepricelistseasonsFactory;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
use Magento\Customer\Model\Session; 
class CreateProduct implements \Magento\Framework\Event\ObserverInterface
{
	 
	 /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var DataPersistorInterface
     */
    protected $dataPersistor;

    /**
     * @var StoreManagerInterface
     */
    private $storeManager;
	
	private $productTypeManager;
	
	private $pricelistFactory;
	private $pricelistseasonsFactory;
	private $seasonalpriceFactory;
	
	/**
     * @var Initialization\Helper
     */
    protected $initializationHelper;
	/**
     * @var app/request
     */
	protected $_request;
	
	/**
     * @var return product model
     */
	protected $productModel;
	protected $_logger;
	protected $carModelImagesFactory;
	protected $directoryList;
	protected $_customerSession;
	protected $_productModelFactory;
	
	

	 /**
     * Save constructor.
     *
     * @param Action\Context $context
     * @param Builder $productBuilder
     * @param Initialization\Helper $initializationHelper
     */
    public function __construct(
        \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
		StoreManagerInterface $StoreManagerInterface,
		RequestInterface $request,
		DataPersistorInterface $DataPersistorInterface,
		VehiclepricelistFactory $VehiclepricelistFactory,
		VehiclepricelistseasonsFactory $VehiclepricelistseasonsFactory, 
		VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
		\Magento\Catalog\Model\Product $productModel,
		\Magento\Catalog\Model\ProductFactory $productModelFactory,
		\Psr\Log\LoggerInterface $logger,
		\Magento\Framework\App\Filesystem\DirectoryList $DirectoryList,
		CarModelImagesFactory $CarModelImagesFactory,
		Session $customerSession
    ) {
      
        $this->productRepository = $productRepository;
		$this->storeManager = $StoreManagerInterface;
		$this->pricelistFactory = $VehiclepricelistFactory;
		$this->pricelistseasonsFactory = $VehiclepricelistseasonsFactory;
		$this->seasonalpriceFactory = $VehicleseasonalpriceFactory;
		$this->_request  = $request;
		$this->productModel = $productModel;
		$this->_logger = $logger;
		$this->carModelImagesFactory = $CarModelImagesFactory;
		$this->directoryList = $DirectoryList;
		$this->_customerSession = $customerSession;
		$this->_productModelFactory = $productModelFactory;
         
    }
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$customerId = $this->_customerSession->getCustomer()->getId();
		$data = $observer->getData('ids');
		$ids = implode(',',$data->getIds());
			if ($data) {
				try {
					$seasonalpriceModel = $this->seasonalpriceFactory->create();
					$seasonalpriceCollection = $seasonalpriceModel->getCollection();
					$seasonalpriceCollection->getSelect()->joinLeft(
						[
						 "carmodeltble"=>$seasonalpriceCollection->getTable('wais_carmodel')
						],
						'main_table.car_model_id=carmodeltble.id',
						[
							"carmodeltble.vehicle_name","carmodeltble.vehicle_category_type",
							"carmodeltble.vehicle_type"
						]
					);
					$seasonalpriceCollection->getSelect()->joinLeft(
						[
						 "vdirectory"=>$seasonalpriceCollection->getTable('waissupplier_vehicle_direrctory')
						],
						'vdirectory.car_model_id=carmodeltble.id',
						[
							"vdirectory.qty as sqty","vdirectory.carmodel_class","vdirectory.vehicle_transmission","vdirectory.vehicle_fuel"
							
						]
					);
					/*$seasonalpriceCollection->getSelect()->joinLeft(
						[
						 "carmodelimages"=>$seasonalpriceCollection->getTable('wais_carmodel_images')
						],
						'carmodelimages.carmodel_id=carmodeltble.id',
						[
							"carmodelimages.url",
							"carmodelimages.image_type",
						]
					);*/
					$seasonalpriceCollection->addFieldToFilter('main_table.id',array('in'=>$ids));
					$seasonalpriceCollection->addFieldToFilter('vdirectory.supplier_id',array('eq'=>$customerId));
					$seasonalpriceCollection->getSelect()->group('car_model_id');
					if($seasonalpriceCollection){
						$seaarr =[];
						$carmodelId = [];
						$productarr = [];
						$createdProductId = [];
						 foreach($seasonalpriceCollection as $_val):
						//var_dump($_val->getId());
							//if(!in_array($_val->getSessionId(),$seaarr)){
								//if(!in_array($_val->getCarModelId(),$carmodelId)){
									//$carmodelId[] = $_val->getCarModelId();
									$productId = $this->createProducts($_val);
									 
								//}
							//}
						endforeach;
						 
					}
					 
				}catch(Exception $e){
					$this->_logger->addDebug('creating products....'.$e->getMessage()."<br/>");
						 
				}
			

			}	
		
		return $this;
	}
	public function createProducts($_val){
		try{
			if($_val->getSqty()){
				$isProduct = '';
				//$product = $this->productModel;
				$product = $this->_productModelFactory->create();
				$isProduct = $product->load($product->getIdBySku(
					'SU-'.$_val->getSupplierId().'SE-'.$_val->getSeasonId().'CM-'.$_val->getCarModelId())
				);
				if(isset($isProduct) && $isProduct->getSku()!=''){
					$product = $isProduct;
				}
				$product->setSku(
				'SU-'.$_val->getSupplierId().'SE-'.$_val->getSeasonId().'CM-'.$_val->getCarModelId()
				);  
				$product->setName($_val->getVehicleName());  
				$product->setAttributeSetId(4); 
				$product->setStatus(1); 
				$product->setWeight('');
				$product->setVisibility(4); 
				$product->setTaxClassId(0); 
				$product->setTypeId('simple');
				$product->setPrice('');
				$product->addData(array('supplier_id' => $_val->getSupplierId()));
				$product->addData(array('template_id' => $_val->getTemplateId()));
				//$product->addData(array('vehicle_fuel' => $_val->getVehicleFuel()));
				
				$product->addData(array('warehouse_id' =>  $_val->getWarehouseId()));

				$tId = $this->getVehicleTransmissionId($_val->getVehicleTransmission());
				$fId = $this->getVehicleFuelId($_val->getVehicleFuel());
				$cId = $this->getVehicleCategory($_val->getVehicleCategoryType());
				$tpId = $this->getVehicleType($_val->getVehicleType());
				$product->addData(
					array('vehicle_transmission' => $tId)
				); 
				$product->addData(
					array('vehicle_fuel' => $fId)
				); 
				$product->addData(
					array('vehicle_category' => $cId)
				);
				$product->addData(
					array('vehicle_type' => $tpId)
				);					
				
				$product->setUrlKey($_val->getVehicleName().$_val->getSupplierId().$_val->getSeasonId().$_val->getCarModelId());
			     $product->setStockData(
						[
							'use_config_manage_stock' => 1,
							'manage_stock' => 1,
							'is_in_stock' => 1,
							'qty' =>$_val->getSqty()
						]
				);
				$product->setWebsiteIds([0,1]);
				$product->setCategoryIds([4]);
				$images = $this->getCarmodelImages($_val->getCarModelId());
				$this->addImagesToGallery($images,$product);
				$isSaved = $product->save();
				$productId = '';
				$productId = $isSaved->getId();
				$this->updateProductIds($productId,$_val);
				 unset($product);
				 
				$this->_logger->info('Successfully created for'.$_val->getCarModelId()."<br/>");
			}else{
				$this->_logger->addDebug('creating not products for qty '.$_val->getCarModelId()."<br/>");
				 
			}
			//return true;
		}catch(Exception $e){
			$this->_logger->addDebug($e->getMessag());
		}
	}
	public function getCarmodelImages($carModelId){
		$imageModel = $this->carModelImagesFactory->create();
		$carModelImagesCollection = $imageModel->getCollection();
		$carModelImagesCollection->addFieldToFilter('carmodel_id',$carModelId);
		return $carModelImagesCollection;
	}
	private function updateProductIds($productId,$_val){
		$seasonsPriceModel = $this->seasonalpriceFactory->create();
		$seasonsPriceCollection1 = $seasonsPriceModel->getCollection();
		$seasonsPriceCollection1->addFieldToFilter('car_model_id',['eq'=>$_val->getCarModelId()]);
		$seasonsPriceCollection1->addFieldToFilter('supplier_id',['eq'=>$_val->getSupplierId()]);
		$seasonsPriceCollection1->addFieldToFilter('pricelist_id',['eq'=>$_val->getPricelistId()]);
		if($seasonsPriceCollection1){
			foreach($seasonsPriceCollection1 as $_up){
					$seasonsPriceModel1 = $this->seasonalpriceFactory->create();
					$seasonsPriceModel1->load($_up->getId());
					$seasonsPriceModel1->setId($_up->getId());
					$seasonsPriceModel1->setProductId($productId);
					$seasonsPriceModel1->save();
			}
			 
		} 
		return true;
	}
	private function addImagesToGallery($images,$product){
		if($images){
				$abspath = $this->directoryList->getPath('media').'/carrental/media/';
				foreach($images as $_img):
					if($_img->getImageType()!=''){
							$product->setImage(
							  $abspath.basename($_img->getUrl())
							)
							->setSmallImage(
							   $abspath.basename($_img->getUrl())
							)
							->setThumbnail(
								$abspath.basename($_img->getUrl())
							);
					}
					$product->addImageToMediaGallery($abspath.basename($_img->getUrl()), array('image', 'small_image', 'thumbnail'), false, false);
				endforeach;
		}
		return ;
		
	}
	private function getVehicleTransmissionId($tcode){
		$arr=[
			'M'=>1,
			'N'=>2,
			'C'=>3,
			'A'=>4,
			'B'=>5,
			'D'=>6
		];
		return $arr[$tcode];
	}
	private function getVehicleFuelId($fcode){
		$arr=[
			'R'=>1,
			'N'=>2,
			'D'=>3,
			'Q'=>4,
			'H'=>5,
			'I'=>6,
			'E'=>7,
			'C'=>8,
			'L'=>9,
			'S'=>10,
			'A'=>11,
			'B'=>12,
			'M'=>13,
			'F'=>14,
			'V'=>15,
			'Z'=>16,
			'U'=>17,
			'X'=>18,
		];
	 return $arr[$fcode];
	}
	private function getVehicleCategory($ccode){
		$arr = [
				'M'=>'1',
				'N'=>'2',
				'E'=>'3',
				'H'=>'4',
				'C'=>'5',
				'D'=>'6',
				'I'=>'7',
				'J'=>'8',
				'S'=>'9',
				'R'=>'10',
				'F'=>'11',
				'G'=>'12',
				'P'=>'13',
				'U'=>'14',
				'L'=>'15',
				'W'=>'16',
				'O'=>'17',
				'X'=>'18',
			];
			
		return $arr[$ccode];
		
	}
	public function getVehicleType($tycode){
			$arr = [
				'B' =>'1',
				'C' =>'2',
				'D' =>'3',
				'W' =>'4',
				'V' =>'5',
				'L' =>'6',
				'S' =>'7',
				'T' =>'8',
				'F' =>'9',
				'J' =>'10',
				'X' =>'11',
				'P' =>'12',
				'E' =>'13',
				'Z' =>'14',
				'M' =>'15',
				'R' =>'16',
				'H' =>'17',
				'Y' =>'18',
				'N' =>'19',
				'G' =>'20',
				'K' =>'21',
			
			];
			return $arr[$tycode];
	}
	
}