<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 02/04/2017
 * Time: 10:24
 */
namespace Synapse\Carrental\Observer\Contacts;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Psr\Log\LoggerInterface as Logger;
use Magento\Store\Model\ScopeInterface;

/**
 * Class Update
 * @package Magenest\RentalAndBookingSystem\Observer\Frontend\Option
 */
class MassTemplate implements ObserverInterface
{
    /**
     * @var Logger
     */
    protected $_logger;
	
    /**
     * 
     * @var type
     * request object
     */
    private $_request;
	
	protected $_transportBuilder;
	 
	protected $_storeManager;
	
	protected $_inlineTranslation;
	
	protected $_scopeConfig;
	
	protected $_customerSession;

    /**
     * Update constructor.
    
     */
    public function __construct(
		\Magento\Framework\App\Action\Context $context,
        RequestInterface $request,
	   \Magento\Customer\Model\Session $customerSession,
	   \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
	   \Magento\Framework\Translate\Inline\StateInterface $stateInterface,
	   \Magento\Store\Model\StoreManagerInterface $storeManager,
	   \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
	   Logger $logger
    ) {
	   $this->_customerSession = $customerSession;
       $this->_request = $request;
	   $this->_logger = $logger;
	   $this->_transportBuilder = $transportBuilder;
	   $this->_inlineTranslation = $stateInterface;
       $this->_storeManager = $storeManager;
	   $this->_scopeConfig = $scopeConfig;
    }

    /**
     * @param Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {

		/* Config value
		$email = $this->_scopeConfig->getValue('trans_email/ident_support/email', ScopeInterface::SCOPE_STORE);
		$name = $this->_scopeConfig->getValue('trans_email/ident_support/name', ScopeInterface::SCOPE_STORE);
		*/
		$data = $observer->getData();
		
		$supplier_id = $data['supplier_id'];
		$action = $data['action'];
		$items = $data['items'];
		$customMessage  = 'Below Contacts(s) are deleted:';
		/* echo "<pre>";
		print_r($items->getData()); die; */
		
		/* Sender Detail (Admin) */
		$sender = [
			'name' => 'Reciver Name',
			'email' => 'rockingteamf1824@gmail.com'
		];
		 
		 
		/* receiver Detail  (supplier,Bcc:to Admin) */
		$receiver = [
			'name' => 'Sender Name',
			'email' => 'rockingteamf@gmail.com',
		];
		
		/* 
		$suplierName = $this->_customerSession->getCustomer()->getName(); 
		$suplierEmail = $this->_customerSession->getCustomer()->getEmail(); 
		
		*/
		 
		$bccAdmin = [
			'name' => 'Sender Name',
			'email' => 'rockingteamf@gmail.com',
		];
		
		$templateVars = array(
			'store' => $this->_storeManager->getStore(),
			'customer_name' => 'John Doe',
			'message'   => $customMessage,
			'items' => $items->getData(),
			'types' => 'contacts'
		);
		
				
		$transport = $this->_transportBuilder->setTemplateIdentifier('mass_template')
		->setTemplateOptions([
			'area' => \Magento\Framework\App\Area::AREA_FRONTEND, 
			'store' => $this->_storeManager->getStore()->getId()]
			)
		->setTemplateVars($templateVars)
		->setFrom($sender)
		->addTo($receiver)
		->getTransport();
		
		$transport->sendMessage();
		$this->_inlineTranslation->resume();

    }
}
