<?php
namespace Synapse\Carrental\Plugin\Model\Checkout\Cart;

use Magento\Framework\Exception\LocalizedException;

class Plugin
{
    /**
     * @var \Magento\Quote\Model\Quote
     */
    protected $quote;
	protected $cartHelper;

    /**
     * Plugin constructor.
     *
     * @param \Magento\Checkout\Model\Session $checkoutSession
     */
    public function __construct(
        \Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Checkout\Helper\Cart $cartHelper
    ) {
        $this->quote = $checkoutSession->getQuote();
		 $this->cartHelper = $cartHelper;
    }

    /**
     * beforeAddProduct
     *
     * @param      $subject
     * @param      $productInfo
     * @param null $requestInfo
     *
     * @return array
     * @throws LocalizedException
     */
    public function beforeAddProduct($subject, $productInfo, $requestInfo = null)
    {
		if ($this->cartHelper->getItemsCount() != 0) {
            throw new LocalizedException(__('Item is already in cart for booking.'));
		}
        return [$productInfo, $requestInfo];
    }
}