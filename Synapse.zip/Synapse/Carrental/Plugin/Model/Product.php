<?php
namespace Synapse\Carrental\Plugin\Model;

use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\RequestInterface;
use Synapse\Carrental\Model\VehicleseasonalpriceFactory;
class Product
{
	protected $categoryFactory;
	protected $collectionFactory;
	protected $state;
	protected $_registry;
	protected $_request;
	private $seasonalpriceFactory;
	
	public function __construct(
	\Magento\Catalog\Model\CategoryFactory $categoryFactory,
	\Magento\Framework\App\State $state,
	 \Magento\Framework\Registry $registry,
	 VehicleseasonalpriceFactory $VehicleseasonalpriceFactory,
	 RequestInterface $request
	){
    
		$this->categoryFactory = $categoryFactory;
		$this->state = $state;
		$this->_registry = $registry;
		$this->_request  = $request;
		$this->seasonalpriceFactory = $VehicleseasonalpriceFactory;
		
		
	}
	public function afterGetPrice(\Magento\Catalog\Model\Product $subject, $result)
    {
		
		return $result ;
		$request = $this->_request->getParams();
		if($request){
			$pickup_date = date('Y-m-d',strtotime($request['pickup_date']));
			$pickup_time = $request['pickup_time'];
			$dropoff_date = date('Y-m-d',strtotime($request['dropoff_date']));
			$dropff_time = $request['dropoff_time'];
			$price = '';
			
			$totalrecordCollection =  $this->_registry->registry('totalrecords');
			$totalrecordCollection1 = $totalrecordCollection->load();
			$totalrecordCollection1->addFieldToFilter('product_id',['eq'=>$subject->getId()]);
			$totalrecordCollection1->getSelect()->group('season_from_date');
			
			if($totalrecordCollection1){
				foreach($totalrecordCollection1 as $_rec):
						if($_rec->getSeasonFromDate() <=$pickup_date )
							$d_1 = $pickup_date;
						else
							$d_1 = $_rec->getSeasonFromDate(); 
				
						if ($_rec->getSeasonFromDate() >= $dropoff_date)
							$d_2 = $dropoff_date;
						else
							$d_2 = $_rec->getSeasonToDate();
						
					$d_1 = strtotime($d_1 . $pickup_time);
					$d_2 = strtotime($d_2 . $dropff_time);
					
					$totaldaysofbookinginSeason = ($d_2 - $d_1);
					$totaldaysofbookinginSeason =ceil($totaldaysofbookinginSeason/86400);
					$price += $this->calculatePrice($_rec,$totaldaysofbookinginSeason);
				endforeach;
				 
				$totalrecordCollection1->clear()->getSelect()->reset('where');	
				unset($totalrecordCollection1);
				unset($totalrecordCollection);
				
			}
		}
		$result = $result+ $price;
		
		
				
        return $result;
    }
	public function calculatePrice($_rec,$totaldaysofbookinginSeason){
		$templateId = 	$_rec->getTemplateId();
		$sub_template_id = $this->subTemplateId($templateId,$totaldaysofbookinginSeason);
		$subtemparr = explode('-',$sub_template_id);
		$sub_template_id = $subtemparr[0];
		$type = $subtemparr[1];
		$price = '';
		/*$totalrecordCollection1 = '';
		$totalrecordCollection1 =  $this->_registry->registry('totalrecords');
		$totalrecordCollection1 = $totalrecordCollection1->load();
		$totalrecordCollection1->addFieldToFilter('product_id',$_rec->getProductId());
		$totalrecordCollection1->addFieldToFilter('template_id',$_rec->getTemplateId());
		$totalrecordCollection1->addFieldToFilter('season_id',$_rec->getSeasonId());
		$totalrecordCollection1->addFieldToFilter('sub_template_id',$_rec->getSubTemplateId());
		 
		
		$price = $totalrecordCollection1->getFirstItem()->getPrice();
		$totalrecordCollection1->clear()->getSelect()->reset('where');
		 
		unset($totalrecordCollection1);*/
		$calculatedP = '';
		if($type=='daily'){
			$calculatedP = $price*$totaldaysofbookinginSeason;
		}else if ($type=='fixed'){
			$calculatedP = $price;
		}else if ($type=='weekly'){
			$week_count = (int) ($totaldaysofbookinginSeason / 7);
			$calculatedP = $price*$week_count;
			$remaining_day = ( $totaldaysofbookinginSeason % 7);
			if($remaining_day>0) {
				$subtemp1 = $this->subTemplateId($templateId,$remaining_day);
				$subtemparr1 = explode('-',$subtemp1);
				$sub_template_id1 = $subtemparr1[0];
				
				//$totalrecordCollection =  $this->_registry->registry('totalrecords');
				//$totalrecordCollection->addFieldToFilter('product_id',$_rec->getProductId());
				//$totalrecordCollection->addFieldToFilter('template_id',$_rec->getTemplateId());
				//$totalrecordCollection->addFieldToFilter('season_id',$_rec->getSeasonId());
				//$totalrecordCollection->addFieldToFilter('sub_template_id',$sub_template_id1);
				//$price = $totalrecordCollection->getFirstItem()->getPrice();
				$calculatedP += $price*$remaining_day;
			}
			
		}
		return $calculatedP;
		
	}
	public function subTemplateId($templateId,$days){
		if ($templateId == 1) {
			if ($days < 3) {
				//  '1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			}
			elseif ($days > 2 && $days < 5)
			{
				// '2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} elseif($days > 4 && $days < 8)
			{
				// '3' => '5-7 daily',
				$sub_template_id = 2;
				$rate_type = 'fixed';
			}else if ($days > 7 && $days < 14)
			{
				//  '4' => '8-13 daily',
				$sub_template_id = 3;
				$rate_type = 'daily';
			}else if ($days == 14)
			{
					// '5' => '14 fixed',
				$sub_template_id = 4;
				$rate_type = 'fixed';
			} else if ($days > 14)
			{
				//   '6' => '14+ daily',
				$sub_template_id = 5;
				$rate_type = 'daily';
			}

        } else
			// template_id 2
		if ($templateId == 2) {
			if ($days < 3) {
				// '1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} elseif ($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} elseif ($days > 4 && $days < 7) {
				//'3' => '5-6 daily',
				$sub_template_id = 2;
				$rate_type = 'daily';
			} else if ($days == 7) {
					//'4' => '7 fixed',
				$sub_template_id =3;
				$rate_type = 'fixed';
			} else if (7 < $days && $days < 14) {
					// '5' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';

            } else if ($days == 14) {
				$sub_template_id = 5;
				//'6' => '14 fixed',
				$rate_type = 'fixed';
			} else if ($days > 14) {
				//'7' => '14+ daily',
				$sub_template_id = 6;
				$rate_type = 'daily';

            }
		}
		// template_id 3
		if ($templateId == 3) {
			if ($days < 3) {
				//'1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} else if ($days > 4 && $days < 7) {
				//'3' => '5-6 daily',
				$sub_template_id = 2;
				$rate_type = 'daily';
			} else if ($days == 7) {
				//'4' => '7 fixed',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			} else if ($days > 7 && $days < 14) {
				//'5' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'7' => '14 fixed',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			} else if ($days > 14) {
				//'8' => '14+  daily',
				$sub_template_id = 6;
				$rate_type = 'daily';
			}
		}
		// template_id 4
		if ($templateId == 4) {
			if ($days < 3) {
				// '1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if ($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} else if ($days > 4 && $days < 7) {
				//  '3' => '5-6 daily',
				$sub_template_id = 2;
				$rate_type = 'daily';
			} else if ($days == 7) {
				//'4' => '7 fixed',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			} else if ($days > 7 && $days < 14) {
				//'5' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'6' => '14 fixed',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			} else if ($days > 14 && $days < 21) {
				//'7' => '15-20 daily',
				$sub_template_id = 6;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'8' => '21 fixed',
				$sub_template_id = 7;
				$rate_type = 'fixed';
			} else if ($days == 21) {
				//'9' => '21+ daily',
				$sub_template_id = 8;
				$rate_type = 'daily';
			}
		}
		// template_id 5
		if ($templateId == 5) {
			if ($days==1) {
				$sub_template_id =0;
				$rate_type = 'fixed';
			}else if ($days == 2) {
				//'8' => '8-13 daily',
				$sub_template_id = 1;
				$rate_type = 'fixed';
			}else if ($days==3) {
				$sub_template_id = 2;
				$rate_type = 'fixed';
			}else if ($days==4) {
				//'8' => '8-13 daily',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			}else if ($days==5) {
				//'8' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'fixed';
			}else if ($days==6) {
				//'8' => '8-13 daily',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			}else if ($days==7) {
				//'8' => '8-13 daily',
				$sub_template_id = 6;
				$rate_type = 'fixed';
			}
			else if ($days > 7 && $days < 14) {
				//'8' => '8-13 daily',
				$sub_template_id = 7;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'9' => '14 fixed',
				$sub_template_id = 8;
				$rate_type = 'fixed';
			} else if ($days > 15 && $days < 21) {
				//'10' => '15-20 daily',
				$sub_template_id = 9;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'11' => '21 fixed',
				$sub_template_id = 10;
				$rate_type = 'fixed';
			} else if ($days > 21) {
				//'12' => '21+ daily',
				$sub_template_id =11 ;
				$rate_type = 'daily';
			}
		}
		// template_id 6
		if ($templateId == 6) {
			if ($days==1) {
				$sub_template_id =0;
				$rate_type = 'fixed';
			}else if ($days == 2) {
				//'8' => '8-13 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			}else if ($days==3) {
				$sub_template_id = 2;
				$rate_type = 'daily';
			}else if ($days==4) {
				//'8' => '8-13 daily',
				$sub_template_id = 3;
				$rate_type = 'daily';
			}else if ($days==5) {
				//'8' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'daily';
			}else if ($days==6) {
				//'8' => '8-13 daily',
				$sub_template_id = 5;
				$rate_type = 'daily';
			}else if ($days==7) {
				//'8' => '8-13 daily',
				$sub_template_id = 6;
				$rate_type = 'daily';
			}else if ($days > 7 && $days < 14) {
				//'8' => '8-13 daily',
				$sub_template_id = 7;
				$rate_type = 'daily';
			} else if ($days == 14) {
				//'9' => '14 fixed',
				$sub_template_id = 8;
				$rate_type = 'fixed';
			} else if ($days > 15 && $days < 21) {
				//'10' => '15-20 daily',
				$sub_template_id = 9;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'11' => '21 fixed',
				$sub_template_id = 10;
				$rate_type = 'fixed';
			} else if ($days >= 20 && $days <= 26) {
				//'12' => '22-26 daily'
				$sub_template_id = 11;
				$rate_type = 'daily';
			} else if ($days == 27) {
				//'13' => '27 fixed',
				$sub_template_id = 12;
				$rate_type = 'fixed';
			} else if ($days > 27) {
				//'14' => '27+  daily',
				$sub_template_id = 13;
				$rate_type = 'daily';
			}
		}

		// template_id 7
		if ($templateId == 7) {
			if ($days==1) {
				$sub_template_id =0;
				$rate_type = 'fixed';
			}else if ($days == 2) {
				//'8' => '8-13 fixed',
				$sub_template_id = 1;
				$rate_type = 'fixed';
			}else if ($days==3) {
				$sub_template_id = 2;
				$rate_type = 'fixed';
			}else if ($days==4) {
				//'8' => '8-13 fixed',
				$sub_template_id = 3;
				$rate_type = 'fixed';
			}else if ($days==5) {
				//'8' => '8-13 daily',
				$sub_template_id = 4;
				$rate_type = 'fixed';
			}else if ($days==6) {
				//'8' => '8-13 fixed',
				$sub_template_id = 5;
				$rate_type = 'fixed';
			}else if ($days==7) {
				//'8' => '8-13 fixed',
				$sub_template_id = 6;
				$rate_type = 'daily';
			}else if ($days==8) {
				//'8' => '8-13 fixed',
				$sub_template_id = 7;
				$rate_type = 'fixed';
			}else if ($days==9) {
				//'8' => '8-13 fixed',
				$sub_template_id = 8;
				$rate_type = 'fixed';
			}else if ($days==10) {
				//'8' => '8-13 fixed',
				$sub_template_id = 9;
				$rate_type = 'fixed';
			}
			else if ($days==11) {
				//'8' => '8-13 fixed',
				$sub_template_id = 10;
				$rate_type = 'fixed';
			}
			else if ($days==12) {
				//'8' => '8-13 fixed',
				$sub_template_id = 11;
				$rate_type = 'fixed';
			}
			else if ($days==13) {
				//'8' => '8-13 fixed',
				$sub_template_id = 12;
				$rate_type = 'fixed';
			}
			else if ($days==14) {
				//'8' => '8-13 fixed',
				$sub_template_id = 13;
				$rate_type = 'fixed';
			}
			else if ($days > 15 && $days < 21) {
				//'15' => '15-20 fixed',
				$sub_template_id = 15;
				$rate_type = 'daily';
			} else if ($days == 21) {
				//'16' => '21 fixed',
				$sub_template_id = 16;
				$rate_type = 'fixed';
			} else if ($days >= 20 && $days <= 26) {
					//'17' => '22-26 daily'
				$sub_template_id = 17;
				$rate_type = 'daily';
			} else if ($days == 27) {
				//'18' => '27 fixed',
				$sub_template_id = 18;
				$rate_type = 'fixed';
			} else if ($days > 27) {
				//'19' => '27+  daily',
				$sub_template_id = 27;
				$rate_type = 'daily';
			}
		}
		// template_id 8
		if ($templateId == 8) {
			if ($days < 7) {
				//'1' => 'daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if ($days == 7) {
				//'2' => 'weekly',
				$sub_template_id = 1;
				$rate_type = 'weekly';
			}
		}
		// template_id 9
		if ($templateId == 9) {
			if ($days < 3) {
				//'1' => '1-2 daily',
				$sub_template_id = 0;
				$rate_type = 'daily';
			} else if ($days > 2 && $days < 5) {
				//'2' => '3-4 daily',
				$sub_template_id = 1;
				$rate_type = 'daily';
			} else if ($days == 7) {
					//'3' => 'weekly',
				$sub_template_id = 2;
				$rate_type = 'weekly';
			} else if ($days > 4 && $days < 7) {
				//'4' => '+ daily',
				$sub_template_id = 3;
				$rate_type = 'daily';
			}
		}
	
		return $sub_template_id.'-'.$rate_type;
	
	}
	 
}