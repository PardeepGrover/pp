<?php

namespace Synapse\Carrental\Model\CarModel\Source;

class Regions implements \Magento\Framework\Option\ArrayInterface
{
    public function toOptionArray()
    {
        return [
             [
                'label' => 'optgroup 1',
                'value' => [
                    [
                        'label' => 'in opt group 1-1',
                        'value' => 'value 1-1'
                    ],
                    [
                        'label' => 'in opt group 1-2',
                        'value' => 'value 1-2'
                    ],
                    [
                        'label' => 'in opt group 1-3',
                        'value' => 'value 1-3'
                    ],
                ]
            ],
            [
                'label' => 'optgroup 2',
                'value' => [
                    [
                        'label' => 'in opt group 2-1',
                        'value' => 'value 2-1'
                    ],
                    [
                        'label' => 'in opt group 2-2',
                        'value' => 'value 2-2'
                    ],
                    [
                        'label' => 'in opt group 2-3',
                        'value' => 'value 2-3'
                    ],
                ]
            ]
        ];
    }
}

