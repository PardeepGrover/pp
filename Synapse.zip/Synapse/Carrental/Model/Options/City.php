<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Model\Options;

use Magento\Framework\Data\OptionSourceInterface;


/**
 * Class Transmission
 */
class City implements OptionSourceInterface
{
    
    /**
     * @var array
     */
    protected $options;
	
	protected $_helper;
	protected $_cityCollectionFactory;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(
	\Synapse\Carrental\Helper\Data $helper,
	\Synapse\Carrental\Model\ResourceModel\City\CollectionFactory $cityCollectionFactory
	)
    {
        $this->_helper = $helper;
        $this->_cityCollectionFactory = $cityCollectionFactory;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
		$collection = $this->_cityCollectionFactory->create();
		$arr = [];
		if($collection){
			foreach($collection as $_k=>$_val):
				$arr = [
					[
					'label' => $_val->getCityName(),
					'value' => $_val->getCityId()
					]
				];
			endforeach;
		}
		$this->options	=  $arr;//toOptionArray();
		return $this->options;
    }
}
