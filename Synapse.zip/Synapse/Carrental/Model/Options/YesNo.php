<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Model\Options;

use Magento\Framework\Data\OptionSourceInterface;


/**
 * Class Transmission
 */
class YesNo implements OptionSourceInterface
{
    
    /**
     * @var array
     */
    protected $options;
	
	protected $_helper;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(\Synapse\Carrental\Helper\Data $helper)
    {
        $this->_helper = $helper;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $options = [
			[
			'label' =>'Yes',
			'value' =>'1'
			],
			[
			'label' =>'No',
			'value' =>'0'
			],
		];
        $this->options = $options;

        return $this->options;
    }
}
