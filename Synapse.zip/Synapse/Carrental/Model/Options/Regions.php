<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Model\Options;

use Magento\Framework\Data\OptionSourceInterface;


/**
 * Class Transmission
 */
class Regions implements OptionSourceInterface
{
    
    /**
     * @var array
     */
    protected $options;
	
	protected $_helper;
	protected $_regionCollectionFactory;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(
	\Synapse\Carrental\Helper\Data $helper,
	\Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory
	)
    {
        $this->_helper = $helper;
        $this->_regionCollectionFactory = $regionCollectionFactory;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
		$collection = $this->_regionCollectionFactory->create();
		$this->options	=  $collection->toOptionArray();
		return $this->options;
    }
}
