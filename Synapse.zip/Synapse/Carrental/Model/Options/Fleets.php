<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Model\Options;

use Magento\Framework\Data\OptionSourceInterface;
use Synapse\Carrental\Model\FleetFactory;
use Magento\Customer\Model\Session;


/**
 * Class Transmission
 */
class Fleets implements OptionSourceInterface
{
    
    /**
     * @var array
     */
    protected $options;
	
	protected $_helper;
	
	protected $_fleetModelFactory;
	
	protected $_fleetCollection;
	protected $_session;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(\Synapse\Carrental\Helper\Data $helper,
								FleetFactory $FleetFactory,
								 Session $customerSession)
    {
        $this->_helper = $helper;
		$this->_fleetModelFactory = $FleetFactory;
		$this->_fleetCollection = $this->_fleetModelFactory->create()->getCollection();
		$this->_session = $customerSession;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
        $supplierId = $this->_session->getCustomer()->getId();
		$collection = $this->_fleetCollection;
		$collection->addFieldToFilter('supplier_id',$supplierId);
		foreach($collection as $_fleet){
			
			$options[] = ['value' =>$_fleet->getId(),
						   'label'=>$_fleet->getFleetName()
						];
		}
        $this->options = $options;

        return $options;
    }
}
