<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Model\Options;

use Magento\Framework\Data\OptionSourceInterface;


/**
 * Class Transmission
 */
class Country implements OptionSourceInterface
{
    
    /**
     * @var array
     */
    protected $options;
	
	protected $_helper;
	protected $_countryCollectionFactory;

    /**
     * Constructor
     *
     * @param BuilderInterface $pageLayoutBuilder
     */
    public function __construct(
	\Synapse\Carrental\Helper\Data $helper,
	\Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory
	)
    {
        $this->_helper = $helper;
        $this->_countryCollectionFactory = $countryCollectionFactory;
    }

    /**
     * Get options
     *
     * @return array
     */
    public function toOptionArray()
    {
		$collection = $this->_countryCollectionFactory->create()->loadByStore();
		$this->options	=  $collection->toOptionArray();
		return $this->options;
    }
}
