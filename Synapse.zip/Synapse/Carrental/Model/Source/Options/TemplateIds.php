<?php
 
namespace Synapse\Carrental\Model\Source\Options;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Customer\Model;
use Magento\Framework\DB\Ddl\Table;
use Synapse\Carrental\Helper\Data as Helper;
class TemplateIds extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
	/**
	* @var OptionFactory
	*/

	protected $optionFactory;
	protected $_customerFactory;
	protected $_Helper;
	
	public function __construct(
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerFactory,
        \Magento\Framework\ObjectManagerInterface $interface,
		Helper $helper
    ) {
       $this->_customerFactory = $customerFactory;
       $this->objectManager = $interface;
       $this->_Helper = $helper;
	   
    }

	
	/**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
		$options=[ 
				['label' =>'1', 'value' =>'1'],
				['label' =>'2', 'value' =>'2'],
				['label' =>'3', 'value' =>'3'],
				['label' =>'4', 'value' =>'4'],
				['label' =>'5', 'value' =>'5'],
				['label' =>'6', 'value' =>'6'],
				['label' =>'7', 'value' =>'7'],
				['label' =>'8', 'value' =>'8'],
				['label' =>'9', 'value' =>'9'],
				['label' =>'10', 'value' =>'10']
			];
		
		//array_unshift($options, ['value' => '0', 'label' => __('-- Please Select --')]);
		
        /* your Attribute options list*/
        $this->_options= $options;
        return $this->_options;
    }
 
    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string|bool
     */
    public function getOptionText($value)
    {
        foreach ($this->getAllOptions() as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }
 
    /**
     * Retrieve flat column definition
     *
     * @return array
     */
    public function getFlatColumns()
    {
        $attributeCode = $this->getAttribute()->getAttributeCode();
        return [
            $attributeCode => [
                'unsigned' => false,
                'default' => null,
                'extra' => null,
                'type' => Table::TYPE_INTEGER,
                'nullable' => true,
                'comment' => 'Custom Attribute Options  ' . $attributeCode . ' column',
            ],
        ];
    }

    
 
}