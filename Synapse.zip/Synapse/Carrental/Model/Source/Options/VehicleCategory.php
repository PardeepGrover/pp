<?php
 
namespace Synapse\Carrental\Model\Source\Options;
use Magento\Eav\Model\ResourceModel\Entity\Attribute\OptionFactory;
use Magento\Customer\Model;
use Magento\Framework\DB\Ddl\Table;
use Synapse\Carrental\Helper\Data as Helper;

class VehicleCategory extends \Magento\Eav\Model\Entity\Attribute\Source\AbstractSource
{
	/**
	* @var OptionFactory
	*/

	protected $optionFactory;
	protected $_customerFactory;
	protected $_helper;
	
	public function __construct(
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerFactory,
        \Magento\Framework\ObjectManagerInterface $interface,
		Helper $Helper
    ) {
       $this->_customerFactory = $customerFactory;
       $this->_helper = $Helper;
       $this->objectManager = $interface;
    }

	
	/**
     * Get all options
     *
     * @return array
     */
    public function getAllOptions()
    {
		 $options = $this->_helper->getCategoryTypeOptions();
		
		//array_unshift($options, ['value' => '0', 'label' => __('-- Please Select --')]);
		
        /* your Attribute options list*/
        $this->_options= $options;
        return $this->_options;
    }
 
    /**
     * Get a text for option value
     *
     * @param string|integer $value
     * @return string|bool
     */
    public function getOptionText($value)
    {
        foreach ($this->getAllOptions() as $option) {
            if ($option['value'] == $value) {
                return $option['label'];
            }
        }
        return false;
    }
 
    /**
     * Retrieve flat column definition
     *
     * @return array
     */
    public function getFlatColumns()
    {
        $attributeCode = $this->getAttribute()->getAttributeCode();
        return [
            $attributeCode => [
                'unsigned' => false,
                'default' => null,
                'extra' => null,
                'type' => Table::TYPE_INTEGER,
                'nullable' => true,
                'comment' => 'Custom Attribute Options  ' . $attributeCode . ' column',
            ],
        ];
    }

    
 
}