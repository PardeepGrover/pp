<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\RateCode;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\App\RequestInterface;
class Collection extends AbstractCollection{
    
	private $_request;
	public function __construct(
		EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null
		//RequestInterface $request

    ) {
		$this->addFilterToMap('id', 'main_table.id');
		$this->_init(
            'Synapse\Carrental\Model\RateCode',
            'Synapse\Carrental\Model\ResourceModel\RateCode'
        );
		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		$this->storeManager = $storeManager;

    }
	 
	protected function _initSelect()
	{
	  
		parent::_initSelect();
		$this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_ratecode_country')],
						'main_table.id= secondTable.rate_code_id', 
						[
						 'secondTable.id as cid','secondTable.country_id as country_id', 'secondTable.rate_code_id as rate_code_id'
						] 
		);
		$this->getSelect()->columns(array('GROUP_CONCAT(country_id) as assigned_country'));
		$this->getSelect()->order('main_table.id DESC');
		$this->getSelect()->group('main_table.id');
		return $this;
	}
}