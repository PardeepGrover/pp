<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\Fleetcarmodels;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\App\RequestInterface;
class Collection extends AbstractCollection{
    
	private $request;
	protected $_idFieldName = 'id';
	public function __construct(
		RequestInterface $request,
		EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null
		

    ) {
		
		
		$this->addFilterToMap('id', 'main_table.id');
		$this->_init(
            'Synapse\Carrental\Model\Fleetcarmodels',
            'Synapse\Carrental\Model\ResourceModel\Fleetcarmodels'
        );
		$this->request = $request;

		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		$this->storeManager = $storeManager;
		
    }
	 
	protected function _initSelect()
	{
		//$id = $this->request->getParam('id');
		 parent::_initSelect();
		$this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_carmodel')],
						'main_table.car_model_id = secondTable.id', 
						['secondTable.id as modelid',
						 'secondTable.vehicle_name',
						 'secondTable.vehicle_category_type',
						 'secondTable.vehicle_category',
						 'secondTable.vehicle_type',
						 'secondTable.country',
						 'secondTable.c_type'
						] 
		);
		$this->getSelect()->joinLeft(
						['ThirdTable' => $this->getTable('wais_carmodel_images')],
						'main_table.car_model_id = ThirdTable.carmodel_id', 
						['ThirdTable.url',
						'ThirdTable.image_type'
						
						] 
		);
		$this->getSelect()->joinLeft(
						['forthTable' => $this->getTable('wais_carmodel_attributes')],
						'forthTable.carmodel_id = secondTable.id', 
						['forthTable.vehicle_doors',
						'forthTable.vehicle_seats',
						'forthTable.vehicle_seats',
						'forthTable.vehicle_model_year',
						'forthTable.small_bags',
						'forthTable.number_of_cases',
						'forthTable.gas',
						'forthTable.mpg',
						'forthTable.height',
						'forthTable.length',
						'forthTable.max_payload',
						'forthTable.max_capacity'
					] 
		);
		$this->getSelect()->order('main_table.id DESC');
		/*if(isset($id) && $id!=''){
			$this->getSelect()->where("main_table.fleet_id=$id");
		}*/
		
		$this->getSelect()->group('main_table.id');
		 return $this;
	}
}