<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\Regions;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\App\RequestInterface;
class Collection extends AbstractCollection{
    
	private $_request;
    public function __construct(

        EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null
		//RequestInterface $request

    ) {
		$this->_init(
            'Synapse\Carrental\Model\Regions',
            'Synapse\Carrental\Model\ResourceModel\Regions'
        );
		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		$this->storeManager = $storeManager;

    }
	protected function _initSelect()
	{
		parent::_initSelect();
		$this->addFieldToSelect('name');
		$this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_subregions')],
						'main_table.id= secondTable.region_id', 
						['main_table.id as region_id',
						 'secondTable.id as subregion_id',
						 'main_table.name as region_name',
						 'secondTable.name as subregion_name'
						] 
		);
		return $this;
	}
	
}