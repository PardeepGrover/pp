<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\Fleet;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\App\RequestInterface;
class Collection extends AbstractCollection{
    
	private $_request;
	public function __construct(
		EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null
		//RequestInterface $request

    ) {
		
		
		$this->addFilterToMap('id', 'main_table.id');
		$this->_init(
            'Synapse\Carrental\Model\Fleet',
            'Synapse\Carrental\Model\ResourceModel\Fleet'
        );
		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		$this->storeManager = $storeManager;

    }
	 
	/*protected function _initSelect()
	{
		parent::_initSelect();
		$this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_fleetcarmodels')],
						'main_table.id= secondTable.fleet_id', 
						[//'main_table.id as id',
						 'secondTable.id as id1',
						 'secondTable.fleet_id',
						 'secondTable.car_model_id',
						 'secondTable.vehicle_fuel',
						 'secondTable.vehicle_transmission',
						 'secondTable.carmodel_class',
						 'secondTable.qty',
						] 
		);
		$this->getSelect()->joinLeft(
						['thirdTable' => $this->getTable('wais_carmodel')],
						'thirdTable.id = secondTable.car_model_id', 
						['thirdTable.id as modelid',
						 'thirdTable.vehicle_name',
						 'thirdTable.vehicle_category_type',
						 'thirdTable.vehicle_category',
						 'thirdTable.vehicle_type',
						 'thirdTable.country',
						 'thirdTable.c_type'
						] 
		);
		$this->getSelect()->joinLeft(
						['fourthTable' => $this->getTable('wais_carmodel_images')],
						'fourthTable.carmodel_id = secondTable.car_model_id', 
						['fourthTable.url',
						'fourthTable.image_type'
						
						] 
		);
		$this->getSelect()->joinLeft(
						['fifthTable' => $this->getTable('wais_carmodel_attributes')],
						'fifthTable.carmodel_id = secondTable.car_model_id', 
						['fifthTable.vehicle_doors',
						'fifthTable.vehicle_seats',
						'fifthTable.vehicle_seats',
						'fifthTable.vehicle_model_year',
						'fifthTable.small_bags',
						'fifthTable.number_of_cases',
						'fifthTable.gas',
						'fifthTable.mpg',
						'fifthTable.height',
						'fifthTable.length',
						'fifthTable.max_payload',
						'fifthTable.max_capacity'
					] 
		);
		$this->getSelect()->order('main_table.id DESC');
		$this->getSelect()->group('main_table.id');
	 
		 
		return $this;
	}*/
}