<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\Fleet;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\App\RequestInterface;
class Collection extends AbstractCollection{
    
	private $_request;
    protected $_idFieldName = 'id';
	public function __construct(
		EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null
		//RequestInterface $request

    ) {
		
		
		$this->addFilterToMap('id', 'main_table.id');
		$this->_init(
            'Synapse\Carrental\Model\Fleet',
            'Synapse\Carrental\Model\ResourceModel\Fleet'
        );
		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		$this->storeManager = $storeManager;

    }
	 
	protected function _initSelect()
	{
		parent::_initSelect();
		
		$this->getSelect()->joinLeft(
			['secondTable' => $this->getTable('customer_entity')],
			'main_table.supplier_id= secondTable.entity_id', 
			[
			'CONCAT(UCASE(secondTable.firstname), " ", UCASE(secondTable.lastname)) as supplier_name'
			] 
		);
	 	$this->getSelect()->joinLeft(
			['thirdTable' => $this->getTable('wais_fleetcarmodels')],
			'main_table.id = thirdTable.fleet_id', 
			['count(thirdTable.car_model_id) as view_cars',
			'thirdTable.fleet_id as fleet_id_for_count'
			] 
		);
		$this->getSelect()->group('main_table.id');
		$this->getSelect()->joinLeft(
			['fourthTable' => $this->getTable('wais_warehouse_info')],
			'FIND_IN_SET(main_table.id,fourthTable.assigned_fleets)', 
			['fourthTable.warehouse_name','fourthTable.location','fourthTable.city as wcity','fourthTable.country_id as wcountry_id',
			'GROUP_CONCAT(DISTINCT fourthTable.warehouse_name) as warehouse_names',
			] 
		);
		 $this->getSelect()->joinLeft(
			[
			'city'=>$this->getTable('directory_country_region_city')
			
			],
			'city.city_id=fourthTable.city',
			[
				'city.city_name as wcity'
			]
		);
		$this->getSelect()->joinLeft(
			[
			'location'=>$this->getTable('directory_city_loctions')
			
			],
			'location.locality_id=fourthTable.location',
			[
				'location.location_name as location'
			]
		);
		 
		
		return $this;
		
		
 

		 

 
		
		 
 
		
		
		
		
		
		
		
		
		
		
		
	}
}