<?php

namespace Synapse\Carrental\Model\ResourceModel\Supplierroles;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends AbstractCollection{
	
	 /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'Synapse\Carrental\Model\Supplierroles',
            'Synapse\Carrental\Model\ResourceModel\Supplierroles'
        );
    }
}