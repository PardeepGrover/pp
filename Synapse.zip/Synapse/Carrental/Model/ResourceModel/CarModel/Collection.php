<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\CarModel;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\App\RequestInterface;
class Collection extends AbstractCollection{
    
	private $_request;
    public function __construct(

        EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null
		//RequestInterface $request

    ) {
		
		
		$this->addFilterToMap('id', 'secondTable.carmodel_id');
		$this->_init(
            'Synapse\Carrental\Model\CarModel',
            'Synapse\Carrental\Model\ResourceModel\CarModel'
        );
		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		$this->storeManager = $storeManager;

    }
	protected function _initSelect()
	{
		parent::_initSelect();
		$this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_carmodel_attributes')],
						'main_table.id= secondTable.carmodel_id', 
						['main_table.id as id',
						 'secondTable.id as id1',
						 'secondTable.carmodel_id',
						 'secondTable.vehicle_doors',
						 'secondTable.vehicle_seats',
						 'secondTable.vehicle_transmission',
						 'secondTable.vehicle_attr_access',
						 'secondTable.vehicle_fuel',
						 'secondTable.vehicle_model_year',
						 'secondTable.small_bags',
						 'secondTable.number_of_cases',
						 'secondTable.gas',
						 'secondTable.mpg',
						 'secondTable.height',
						 'secondTable.length',
						 'secondTable.max_payload',
						 'secondTable.max_capacity',
						] 
		);
		$this->getSelect()->joinLeft(
						['thirdTable' => $this->getTable('wais_carmodel_images')],
						'secondTable.carmodel_id= thirdTable.carmodel_id', 
						['thirdTable.id as imgid',
						 'thirdTable.name',
						 'thirdTable.url',
						 'thirdTable.type',
						] 
		);
		$this->getSelect()->where('main_table.id not in (select car_model_id from '. $this->getTable('waissupplier_vehicle_direrctory').' where is_active_in_dir="1")');
	
		$this->getSelect()->order('main_table.id DESC');
		$this->getSelect()->group('main_table.id');
		//var_dump($this->getSelect()->__toString());
		//die;
		 return $this;
	}
	
}