<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\Vehicleseasonalprice;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends AbstractCollection{
    
      /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'Synapse\Carrental\Model\Vehicleseasonalprice',
            'Synapse\Carrental\Model\ResourceModel\Vehicleseasonalprice'
        );
    }
	
	protected function _initSelect()
	{
		parent::_initSelect();
		/* $this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_pricelist_seasons')],
						'main_table.season_id= secondTable.id', 
						[
						 'secondTable.season_name',
						 'secondTable.season_from_date',
						 'secondTable.season_to_date'
						  
						] 
		);
		 $this->getSelect()->joinLeft(
						['thirdTable' => $this->getTable('wais_carmodel')],
						'thirdTable.id= secondTable.car_model_id', 
						[
						 'thirdTable.vehicle_name',
						  
						] 
		); */
		return $this;
	}
}