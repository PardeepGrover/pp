<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\Vehiclepricelist;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
use Magento\Framework\App\RequestInterface;
class Collection extends AbstractCollection{
    
	private $_request;
	
    public function __construct(

        EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null
		//RequestInterface $request

    ) {
		$this->addFilterToMap('warehouse_id', 'secondTable.id');
		$this->_init(
            'Synapse\Carrental\Model\Vehiclepricelist',
            'Synapse\Carrental\Model\ResourceModel\Vehiclepricelist'
        );
		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		$this->storeManager = $storeManager;

    }
	protected function _initSelect()
	{
		parent::_initSelect();
		$this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_warehouse_info')],
						'main_table.warehouse_id= secondTable.id', 
						[
						 'secondTable.warehouse_name',
						 'secondTable.city',
						 'secondTable.country_id',
						 'secondTable.location'
						] 
		);
		$this->getSelect()->joinLeft(
						['thirdTable' => $this->getTable('wais_ratecode')],
						'main_table.rate_code= thirdTable.id', 
						[
						 'thirdTable.ratecode_name',
						  
						] 
		);
		$this->getSelect()->joinLeft(
						['forthTable' => $this->getTable('wais_fleet')],
						'main_table.fleet_id= forthTable.id', 
						[
						 'forthTable.fleet_name',
						  
						] 
		);
		$this->getSelect()->joinLeft(
			[
			'city'=>$this->getTable('directory_country_region_city')
			
			],
			'city.city_id=secondTable.city',
			[
				'city.city_name as city'
			]
		);
		$this->getSelect()->joinLeft(
			[
			'location'=>$this->getTable('directory_city_loctions')
			
			],
			'location.locality_id=secondTable.location',
			[
				'location.location_name as location'
			]
		);
		return $this;
	}
	
}