<?php
namespace Synapse\Carrental\Model\ResourceModel\Bookingrequests;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends AbstractCollection{
	
	 /**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->_init(
            'Synapse\Carrental\Model\Bookingrequests',
            'Synapse\Carrental\Model\ResourceModel\Bookingrequests'
        );
    }
}