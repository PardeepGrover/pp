<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel\Warehousetimings;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Magento\Framework\Data\Collection\EntityFactoryInterface;
use Psr\Log\LoggerInterface;
use Magento\Framework\Data\Collection\Db\FetchStrategyInterface;
use Magento\Framework\Event\ManagerInterface;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\DB\Adapter\AdapterInterface;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Collection extends AbstractCollection{
    
	protected $_idFieldName = 'main_table.id';
    public function __construct(

        EntityFactoryInterface $entityFactory,
		LoggerInterface $logger,
		FetchStrategyInterface $fetchStrategy,
		ManagerInterface $eventManager,
		StoreManagerInterface $storeManager,
		AdapterInterface $connection = null,
		AbstractDb $resource = null

    ) {
		$this->addFilterToMap('entity_id', 'main_table.id');
		$this->_init(
            'Synapse\Carrental\Model\Warehousetimings',
            'Synapse\Carrental\Model\ResourceModel\Warehousetimings'
        );
		parent::__construct($entityFactory, $logger, $fetchStrategy, $eventManager, $connection, $resource);
		
        $this->storeManager = $storeManager;

    }
	protected function _initSelect()
	{
		parent::_initSelect();
		$collection = $this;
	    $this->getSelect()->joinLeft(
						['secondTable' => $this->getTable('wais_warehouse_info')],
						'main_table.warehouse_id= secondTable.id and main_table.supplier_id = secondTable.supplier_id', 
						[
						 "CONCAT(main_table.from_date, '/',main_table.to_date) as date_range",	 "secondTable.warehouse_name",
							"secondTable.city",
							"secondTable.country_id",
							"secondTable.location",
					        "secondTable.supplier_id as supp_id",
						    "main_table.id",
							"main_table.event_type",
							"main_table.from_date",
							"main_table.to_date",
							"main_table.weekday",
							"main_table.pickup_hours",
							"main_table.dropoff_hours",
							"main_table.holidays",
							"main_table.created_at",
							"main_table.id as timing_id",
						] 
		);
		$this->getSelect()->joinLeft(
                ['thirdTable' => $this->getTable('customer_entity')],
                'secondTable.supplier_id = thirdTable.entity_id',
                ['concat(thirdTable.firstname," ", thirdTable.lastname) as supplier_name']
        );
		$this->getSelect()->joinLeft(
			[
			'city'=>$this->getTable('directory_country_region_city')
			
			],
			'city.city_id=secondTable.city',
			[
				'city.city_name as city'
			]
		);
		$this->getSelect()->joinLeft(
			[
			'location'=>$this->getTable('directory_city_loctions')
			
			],
			'location.locality_id=secondTable.location',
			[
				'location.location_name as location'
			]
		);
		$this->getSelect()->order('main_table.id DESC');
		 
	}
	
}