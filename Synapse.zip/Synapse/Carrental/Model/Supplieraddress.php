<?php
namespace Synapse\Carrental\Model;
use Magento\Framework\Model\AbstractModel;
class Supplieraddress extends AbstractModel{
	
	/**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Synapse\Carrental\Model\ResourceModel\Supplieraddress');
    }   
}