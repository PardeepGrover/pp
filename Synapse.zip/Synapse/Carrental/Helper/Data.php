<?php
namespace Synapse\Carrental\Helper;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    private $_supplierfoFactory;
	private $_bookingrequestsFactory;
	private $_bookingdetailsFactory;
	private $_bookingcommisionFactory;
	private $_warehouseinfoFactory;
	private $_warehouseholidayFactory;
	private $_warehouseholidayserviceFactory;
	private $_warehousetimingsFactory;
	private $_warehouseexceededtimingsFactory;
	private $_vehicleseasonalpriceFactory;
	private $_vehiclepricerateFactory;
	private $_vehicleexcludedatesFactory;
	private $_termsconditionsFactory;
	private $_supplierrolesFactory;
	private $_supplierdepartmentFactory;
	private $_supplieraddressFactory;
	private $_customerFactory;
	private $_carModelFactory;
	private $_carModelAttrFactory;
	private $_carModelImagesFactory;
	private $_rateCodeFactory;
	private $_regionFactory;
	private $_customerRepositoryInterface;
	protected $_cityFactory;
	protected $_locationFactory;
	
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Synapse\Carrental\Model\SupplierinfoFactory $supplierinfoFactory,
        \Synapse\Carrental\Model\BookingrequestsFactory $bookingrequestsFactory,
        \Synapse\Carrental\Model\BookingdetailsFactory  $bookingdetailsFactory,
        \Synapse\Carrental\Model\BookingcommisionFactory $bookingcommisionFactory,
		\Synapse\Carrental\Model\WarehouseinfoFactory $warehouseinfoFactory,
          \Synapse\Carrental\Model\WarehouseholidayFactory $warehouseholidayFactory,
          \Synapse\Carrental\Model\WarehouseholidayserviceFactory $warehouseholidayserviceFactory ,
          \Synapse\Carrental\Model\WarehousetimingsFactory $warehousetimingsFactory,
          \Synapse\Carrental\Model\WarehouseexceededtimingsFactory $warehouseexceededtimingsFactory,
          \Synapse\Carrental\Model\VehicleseasonalpriceFactory $vehicleseasonalpriceFactory,
          \Synapse\Carrental\Model\VehiclepricerateFactory $vehiclepricerateFactory,
          \Synapse\Carrental\Model\VehicleexcludedatesFactory $vehicleexcludedatesFactory ,
          \Synapse\Carrental\Model\TermsconditionsFactory $termsconditionsFactory,
          \Synapse\Carrental\Model\SupplierrolesFactory $supplierrolesFactory,
          \Synapse\Carrental\Model\SupplierdepartmentFactory $supplierdepartmentFactory,
          \Synapse\Carrental\Model\SupplieraddressFactory $supplieraddressFactory,
          \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface, 
		  \Synapse\Carrental\Model\CarModelFactory $CarModelFactory,
		  \Synapse\Carrental\Model\CarModelAttrFactory $CarModelAttrFactory,
		  \Synapse\Carrental\Model\CarModelImagesFactory $CarModelImagesFactory,
		  \Synapse\Carrental\Model\RateCodeFactory $RateCodeFactory,
		  \Synapse\Carrental\Model\RegionsFactory $RegionFactory,
		  \Synapse\Carrental\Model\CityFactory    $CityFactory,
		  \Synapse\Carrental\Model\LocationFactory    $LocationFactory
	) {
        $this->_supplierfoFactory 		= $supplierinfoFactory;
		$this->_bookingrequestsFactory  	= $bookingrequestsFactory;
		$this->_bookingdetailsFactory 		= $bookingdetailsFactory;
		$this->_bookingcommisionFactory 	=$bookingcommisionFactory;
		$this->_warehouseinfoFactory		= $warehouseinfoFactory;
		$this->_warehouseholidayFactory 	= $warehouseholidayFactory;
		$this->_warehouseholidayserviceFactory = $warehouseholidayserviceFactory ;
		$this->_warehousetimingsFactory 	= $warehousetimingsFactory;
		$this->_warehouseexceededtimingsFactory = $warehouseexceededtimingsFactory;
		$this->_vehicleseasonalpriceFactory  = $vehicleseasonalpriceFactory;
		$this->_vehiclepricerateFactory    = $vehiclepricerateFactory;
		$this->_vehicleexcludedatesFactory = $vehicleexcludedatesFactory;
		$this->_termsconditionsFactory 		= $termsconditionsFactory;
		$this->_supplierrolesFactory  		= $supplierrolesFactory;
		$this->_supplierdepartmentFactory 	= $supplierdepartmentFactory;
		$this->_supplieraddressFactory   	= $supplieraddressFactory;
		$this->_carModelFactory				= $CarModelFactory;
		$this->_carModelAttrFactory			= $CarModelAttrFactory;
		$this->_carModelImagesFactory       = $CarModelImagesFactory;
		$this->_rateCodeFactory             = $RateCodeFactory;
		$this->_regionFactory 				= $RegionFactory;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
		$this->_cityFactory    = $CityFactory;
		$this->_locationFactory = $LocationFactory;
		parent::__construct($context);
    }
    public function test()
    {
        $supplierinfoCollection = $this->_supplierfoFactory->create()->getCollection();
        var_dump($supplierinfoCollection);
        
    }
     /**
     * {@inheritdoc}
     */
    public function getCustomerAttributeValue($customerId, $attributeCode)
    {
        $customerObject = $this->_customerFactory->create()->load($customerId);
        return $attribute = ($customerObject->getData($attributeCode)) ? $customerObject->getData($attributeCode): false;
    }
    public function WarehouseinfoFactory(){
        return $this->_warehouseinfoFactory->create();
    }
    public function WarehouseholidayFactory(){
        
        return $this->_warehouseholidayFactory->create();
    }
    public function WarehousetimingsFactory(){
        return $this->_warehousetimingsFactory->create();
    }
    public function WarehouseexceededtimingsFactory(){
        return $this->_warehouseexceededtimingsFactory->create();
    }
    public function getEventTypes(){
        $types = [
				''=>'',
                1=>__('Working hours'),
                2=>__('Holidays'),
                3=>__('Fees'),
                4=>__('Out of Hours'),
            
        ];
        return $types;
        
    }
	public function getWarehouses(){
		$modelFactory = $this->WarehouseinfoFactory();
		return $modelFactory->getCollection();
	}
	public function getCategoryType(){
		
		return [
			['label'=>'Select Category',
			 'value'=>''
			],
			['label'=>'Mini(M)',
			 'value'=>'M'
			],
			['label'=>'Mini Elite(N)',
			 'value'=>'N'
			],
			['label'=>'Economy(E)',
			 'value'=>'E'
			],
			['label'=>'Economy Elite(H)',
			 'value'=>'H'
			],
			['label'=>'Compact(C)',
			 'value'=>'C'
			],
			['label'=>'Compact Elite(D)',
			 'value'=>'D'
			],
			['label'=>'Intermediate(I)',
			 'value'=>'I'
			],
			['label'=>'Intermediate Elite(J)',
			 'value'=>'J'
			],
			['label'=>'Standard(S)',
			 'value'=>'S'
			],
			['label'=>'Standard Elite(R)',
			 'value'=>'R'
			],
			['label'=>'Fullsize(F)',
			 'value'=>'F'
			],
			['label'=>'Fullsize Elite(G)',
			 'value'=>'G'
			],
			['label'=>'Premium(P)',
			 'value'=>'P'
			],
			['label'=>'Premium Elite(U)',
			 'value'=>'U'
			],
			['label'=>'Luxury(L)',
			 'value'=>'L'
			],
			['label'=>'Luxury Elite(W)',
			 'value'=>'W'
			],
			['label'=>'Oversize(O)',
			 'value'=>'O'
			],
			['label'=>'Special(X)',
			 'value'=>'X'
			] 
		];
		    
        
		 
	}
	public function getCategory(){
		
		return [];
	}
	public function getVehicleType(){
		return [
			['label'=>'Select Vehicle Type',
			 'value'=>''
			],
			['label'=>'2-3 Door(B)',
			 'value'=>'B'
			],
			['label'=>'2/4 Door(C)',
			 'value'=>'C'
			],
			['label'=>'4-5 Door(D)',
			 'value'=>'D'
			],
			['label'=>'Wagon/Estate(W)',
			 'value'=>'W'
			],
			['label'=>'Passenger Van(V)',
			 'value'=>'V'
			],
			['label'=>'Limousine(L)',
			 'value'=>'L'
			],
			['label'=>'Sport(S)',
			 'value'=>'S'
			],
			['label'=>'Convertible(T)',
			 'value'=>'T'
			],
			['label'=>'SUV(F)',
			 'value'=>'F'
			],
			['label'=>'Open Air All Terrain(J)',
			 'value'=>'J'
			],
			['label'=>'Special(X)',
			 'value'=>'X'
			],
			['label'=>'Pick up Regular Car(P)',
			 'value'=>'P'
			],
			['label'=>'Coupe(E)',
			 'value'=>'E'
			],
			['label'=>'Special Offer Car(Z)',
			 'value'=>'Z'
			],
			['label'=>'Monospace(M)',
			 'value'=>'M'
			],
			['label'=>'Recreational Vehicle(R)',
			 'value'=>'R'
			],
		    ['label'=>'Motor Home(H)',
			 'value'=>'H'
			],
			['label'=>'2 Wheel Vehicle(Y)',
			 'value'=>'Y'
			],
			['label'=>'Roadster(N)',
			 'value'=>'N'
			],
			['label'=>'Crossover(G)',
			 'value'=>'G'
			],
            ['label'=>'Commercial Van/Truck(K)',
			 'value'=>'K'
			]
		];
	}
	public function getTransmission(){
		return [
				[
					'label'=>'Select Transmission',
					'value'=>''
				],
				[
				'label'=>'Manual Unspecified Drive(M)',
				'value'=>'M'
				],
				[
				'label'=>'Manual 4WD(N)',
				'value'=>'N'
				],
				[
				'label'=>'Manual AWD(C)',
				'value'=>'C'
				],
				[
				'label'=>'Auto Unspecified Drive(A)',
				'value'=>'A'
				],
				[
				'label'=>'Auto 4WD(B)',
				'value'=>'B'
				],
				[
				'label'=>'Auto AWD(D)',
				'value'=>'D'
				]
		
		];
	}
	public function getFuel(){
		return [
				[
				'label'=>'Select Fuel',
				'value'=>''
				],
				[
				'label'=>'Unspecified Fuel/Power With Air(R)',
				'value'=>'R'
				],
				[
				'label'=>'Unspecified Fuel/Power Without Air(N)',
				'value'=>'N'
				],
				[
				'label'=>'Diesel Air(D)',
				'value'=>'D'
				],
				[
				'label'=>'Diesel No Air(Q)',
				'value'=>'Q'
				],
				[
				'label'=>'Hybrid Air(H)',
				'value'=>'H'
				],
				[
				'label'=>'Hybrid No Air(I)',
				'value'=>'I'
				],
				[
				'label'=>'Electric Air(E)',
				'value'=>'E'
				],
				[
				'label'=>'Electric No Air(C)',
				'value'=>'C'
				],
				[
				'label'=>'LPG/Compressed Gas Air',
				'value'=>'L'
				],
				[
				'label'=>'LPG/Compressed Gas Air(S)',
				'value'=>'S'
				],
				[
				'label'=>'Hydrogen Air(A)',
				'value'=>'A'
				],
				[
				'label'=>'Hydrogen No Air(B)',
				'value'=>'B'
				],
				[
				'label'=>'Multi Fuel/Power Air(M)',
				'value'=>'M'
				],
				[
				'label'=>'Multi fuel/power No Air(F)',
				'value'=>'F'
				],
				[
				'label'=>'Petrol Air(V)',
				'value'=>'V'
				],
				[
				'label'=>'Petrol No Air(Z)',
				'value'=>'Z'
				],
				[
				'label'=>'Ethanol Air(U)',
				'value'=>'U'
				],
				[
				'label'=>'Ethanol No Air(X)',
				'value'=>'X'
				]
            ];
	}
	public function getCarModels(){
		$model = $this->_carModelFactory->create();
		$collection = $model->getCollection();
		$collection->getSelect()->joinLeft(
				['attrTable' => $collection->getTable('wais_carmodel_attributes')],
				'main_table.id= attrTable.carmodel_id', 
				['main_table.id as id',
				 'attrTable.id as id1',
				 'attrTable.carmodel_id',
				 'attrTable.vehicle_doors',
				 'attrTable.vehicle_seats',
				 'attrTable.vehicle_transmission',
				 'attrTable.vehicle_attr_access',
				 'attrTable.vehicle_fuel',
				 'attrTable.vehicle_model_year',
				 'attrTable.small_bags',
				 'attrTable.number_of_cases',
				 'attrTable.gas',
				 'attrTable.mpg',
				 'attrTable.height',
				 'attrTable.length',
				 'attrTable.max_payload',
				 'attrTable.max_capacity',
				] 
		)/*->joinLeft(
				['thirdTable' => $collection->getTable('wais_carmodel_images')],
				'secondTable.carmodel_id= thirdTable.carmodel_id', 
				['thirdTable.id as imgid',
				 'thirdTable.name',
				 'thirdTable.url',
				 'thirdTable.type',
				] 
		)*/;
		return $collection;
	}
	public function getRateCodes(){
		$ratecodeModel = $this->_rateCodeFactory->create();
		$ratecodeColl  = $ratecodeModel->getCollection();
		return $ratecodeColl;
	}
	public function getCarModels1(){
		$model = $this->_carModelFactory->create();
		$collection = $model->getCollection();
		$collection->getSelect()->joinLeft(
				['attrTable1' => $collection->getTable('wais_carmodel_attributes')],
				'main_table.id= attrTable1.carmodel_id', 
				['main_table.id as id',
				 'attrTable1.id as id1',
				 'attrTable1.carmodel_id',
				 'attrTable1.vehicle_doors',
				 'attrTable1.vehicle_seats',
				 'attrTable1.vehicle_transmission',
				 'attrTable1.vehicle_attr_access',
				 'attrTable1.vehicle_fuel',
				 'attrTable1.vehicle_model_year',
				 'attrTable1.small_bags',
				 'attrTable1.number_of_cases',
				 'attrTable1.gas',
				 'attrTable1.mpg',
				 'attrTable1.height',
				 'attrTable1.length',
				 'attrTable1.max_payload',
				 'attrTable1.max_capacity',
				] 
		)->joinLeft(
				['thirdTable1' => $collection->getTable('wais_carmodel_images')],
				'attrTable1.carmodel_id= thirdTable1.carmodel_id', 
				['thirdTable1.id as imgid',
				 'thirdTable1.name',
				 'thirdTable1.url',
				 'thirdTable1.type',
				] 
		);
		$collection->setOrder('main_table.country','DESC');
		$collection->getSelect()->reset(\Magento\Framework\DB\Select::ORDER);
		 
		$collection->getSelect()->order('main_table.country desc');
		$collection->getSelect()->where('main_table.country!=""');
		return $collection;
	}
	public function getDailyRanges(){
		return [
				1=>[
					[
						'label'=>'1-2 daily',
						'value'=>'1',
						'range' =>'d,1,2',
						'type' =>'daily',
						
					],
					[
						'label'=>'3-4 daily',
						'value'=>'2',
						'range' =>'d,3,4',
						'type' =>'daily',
					],
					[
						'label'=>'5-7 fixed',
						'value'=>'3',
						'range' =>'f,5,7',
						'type' =>'fixed',
					],
					[
						'label'=>'8-13 daily',
						'value'=>'4',
						'range' =>'d,8,13',
						'type' =>'daily',
					],
					[
						'label'=>'14 fixed',
						'value'=>'5',
						'range' =>'f,14',
						'type' =>'fixed',
					],
					[
						'label'=>'14+ daily',
						'value'=>'6',
						'range' =>'d,15',
						'type' =>'daily',
					]
				],
				2=>[
					[
						'label'=>'1-2 daily',
						'value'=>'1',
						'range' =>'d,1,2',
						'type' =>'daily',
					],
					[
						'label'=>'3-4 daily',
						'value'=>'2',
						'range' =>'d,3,4',
						'type' =>'daily',
					],
					[
						'label'=>'5-6 daily',
						'value'=>'3',
						'range' =>'d,5,6',
						'type' =>'daily',
					],
					[
						'label'=>'7 fixed',
						'value'=>'4',
						'range' =>'f,7',
						'type' =>'fixed',
					],
					[
						'label'=>'8-13 daily',
						'value'=>'5',
						'range' =>'d,8,13',
						'type' =>'daily',
					],
					[
						'label'=>'14 fixed',
						'value'=>'6',
						'range' =>'f,14',
						'type' =>'fixed',
					],
					[
						'label'=>'14+ daily',
						'value'=>'7',
						'range' =>'d,15',
						'type' =>'daily',
					]
				],
				3=>[
					[
						'label'=>'1-2 daily',
						'value'=>'1',
						'range' =>'d,1,2',
						'type' =>'daily',
					],
					[
						'label'=>'3-4 daily',
						'value'=>'2',
						'range' =>'d,3,4',
						'type' =>'daily',
					],
					[
						'label'=>'5-5 daily',
						'value'=>'3',
						'range' =>'d,5',
						'type' =>'daily',
					],
					[
						'label'=>'6-6 daily',
						'value'=>'4',
						'range' =>'d,6',
						'type' =>'daily',
					],
					[
						'label'=>'7 fixed',
						'value'=>'5',
						'range' =>'f,7',
						'type' =>'fixed',
					],
					[
						'label'=>'8-13 daily',
						'value'=>'6',
						'range' =>'d,8,13',
						'type' =>'daily',
					],
					[
						'label'=>'14 fixed',
						'value'=>'7',
						'range' =>'f,14',
						'type' =>'fixed',
					],
					[
						'label'=>'14+daily',
						'value'=>'7',
						'range' =>'d,15',
						'type' =>'daily',
					]
				],
				4=>[
					[
						'label'=>'1-2 daily',
						'value'=>'1',
						'range' =>'d,1,2',
						'type' =>'daily',
					],
					[
						'label'=>'3-4 daily',
						'value'=>'2',
						'range' =>'d,3,4',
						'type' =>'daily',
					],
					[
						'label'=>'5-6 daily',
						'value'=>'3',
						'range' =>'d,5,6',
						'type' =>'daily',
					],
					[
						'label'=>'7 fixed',
						'value'=>'4',
						'range' =>'f,7',
						'type' =>'fixed',
					],
					[
						'label'=>'8-13 daily',
						'value'=>'5',
						'range' =>'d,8,13',
						'type' =>'daily',
					],
					[
						'label'=>'14 fixed',
						'value'=>'6',
						'range' =>'f,14',
						'type' =>'fixed',
					],
					[
						'label'=>'15-20 daily',
						'value'=>'7',
						'range' =>'d,15,20',
						'type' =>'daily',
					],
					[
						'label'=>'21 fixed',
						'value'=>'7',
						'range' =>'f,21',
						'type' =>'fixed',
					],
					[
						'label'=>'21+daily',
						'value'=>'8',
						'range' =>'d,22',
						'type' =>'daily',
					]
				],
				5=>[
					[
						'label'=>'1 fixed',
						'value'=>'1',
						'range' =>'f,1',
						'type' =>'fixed',
					],
					[
						'label'=>'2 fixed',
						'value'=>'2',
						'range' =>'f,2',
						'type' =>'fixed',
					],
					[
						'label'=>'3 fixed',
						'value'=>'3',
						'range' =>'f,3',
						'type' =>'fixed',
					],
					[
						'label'=>'4 fixed',
						'value'=>'4',
						'range' =>'f,4',
						'type' =>'fixed',
					],
					[
						'label'=>'5 fixed',
						'value'=>'5',
						'range' =>'f,5',
						'type' =>'fixed',
					],
					[
						'label'=>'6 fixed',
						'value'=>'6',
						'range' =>'f,6',
						'type' =>'fixed',
					],
					[
						'label'=>'7 fixed',
						'value'=>'7',
						'range' =>'f,7',
						'type' =>'fixed',
					],
					[
						'label'=>'8-13 daily',
						'value'=>'8',
						'range' =>'d,8,13',
						'type' =>'daily',
					],
					[
						'label'=>'14 fixed',
						'value'=>'9',
						'range' =>'f,14',
						'type' =>'fixed',
					],
					[
						'label'=>'15-20 daily',
						'value'=>'10',
						'range' =>'d,15,20',
						'type' =>'daily',
					],
					[
						'label'=>'21 fixed',
						'value'=>'11',
						'range' =>'f,21',
						'type' =>'fixed',
					],
					[
						'label'=>'21+ daily',
						'value'=>'12',
						'range' =>'d,22',
						'type' =>'daily',
					]
				],
				6=>[
					[
						'label'=>'1 fixed',
						'value'=>'1',
						'range' =>'f,1',
						'type' =>'fixed',
					],
					[
						'label'=>'2 fixed',
						'value'=>'2',
						'range' =>'f,2',
						'type' =>'fixed',
					],
					[
						'label'=>'3 fixed',
						'value'=>'3',
						'range' =>'f,3',
						'type' =>'fixed',
					],
					[
						'label'=>'4 fixed',
						'value'=>'4',
						'range' =>'f,4',
						'type' =>'fixed',
					],
					[
						'label'=>'5 fixed',
						'value'=>'5',
						'range' =>'f,5',
						'type' =>'fixed',
					],
					[
						'label'=>'6 fixed',
						'value'=>'6',
						'range' =>'f,6',
						'type' =>'fixed',
					],
					[
						'label'=>'7 fixed',
						'value'=>'7',
						'range' =>'f,7',
						'type' =>'fixed',
					],
					[
						'label'=>'8-13 daily',
						'value'=>'8',
						'range' =>'d,8,13',
						'type' =>'daily',
					],
					[
						'label'=>'14 fixed',
						'value'=>'9',
						'range' =>'f,14',
						'type' =>'fixed',
					],
					[
						'label'=>'15-20 daily',
						'value'=>'10',
						'range' =>'d,15,20',
						'type' =>'daily',
					],
					[
						'label'=>'21 fixed',
						'value'=>'11',
						'range' =>'f,21',
						'type' =>'fixed',
					],
					[
						'label'=>'22-26 daily',
						'value'=>'12',
						'range' =>'d,22,26',
						'type' =>'daily',
					],
					[
						'label'=>'27 fixed',
						'value'=>'13',
						'range' =>'f,27',
						'type' =>'fixed',
					],
					[
						'label'=>'27+daily',
						'value'=>'14',
						'range' =>'d,28',
						'type' =>'daily',
					]
				],
				7=>[
					[
						'label'=>'1 fixed',
						'value'=>'1',
						'range' =>'d,1',
						'type' =>'fixed',
					],
					[
						'label'=>'2 fixed',
						'value'=>'2',
						'range' =>'f,2',
						'type' =>'fixed',
					],
					[
						'label'=>'3 fixed',
						'value'=>'3',
						'range' =>'f,3',
						'type' =>'fixed',
					],
					[
						'label'=>'4 fixed',
						'value'=>'4',
						'range' =>'f,4',
						'type' =>'fixed',
					],
					[
						'label'=>'5 fixed',
						'value'=>'5',
						'range' =>'f,5',
						'type' =>'fixed',
					],
					[
						'label'=>'6 fixed',
						'value'=>'6',
						'range' =>'f,6',
						'type' =>'fixed',
					],
					[
						'label'=>'7 fixed',
						'value'=>'7',
						'range' =>'f,7',
						'type' =>'fixed',
					],
					[
						'label'=>'8 fixed',
						'value'=>'8',
						'range' =>'f,8',
						'type' =>'fixed',
					],
					[
						'label'=>'9 fixed',
						'value'=>'9',
						'range' =>'f,9',
						'type' =>'fixed',
					],
					[
						'label'=>'10 fixed',
						'value'=>'10',
						'range' =>'f,10',
						'type' =>'fixed',
					],
					[
						'label'=>'11 fixed',
						'value'=>'11',
						'range' =>'f,11',
						'type' =>'fixed',
					],
					[
						'label'=>'12 fixed',
						'value'=>'12',
						'range' =>'f,12',
						'type' =>'fixed',
					],
					[
						'label'=>'13 fixed',
						'value'=>'13',
						'range' =>'f,13',
						'type' =>'fixed',
					],
					[
						'label'=>'14 fixed',
						'value'=>'14',
						'range' =>'f,14',
						'type' =>'fixed',
					],
					[
						'label'=>'15-20 daily',
						'value'=>'15',
						'range' =>'d,15,20',
						'type' =>'daily',
					],
					[
						'label'=>'21 fixed',
						'value'=>'16',
						'range' =>'f,21',
						'type' =>'fixed',
					],
					[
						'label'=>'22-26 daily',
						'value'=>'17',
						'range' =>'d,22,26',
						'type' =>'daily',
					],
					[
						'label'=>'27 fixed',
						'value'=>'18',
						'range' =>'f,27',
						'type' =>'daily',
					],
					[
						'label'=>'27+ daily',
						'value'=>'19',
						'range' =>'d,28',
						'type' =>'daily',
					]
				],
				8=>[
					[
						'label'=>'Daily',
						'value'=>'1',
						'range' =>'d,1',
						'type' =>'daily',
					],
					[
						'label'=>'Weekly',
						'value'=>'2',
						'range' =>'w,1',
						'type' =>'weekly',
					] 
				],
				9=>[
					[
						'label'=>'1-2 daily',
						'value'=>'1',
						'range' =>'d,1,2',
						'type' =>'daily',
					],
					[
						'label'=>'3-4 daily',
						'value'=>'2',
						'range' =>'d,3,4',
						'type' =>'daily',
					],
					[
						'label'=>'weekly',
						'value'=>'3',
						'range' =>'w,1',
						'type' =>'weekly',
					],
					[
						'label'=>'+daily',
						'value'=>'4',
						'range' =>'d,1',
						'type' =>'daily',
					]   
				]
				
			];
		
		
		
	}
	public function getSupplierName($customerId){
	
	    $customer = $this->_customerRepositoryInterface->getById($customerId);
		 return $customer->getFirstname().' '.$customer->getLastname();
	}
	public function getRegions(){
		$regionModel = $this->_regionFactory->create();
		$collection  = $regionModel->getCollection();
		$arr = [];
		$i = 0;
		$j  = '';
		$z= 0;
		foreach($collection as $key=>$value){
			if($j!=$value->getRegionId()){
				$i= 0;
				$j = $value->getRegionId();
			}
			$arr[$value->getRegionId()]['label'] = $value->getRegionName();
			$arr[$value->getRegionId()]['value'] = $value->getRegionId();
			$arr[$value->getRegionId()]['is_active'] = '1';
			$arr[$value->getRegionId()]['optgroup'][$i]['label'] = $value->getSubregionName();
			$arr[$value->getRegionId()]['optgroup'][$i]['is_active'] = '1';
			$arr[$value->getRegionId()]['optgroup'][$i]['value'] = $value->getSubregionId();
			$i++;
		
			
		}
		//$arr = array_map('array_values', $arr);
		//$arr = array_values($arr);
		return  $arr;
	}
	public function getLocationTypes(){
		$data = [
				[
				'label' =>__('Select'),
				'value' => '',
				],
				[
				'label' =>__('Airport'),
				'value' => 'Airport',
				],
				[
				'label' =>__('Station'),
				'value' => 'Station',
				],
				[
				'label' =>__('City'),
				'value' => 'City',
				],
				[
				'label' =>__('Place'),
				'value' => 'Place',
				]
			];
		
		return $data;
	}
	public function getCityJson(){
		$cityModel 		= $this->_cityFactory->create();
		$cityCollection = $cityModel->getCollection();
		return $cityCollection;
	}
	public function getLocationJson(){
		$locationModel = $this->_locationFactory->create();
		$locationCollection = $locationModel->getCollection();
		return $locationCollection;
	}
	public function getFuelOtions(){
		return [
				[
				'label'=>'Select Fuel',
				'value'=>''
				],
				[
				'label'=>'Unspecified Fuel/Power With Air(R)',
				'value'=>'1'
				],
				[
				'label'=>'Unspecified Fuel/Power Without Air(N)',
				'value'=>'2'
				],
				[
				'label'=>'Diesel Air(D)',
				'value'=>'3'
				],
				[
				'label'=>'Diesel No Air(Q)',
				'value'=>'4'
				],
				[
				'label'=>'Hybrid Air(H)',
				'value'=>'5'
				],
				[
				'label'=>'Hybrid No Air(I)',
				'value'=>'6'
				],
				[
				'label'=>'Electric Air(E)',
				'value'=>'7'
				],
				[
				'label'=>'Electric No Air(C)',
				'value'=>'8'
				],
				[
				'label'=>'LPG/Compressed Gas Air',
				'value'=>'9'
				],
				[
				'label'=>'LPG/Compressed Gas Air(S)',
				'value'=>'10'
				],
				[
				'label'=>'Hydrogen Air(A)',
				'value'=>'11'
				],
				[
				'label'=>'Hydrogen No Air(B)',
				'value'=>'12'
				],
				[
				'label'=>'Multi Fuel/Power Air(M)',
				'value'=>'13'
				],
				[
				'label'=>'Multi fuel/power No Air(F)',
				'value'=>'14'
				],
				[
				'label'=>'Petrol Air(V)',
				'value'=>'15'
				],
				[
				'label'=>'Petrol No Air(Z)',
				'value'=>'16'
				],
				[
				'label'=>'Ethanol Air(U)',
				'value'=>'17'
				],
				[
				'label'=>'Ethanol No Air(X)',
				'value'=>'18'
				]
            ];
	}
	public function getTransmissionOptions(){
		return [
				[
					'label'=>'Select Transmission',
					'value'=>''
				],
				[
				'label'=>'Manual Unspecified Drive(M)',
				'value'=>'1'
				],
				[
				'label'=>'Manual 4WD(N)',
				'value'=>'2'
				],
				[
				'label'=>'Manual AWD(C)',
				'value'=>'3'
				],
				[
				'label'=>'Auto Unspecified Drive(A)',
				'value'=>'4'
				],
				[
				'label'=>'Auto 4WD(B)',
				'value'=>'5'
				],
				[
				'label'=>'Auto AWD(D)',
				'value'=>'6'
				]
		
		];
	}
	public function getCategoryTypeOptions(){
			return 
			[
				['label'=>'Select Category',
				 'value'=>''
				],
				['label'=>'Mini(M)',
				 'value'=>'1'
				],
				['label'=>'Mini Elite(N)',
				 'value'=>'2'
				],
				['label'=>'Economy(E)',
				 'value'=>'3'
				],
				['label'=>'Economy Elite(H)',
				 'value'=>'4'
				],
				['label'=>'Compact(C)',
				 'value'=>'5'
				],
				['label'=>'Compact Elite(D)',
				 'value'=>'6'
				],
				['label'=>'Intermediate(I)',
				 'value'=>'7'
				],
				['label'=>'Intermediate Elite(J)',
				 'value'=>'8'
				],
				['label'=>'Standard(S)',
				 'value'=>'9'
				],
				['label'=>'Standard Elite(R)',
				 'value'=>'10'
				],
				['label'=>'Fullsize(F)',
				 'value'=>'11'
				],
				['label'=>'Fullsize Elite(G)',
				 'value'=>'12'
				],
				['label'=>'Premium(P)',
				 'value'=>'13'
				],
				['label'=>'Premium Elite(U)',
				 'value'=>'14'
				],
				['label'=>'Luxury(L)',
				 'value'=>'15'
				],
				['label'=>'Luxury Elite(W)',
				 'value'=>'16'
				],
				['label'=>'Oversize(O)',
				 'value'=>'17'
				],
				['label'=>'Special(X)',
				 'value'=>'18'
				] 	
			];
	}
    
	public function getVehicleTypeOptions(){
		return [
			 
			['label'=>'2-3 Door(B)',
			 'value'=>'1'
			],
			['label'=>'2/4 Door(C)',
			 'value'=>'2'
			],
			['label'=>'4-5 Door(D)',
			 'value'=>'3'
			],
			['label'=>'Wagon/Estate(W)',
			 'value'=>'4'
			],
			['label'=>'Passenger Van(V)',
			 'value'=>'5'
			],
			['label'=>'Limousine(L)',
			 'value'=>'6'
			],
			['label'=>'Sport(S)',
			 'value'=>'7'
			],
			['label'=>'Convertible(T)',
			 'value'=>'8'
			],
			['label'=>'SUV(F)',
			 'value'=>'9'
			],
			['label'=>'Open Air All Terrain(J)',
			 'value'=>'10'
			],
			['label'=>'Special(X)',
			 'value'=>'11'
			],
			['label'=>'Pick up Regular Car(P)',
			 'value'=>'12'
			],
			['label'=>'Coupe(E)',
			 'value'=>'13'
			],
			['label'=>'Special Offer Car(Z)',
			 'value'=>'14'
			],
			['label'=>'Monospace(M)',
			 'value'=>'15'
			],
			['label'=>'Recreational Vehicle(R)',
			 'value'=>'16'
			],
		    ['label'=>'Motor Home(H)',
			 'value'=>'17'
			],
			['label'=>'2 Wheel Vehicle(Y)',
			 'value'=>'18'
			],
			['label'=>'Roadster(N)',
			 'value'=>'19'
			],
			['label'=>'Crossover(G)',
			 'value'=>'20'
			],
            ['label'=>'Commercial Van/Truck(K)',
			 'value'=>'21'
			]
		];
	}
	public function getProductAdditionalInfo($productId){
		
		$seasonalPriceModel = $this->_vehicleseasonalpriceFactory->create();
		$collection = $seasonalPriceModel->getCollection();
		$collection->addFieldToFilter('product_id',$productId);
		$collection->addFieldToSelect('car_model_id');
		$collection->getSelect()->joinLeft(
				['attrTable1' => $collection->getTable('wais_carmodel_attributes')],
				'main_table.car_model_id= attrTable1.carmodel_id', 
				['main_table.id as id',
				 'attrTable1.id as id1',
				 'attrTable1.carmodel_id',
				 'attrTable1.vehicle_doors',
				 'attrTable1.vehicle_seats',
				 'attrTable1.vehicle_transmission',
				 'attrTable1.vehicle_attr_access',
				 'attrTable1.vehicle_fuel',
				 'attrTable1.vehicle_model_year',
				 'attrTable1.small_bags',
				 'attrTable1.number_of_cases',
				 'attrTable1.gas',
				 'attrTable1.mpg',
				 'attrTable1.height',
				 'attrTable1.length',
				 'attrTable1.max_payload',
				 'attrTable1.max_capacity',
				] 
		);
		$collection->getSelect()->group('main_table.car_model_id');
		return $collection->getFirstItem();
		
	}
	
	
	
	/* mileage policy START*/
		public function mileageFee(){
			return 
			[
				[
				'label'=>__('Included Vat'),
				'value'=>'1'
				],
				[
				'label'=>__('Excluded Vat'),
				'value'=>'2'
				]
			];
		}
		public function mileageUnits(){
			return 
			[
				[
					'label'=>__('Imperial'),
					'value'=>'1'
				],
				[
					'label'=>__('Metric'),
					'value'=>'2'
				]
			];
		}
		public function mileageTypes(){
			return 
			[
				[
					'label'=>'Select Mileage',
					'value'=>''
				],
				[
					'label'=>__('Limited'),
					'value'=>'1'
				],
				[
					'label'=>__('Unlimited'),
					'value'=>'2'
				]
			];
		}
		public function durationTypes(){
			return 
			[
				['label'=>__('Per Day'),
				'value'=>'1'
				],
				['label'=>__('Per Week'),
				'value'=>'2'
				],
				['label'=>__('Per Month'),
				'value'=>'3'
				],
				['label'=>__('Per Rental'),
				'value'=>'4'
				],
				['label'=>__('Over 30 Days'),
				'value'=>'5'
				]
				
				
			];
		}
		public function getFuelTaxType(){
			return 
			[
				['label'=>__('Including Tax'),
				'value'=>'1'
				],
				['label'=>__('Excluding Tax'),
				'value'=>'2'
				]
				
				
				
			];
		}
		public function IsFuelDepositAtPickup(){
			return 
			[
				['label'=>__('Yes'),
				'value'=>'1'
				],
				['label'=>__('No'),
				'value'=>'2'
				]
				
				
				
			];
		}
		public function getFuelPType(){
			return 
			[
				['label'=>__('Select Full Type'),
				'value'=>''
				],
				['label'=>__('Fuel to Fuel'),
				'value'=>'1'
				],
				['label'=>__('Same to Same'),
				'value'=>'2'
				],
				['label'=>__('Free Tank'),
				'value'=>'3'
				],
				['label'=>__('Empty to Empty'),
				'value'=>'4'
				],
				['label'=>__('Pre Pay Fuel'),
				'value'=>'5'
				]
				
				
				
			];
		}
		public function getDepositAmountType(){
			return 
			[
				['label'=>__('Fix Amount'),
				'value'=>'1'
				],
				['label'=>__('Min -Max Amount'),
				'value'=>'2'
				] 
			];
		}
		public function getPayForFuel(){
			return 
			[
				['label'=>__('Yes'),
				'value'=>'1'
				],
				['label'=>__('No'),
				'value'=>'0'
				] 
			];	
			
		}
		public function getRefuelMeasureType(){
			return 
			[
				['label'=>__('Fixed'),
				'value'=>'1'
				],
				['label'=>__('Per Litre'),
				'value'=>'2'
				],
				['label'=>__('Per Gallon'),
				'value'=>'3'
				] 
			];	
			
		}
	
	
	/* mileage policy END*/
}


 