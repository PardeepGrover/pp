<?php
/**
 * Copyright (c) 2017. Volodumur Hryvinskyi.  All rights reserved.
 * @author: <mailto:volodumur@hryvinskyi.com>
 * @github: <https://github.com/scriptua>
 */

namespace Script\QuickView\Block;

use \Magento\Catalog\Api\ProductRepositoryInterface;
use \Magento\Catalog\Model\Product;
use \Magento\Catalog\Block\Product\View;

class QuickView extends \Magento\Framework\View\Element\Template
{
	
}
