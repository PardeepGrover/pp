<?php
namespace Synapse\Carrental\Helper;
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    private $_supplierfoFactory;
	private $_bookingrequestsFactory;
	private $_bookingdetailsFactory;
	private $_bookingcommisionFactory;
	private $_warehouseinfoFactory;
	private $_warehouseholidayFactory;
	private $_warehouseholidayserviceFactory;
	private $_warehousetimingsFactory;
	private $_warehouseexceededtimingsFactory;
	private $_vehicleseasonalpriceFactory;
	private $_vehiclepricerateFactory;
	private $_vehicleexcludedatesFactory;
	private $_termsconditionsFactory;
	private $_supplierrolesFactory;
	private $_supplierdepartmentFactory;
	private $_supplieraddressFactory;
	private $_customerFactory;
	private $_carModelFactory;
	private $_carModelAttrFactory;
	private $_carModelImagesFactory;
	private $_rateCodeFactory;
	
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Synapse\Carrental\Model\SupplierinfoFactory $supplierinfoFactory,
          \Synapse\Carrental\Model\BookingrequestsFactory $bookingrequestsFactory,
          \Synapse\Carrental\Model\BookingdetailsFactory  $bookingdetailsFactory,
          \Synapse\Carrental\Model\BookingcommisionFactory $bookingcommisionFactory,
          \Synapse\Carrental\Model\WarehouseinfoFactory $warehouseinfoFactory,
          \Synapse\Carrental\Model\WarehouseholidayFactory $warehouseholidayFactory,
          \Synapse\Carrental\Model\WarehouseholidayserviceFactory $warehouseholidayserviceFactory ,
          \Synapse\Carrental\Model\WarehousetimingsFactory $warehousetimingsFactory,
          \Synapse\Carrental\Model\WarehouseexceededtimingsFactory $warehouseexceededtimingsFactory,
          \Synapse\Carrental\Model\VehicleseasonalpriceFactory $vehicleseasonalpriceFactory,
          \Synapse\Carrental\Model\VehiclepricerateFactory $vehiclepricerateFactory,
          \Synapse\Carrental\Model\VehicleexcludedatesFactory $vehicleexcludedatesFactory ,
          \Synapse\Carrental\Model\TermsconditionsFactory $termsconditionsFactory,
          \Synapse\Carrental\Model\SupplierrolesFactory $supplierrolesFactory,
          \Synapse\Carrental\Model\SupplierdepartmentFactory $supplierdepartmentFactory,
          \Synapse\Carrental\Model\SupplieraddressFactory $supplieraddressFactory,
          \Magento\Customer\Model\CustomerFactory $customerFactory,
		  \Synapse\Carrental\Model\CarModelFactory $CarModelFactory,
		  \Synapse\Carrental\Model\CarModelAttrFactory $CarModelAttrFactory,
		  \Synapse\Carrental\Model\CarModelImagesFactory $CarModelImagesFactory,
		  \Synapse\Carrental\Model\RateCodeFactory $RateCodeFactory
	) {
        $this->_supplierfoFactory 		= $supplierinfoFactory;
		$this->_bookingrequestsFactory  	= $bookingrequestsFactory;
		$this->_bookingdetailsFactory 		= $bookingdetailsFactory;
		$this->_bookingcommisionFactory 	=$bookingcommisionFactory;
		$this->_warehouseinfoFactory		= $warehouseinfoFactory;
		$this->_warehouseholidayFactory 	= $warehouseholidayFactory;
		$this->_warehouseholidayserviceFactory = $warehouseholidayserviceFactory ;
		$this->_warehousetimingsFactory 	= $warehousetimingsFactory;
		$this->_warehouseexceededtimingsFactory = $warehouseexceededtimingsFactory;
		$this->_vehicleseasonalpriceFactory  = $vehicleseasonalpriceFactory;
		$this->_vehiclepricerateFactory    = $vehiclepricerateFactory;
		$this->_vehicleexcludedatesFactory = $vehicleexcludedatesFactory;
		$this->_termsconditionsFactory 		= $termsconditionsFactory;
		$this->_supplierrolesFactory  		= $supplierrolesFactory;
		$this->_supplierdepartmentFactory 	= $supplierdepartmentFactory;
		$this->_supplieraddressFactory   	= $supplieraddressFactory;
		$this->_carModelFactory				= $CarModelFactory;
		$this->_carModelAttrFactory			= $CarModelAttrFactory;
		$this->_carModelImagesFactory       = $CarModelImagesFactory;
		$this->_rateCodeFactory             = $RateCodeFactory;
        $this->_customerFactory = $customerFactory;
		parent::__construct($context);
    }
    public function test()
    {
        $supplierinfoCollection = $this->_supplierfoFactory->create()->getCollection();
        var_dump($supplierinfoCollection);
        
    }
     /**
     * {@inheritdoc}
     */
    public function getCustomerAttributeValue($customerId, $attributeCode)
    {
        $customerObject = $this->_customerFactory->create()->load($customerId);
        return $attribute = ($customerObject->getData($attributeCode)) ? $customerObject->getData($attributeCode): false;
    }
    public function WarehouseinfoFactory(){
        return $this->_warehouseinfoFactory->create();
    }
    public function WarehouseholidayFactory(){
        
        return $this->_warehouseholidayFactory->create();
    }
    public function WarehousetimingsFactory(){
        return $this->_warehousetimingsFactory->create();
    }
    public function WarehouseexceededtimingsFactory(){
        return $this->_warehouseexceededtimingsFactory->create();
    }
    public function getEventTypes(){
        $types = [
				''=>'',
                1=>__('Working hours'),
                2=>__('Holidays'),
                3=>__('Fees'),
                4=>__('Out of Hours'),
            
        ];
        return $types;
        
    }
	public function getWarehouses(){
		$modelFactory = $this->WarehouseinfoFactory();
		return $modelFactory->getCollection();
	}
	public function getCategoryType(){
		
		return [
			['label'=>'Select Category',
			 'value'=>''
			],
			['label'=>'Mini(M)',
			 'value'=>'M'
			],
			['label'=>'Mini Elite(N)',
			 'value'=>'N'
			],
			['label'=>'Economy(E)',
			 'value'=>'E'
			],
			['label'=>'Economy Elite(H)',
			 'value'=>'H'
			],
			['label'=>'Compact(C)',
			 'value'=>'C'
			],
			['label'=>'Compact Elite(D)',
			 'value'=>'D'
			],
			['label'=>'Intermediate(I)',
			 'value'=>'I'
			],
			['label'=>'Intermediate Elite(J)',
			 'value'=>'J'
			],
			['label'=>'Standard(S)',
			 'value'=>'S'
			],
			['label'=>'Standard Elite(R)',
			 'value'=>'R'
			],
			['label'=>'Fullsize(F)',
			 'value'=>'F'
			],
			['label'=>'Fullsize Elite(G)',
			 'value'=>'G'
			],
			['label'=>'Premium(P)',
			 'value'=>'P'
			],
			['label'=>'Premium Elite(U)',
			 'value'=>'U'
			],
			['label'=>'Luxury(L)',
			 'value'=>'L'
			],
			['label'=>'Luxury Elite(W)',
			 'value'=>'W'
			],
			['label'=>'Oversize(O)',
			 'value'=>'O'
			],
			['label'=>'Special(X)',
			 'value'=>'X'
			] 
		];
		    
        
		 
	}
	public function getCategory(){
		
		return [];
	}
	public function getVehicleType(){
		return [
			['label'=>'Select Vehicle Type',
			 'value'=>''
			],
			['label'=>'2-3 Door(B)',
			 'value'=>'B'
			],
			['label'=>'2/4 Door(C)',
			 'value'=>'C'
			],
			['label'=>'4-5 Door(D)',
			 'value'=>'D'
			],
			['label'=>'Wagon/Estate(W)',
			 'value'=>'W'
			],
			['label'=>'Passenger Van(V)',
			 'value'=>'V'
			],
			['label'=>'Limousine(L)',
			 'value'=>'L'
			],
			['label'=>'Sport(S)',
			 'value'=>'S'
			],
			['label'=>'Convertible(T)',
			 'value'=>'T'
			],
			['label'=>'SUV(F)',
			 'value'=>'F'
			],
			['label'=>'Open Air All Terrain(J)',
			 'value'=>'J'
			],
			['label'=>'Special(X)',
			 'value'=>'X'
			],
			['label'=>'Pick up Regular Car(P)',
			 'value'=>'P'
			],
			['label'=>'Coupe(E)',
			 'value'=>'E'
			],
			['label'=>'Special Offer Car(Z)',
			 'value'=>'Z'
			],
			['label'=>'Monospace(M)',
			 'value'=>'M'
			],
			['label'=>'Recreational Vehicle(R)',
			 'value'=>'R'
			],
		    ['label'=>'Motor Home(H)',
			 'value'=>'H'
			],
			['label'=>'2 Wheel Vehicle(Y)',
			 'value'=>'Y'
			],
			['label'=>'Roadster(N)',
			 'value'=>'N'
			],
			['label'=>'Crossover(G)',
			 'value'=>'G'
			],
            ['label'=>'Commercial Van/Truck(K)',
			 'value'=>'K'
			]
		];
	}
	public function getTransmission(){
		return [
				[
					'label'=>'Select Transmission',
					'value'=>''
				],
				[
				'label'=>'Manual Unspecified Drive(M)',
				'value'=>'M'
				],
				[
				'label'=>'Manual 4WD(N)',
				'value'=>'N'
				],
				[
				'label'=>'Manual AWD(C)',
				'value'=>'C'
				],
				[
				'label'=>'Auto Unspecified Drive(A)',
				'value'=>'A'
				],
				[
				'label'=>'Auto 4WD(B)',
				'value'=>'B'
				],
				[
				'label'=>'Auto AWD(D)',
				'value'=>'D'
				]
		
		];
	}
		public function getFuel(){
		return [
				[
				'label'=>'Select Fuel',
				'value'=>''
				],
				[
				'label'=>'Unspecified Fuel/Power With Air(R)',
				'value'=>'R'
				],
				[
				'label'=>'Unspecified Fuel/Power Without Air(N)',
				'value'=>'N'
				],
				[
				'label'=>'Diesel Air(D)',
				'value'=>'D'
				],
				[
				'label'=>'Diesel No Air(Q)',
				'value'=>'Q'
				],
				[
				'label'=>'Hybrid Air(H)',
				'value'=>'H'
				],
				[
				'label'=>'Hybrid No Air(I)',
				'value'=>'I'
				],
				[
				'label'=>'Electric Air(E)',
				'value'=>'E'
				],
				[
				'label'=>'Electric No Air(C)',
				'value'=>'C'
				],
				[
				'label'=>'LPG/Compressed Gas Air',
				'value'=>'L'
				],
				[
				'label'=>'LPG/Compressed Gas Air(S)',
				'value'=>'S'
				],
				[
				'label'=>'Hydrogen Air(A)',
				'value'=>'A'
				],
				[
				'label'=>'Hydrogen No Air(B)',
				'value'=>'B'
				],
				[
				'label'=>'Multi Fuel/Power Air(M)',
				'value'=>'M'
				],
				[
				'label'=>'Multi fuel/power No Air(F)',
				'value'=>'F'
				],
				[
				'label'=>'Petrol Air(V)',
				'value'=>'V'
				],
				[
				'label'=>'Petrol No Air(Z)',
				'value'=>'Z'
				],
				[
				'label'=>'Ethanol Air(U)',
				'value'=>'U'
				],
				[
				'label'=>'Ethanol No Air(X)',
				'value'=>'X'
				]
            ];
	}
	public function getCarModels(){
		$model = $this->_carModelFactory->create();
		$collection = $model->getCollection();
		$collection->getSelect()->joinLeft(
				['attrTable' => $collection->getTable('wais_carmodel_attributes')],
				'main_table.id= attrTable.carmodel_id', 
				['main_table.id as id',
				 'attrTable.id as id1',
				 'attrTable.carmodel_id',
				 'attrTable.vehicle_doors',
				 'attrTable.vehicle_seats',
				 'attrTable.vehicle_transmission',
				 'attrTable.vehicle_attr_access',
				 'attrTable.vehicle_fuel',
				 'attrTable.vehicle_model_year',
				 'attrTable.small_bags',
				 'attrTable.number_of_cases',
				 'attrTable.gas',
				 'attrTable.mpg',
				 'attrTable.height',
				 'attrTable.length',
				 'attrTable.max_payload',
				 'attrTable.max_capacity',
				] 
		)/*->joinLeft(
				['thirdTable' => $collection->getTable('wais_carmodel_images')],
				'secondTable.carmodel_id= thirdTable.carmodel_id', 
				['thirdTable.id as imgid',
				 'thirdTable.name',
				 'thirdTable.url',
				 'thirdTable.type',
				] 
		)*/;
		return $collection;
	}
	public function getRateCodes(){
		$ratecodeModel = $this->_rateCodeFactory->create();
		$ratecodeColl  = $ratecodeModel->getCollection();
		return $ratecodeColl;
	}
	public function getCarModels1(){
		$model = $this->_carModelFactory->create();
		$collection = $model->getCollection();
		$collection->getSelect()->joinLeft(
				['attrTable1' => $collection->getTable('wais_carmodel_attributes')],
				'main_table.id= attrTable1.carmodel_id', 
				['main_table.id as id',
				 'attrTable1.id as id1',
				 'attrTable1.carmodel_id',
				 'attrTable1.vehicle_doors',
				 'attrTable1.vehicle_seats',
				 'attrTable1.vehicle_transmission',
				 'attrTable1.vehicle_attr_access',
				 'attrTable1.vehicle_fuel',
				 'attrTable1.vehicle_model_year',
				 'attrTable1.small_bags',
				 'attrTable1.number_of_cases',
				 'attrTable1.gas',
				 'attrTable1.mpg',
				 'attrTable1.height',
				 'attrTable1.length',
				 'attrTable1.max_payload',
				 'attrTable1.max_capacity',
				] 
		)->joinLeft(
				['thirdTable1' => $collection->getTable('wais_carmodel_images')],
				'attrTable1.carmodel_id= thirdTable1.carmodel_id', 
				['thirdTable1.id as imgid',
				 'thirdTable1.name',
				 'thirdTable1.url',
				 'thirdTable1.type',
				] 
		);
		$collection->setOrder('main_table.country','DESC');
		$collection->getSelect()->reset(\Magento\Framework\DB\Select::ORDER);
		 
		$collection->getSelect()->order('main_table.country desc');
		$collection->getSelect()->where('main_table.country!=""');
		return $collection;
	}
        
}