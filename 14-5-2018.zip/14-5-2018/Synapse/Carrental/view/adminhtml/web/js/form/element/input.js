define([
    'jquery',
    'underscore',
    'uiRegistry',
    'Magento_Ui/js/form/element/text',
    'Magento_Ui/js/modal/modal',
], function ($, _, uiRegistry, text, modal) {
    'use strict';
    return text.extend({

        /**
         * On value change handler.
         *
         * @param {String} value
         */
        onUpdate: function (value)
        {
            if (value != 'undefined')
            {
              alert("Hello");
            }
            return this._super();
        },
    });
});