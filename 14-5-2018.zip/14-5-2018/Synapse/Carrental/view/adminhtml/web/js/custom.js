require(['jquery'],function($){
	$(document).ready(function(){
				$(document).on('blur', 'input[name="c_type"]', function(){
					var letter = $(this).val().toUpperCase();
					if(letter!=''){
						$('select[name="vehicle_category_type"]').val(letter.charAt(0)).change();
						$('select[name="vehicle_type"]').val(letter.charAt(1)).change();
					}
				});
				/*$(document).on('change', 'select[name="vehicle_category_type"],select[name="vehicle_type"]', function(){
					var letter = $(this).val().toUpperCase();
					if(letter!=''){
						if($('input[name="c_type"]').val().length<2){
							letter = letter + $('input[name="c_type"]').val();
						}else{
							letter = $(this).val().toUpperCase();
						}
						$('input[name="c_type"]').val(letter);
					}
				});*/
			
	});
 });