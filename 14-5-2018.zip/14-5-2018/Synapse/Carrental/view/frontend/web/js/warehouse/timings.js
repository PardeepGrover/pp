define(['jquery', 
		'uiComponent',
		'ko',
		'Magento_Ui/js/modal/modal',
		'jquery/ui'], function ($, Component, ko,modal) {
        'use strict';
		var holdiaystring = '<select name="timings[holidays][]" class="holiday_list">';
		return function(config) { 
			var yeararr=[];
			$.each(config.holidays,function(index,value){
				if($.inArray(value.year,yeararr)== -1){
					 yeararr.push(value.year);
					 console.log(yeararr);
					holdiaystring=holdiaystring+'<optgroup label="'+value.year+'">';
				}
				holdiaystring=holdiaystring+'<option value="'+value.id+'">'+value.holiday_name+'</option>';
					 
			});
			holdiaystring = holdiaystring+'</select>';
			return Component.extend({
			 defaults: {
				template: 'Synapse_Carrental/warehouse/timings'
			},
			event_id: ko.observable(),
			show_fee_field: ko.observable(),
			numberofrows: ko.observable(),
			supplierholidays :ko.observableArray(),
			holidaylist: ko.observable(),
			initialize: function () {
				var self = this;
				var url = self.options;
				self.holidaylist = holdiaystring;
				var i = 1,j=1,fromtoids=1,pickfromtoids=1,dropfromtoids = 1;
				$('#remove-1').remove();
                this._super();
				ko.bindingHandlers.eventtype = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).change(function () {
							self.event_id($(element).val());
							 
						});
					}
				};
				/*ko.bindingHandlers.addtimingcolumns = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						var $i = 0;
						$(element).click(function () {
							 self.numberofrows($i++);
							 
						});
					}
				};*/
				ko.bindingHandlers.showfeefield = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).change(function () {
							if($(element).val()==1){
								$(element).parent().parent().next().show();
							}else{
								 $(element).parent().parent().next().hide();
								 }
							
						});
					}
				};
				/*ko.bindingHandlers.showperdayfeefield = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).change(function () {
							if($(element).val()==1){
								 $('#perdayfee').show();
							}else{
								 $('#perdayfee').hide();
								 }
							
						});
					}
				};*/
				/*ko.bindingHandlers.showholidayfields = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).change(function () {
							if($(element).val()==1){
								 $('#holidayfields').show();
							}else{
								 $('#holidayfields').hide();
								 }
							
						});
					}
				};*/
				ko.bindingHandlers.perhourCalendar1 = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).timepicker({
							showInputs: false,
							formatTime:'H:i'
						});
					}
				};
				ko.bindingHandlers.perhourCalendar2 = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).timepicker({
							showInputs: false,
							formatTime:'H:i'
						});
					}
				};
				
				/* pickup perhourrows START*/
				/*self.perhourrows = ko.observableArray([
					{ id: i }
				]);
				ko.bindingHandlers.addperhourrow = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function (event) {
							event.preventDefault();
							self.perhourrows.push({ id:++i});
						});
					}
				};*/
				/* pickup perhourrows END*/ 
				
				
				/*pick pickup fromto hours START*/
				self.pickfromtohrs = ko.observableArray([
					{ id: fromtoids }
				]);
				ko.bindingHandlers.addpickfromtohrs = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function (event) {
							event.preventDefault();
							self.pickfromtohrs.push({ id:++fromtoids});
							$(this).next().remove();
							$("a[class*='aadd']").not('#add-1').remove();
							
						});
					}
				};
				ko.bindingHandlers.removefromtorow = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function () {
							if(self.pickfromtohrs().length>1){
								self.pickfromtohrs.pop(this);
								 
							}
							
							 
						});
						
					}
				};
				/*pick pickup fromto hours END*/
				
				 
				
				
				/* dropoff fromto*/
				ko.bindingHandlers.adddropfromtohrs = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function (event) {
							self.dropfromtohrs.push({ id:++dropfromtoids});
							$("a[class*='dropadd']").not('#dropadd-1').remove();
							$(this).next().remove();
						});
						
					}
				};
				self.dropfromtohrs = ko.observableArray([
					{ id: dropfromtoids }
				]);
				ko.bindingHandlers.removedropfromto = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function () {
							if(self.dropfromtohrs().length>1){
								self.dropfromtohrs.pop(this);
								 
							}
						});
						
					}
				};
			
			
				/* dropoff fromto */ 
				ko.bindingHandlers.weekdays = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						var self = this;
						var i;
					  $(element).click(function () {
							$('.price-ptype').toggleClass('unselecteddays');
							if($('.price-ptype').length){
								for(i=1;i<=$('.price-ptype').length;i++){
									var val = $('.day'+i).prev().data('type');
									if($('.day'+i).val()!=''){
											$('.day'+i).val("");
									}else{
										$('.day'+i).val(val);
									}
								}
							}
							  
						});
							 
						 
					}
				};
				ko.bindingHandlers.dayselect = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						var self = this;
						$(element).click(function () {
							$(element).toggleClass('unselecteddays');
							var val = $(element).data('type');
							var dayval = $(element).next().val();
							if(dayval!=''){
								$(element).next().val("");
							}else{
								$(element).next().val(val);
							}
							  
						});
							 
						 
					}
				};
				ko.bindingHandlers.togglepickuphours = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function () {
							$('.pickup-main-container .event-setting').toggle();
						});
							 
						 
					}
				};
				ko.bindingHandlers.toggledropoffhours = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						var self = this;
						$(element).click(function () {
							$('.dropoff-main-container .dropofffrom').toggle();
						});
					}
				};
				
				
				
				
				
				
				
				/* Holiday functions */
				
				//self.supplierholidays = ko.observableArray(supplierholidaysarr[0]);
				ko.bindingHandlers.toggleholidaypickuphours = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function () {
							$('.holiday-pickup-main-container .event-setting').toggle();
						});
							 
						 
					}
				};
				/* holiday PICKUPHOURS rows add/remove START*/ 
				 
				
				
				
				var holidaypickuprow = 1;
				self.holidaypickuphours = ko.observableArray([
					{ id: holidaypickuprow }
				]);
				ko.bindingHandlers.addholidaypickuphours = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function (event) {
							event.preventDefault();
							self.holidaypickuphours.push({ id:++holidaypickuprow});
							$(this).next().remove();
							$("a[class*='holidayadd']").not('#holiday-add-1').remove();
							
						});
					}
				};
				ko.bindingHandlers.removeholidaypickuphours = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function () {
							if(self.holidaypickuphours().length>1){
								self.holidaypickuphours.pop(this);
								 
							}
						});
						
					}
				};
				/* holiday PICKUPHOURS rows add/remove END*/ 
				
				/* HOLIDAY DROPOFF ROWS add/remove START */
				
				ko.bindingHandlers.toggleholidaydropoffhours = {
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function () {
							$('.holiday-dropoff-main-container .dropofffrom').toggle();
						});
							 
						 
					}
				};
				var holidaydropoffrow = 1;
				self.holidaydropoffhours = ko.observableArray([
					{ id: holidaydropoffrow }
				]);
				 
				
				ko.bindingHandlers.addholidaydropoff = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function (event) {
							event.preventDefault();
							self.holidaydropoffhours.push({ id:++holidaydropoffrow});
							$(this).next().remove();
							$("a[class*='holidaydropoffadd']").not('#holidaydropoff-add-1').remove();
							
						});
					}
				};
				ko.bindingHandlers.removeholidaydropoff = {	
					init: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
						$(element).click(function () {
							if(self.holidaydropoffhours().length>1){
								self.holidaydropoffhours.pop(this);
								 
							}
						});
						
					}
				};
				
            },
			});
		}
		}
);