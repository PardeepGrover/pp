require(['jquery'],function($){
	$(document).ready(function(){
		
		alert("Hello");
		
	});
	
	
	
});