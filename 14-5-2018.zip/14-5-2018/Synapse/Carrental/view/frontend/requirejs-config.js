/**
 * Created by hoang on 24/12/2016.
 */
var config = {
    paths: {
        "fullcalendar": 'Synapse_Carrental/js/fullcalendar.min',
		"select2": 'Synapse_Carrental/js/select2.min',
		"customjs":'Synapse_Carrental/js/custom'
		
    },
	 map: {
        '*': {
            'Magento_Ui/js/grid/massactions': 'Synapse_Carrental/js/grid/massactions'
			
			}
    },
	 
	
    shim:{
        'fullcalendar':{
            'deps':['jquery']
        },
		'select2':{
            'deps':['jquery']
        }
		
		
		
		
    }
	  
};