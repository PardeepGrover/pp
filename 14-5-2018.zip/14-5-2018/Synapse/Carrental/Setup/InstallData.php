<?php

namespace Synapse\Carrental\Setup;

use Magento\Eav\Setup\EavSetup;
use Magento\Eav\Setup\EavSetupFactory;
use Magento\Eav\Model\Entity\Attribute\SetFactory as AttributeSetFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

#use Magento\Catalog\Model\Product;

/**
 * @codeCoverageIgnore
 */
class InstallData implements InstallDataInterface {

    const APPROVE_ACCOUNT = 'approve_account';

    /**
     * EAV setup factory
     *
     * @var EavSetup
     */
    private $eavSetupFactory;

    /**
     * Customer setup factory
     *
     * @var \Magento\Customer\Setup\CustomerSetupFactory
     */
    private $customerSetupFactory;
    private $attributeSetFactory;

    /**
     * InstallData constructor.
     * @param EavSetup $eavSetupFactory
     */
    public function __construct(
    EavSetupFactory $eavSetupFactory, \Magento\Customer\Setup\CustomerSetupFactory $customerSetupFactory, AttributeSetFactory $attributeSetFactory
    ) {
        $this->eavSetupFactory = $eavSetupFactory;
        $this->customerSetupFactory = $customerSetupFactory;
        $this->attributeSetFactory = $attributeSetFactory;
    }

    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(ModuleDataSetupInterface $setup, ModuleContextInterface $context) {
        /** @var CustomerSetup $customerSetup */
        $customerSetup = $this->customerSetupFactory->create(['setup' => $setup]);
        $customerSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, 'is_supplier');
        $customerSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, 'department_name');
        $customerSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, 'department_phonenumber');
        $customerSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, 'department_email');
        $customerSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, 'show_dinfo');
        $customerSetup->removeAttribute(\Magento\Customer\Model\Customer::ENTITY, 'supplier_department_name');
       
        $setup->startSetup();
        $customerEntity = $customerSetup->getEavConfig()->getEntityType('customer');
        $attributeSetId = $customerEntity->getDefaultAttributeSetId();

        $attributeSet = $this->attributeSetFactory->create();
        $attributeGroupId = $attributeSet->getDefaultGroupId($attributeSetId);

        $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'is_supplier', [
            "type" => "int",
            "backend" => "",
            "label" => "Do you want to become supplier",
            "input" => "boolean",
            "source" => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
            "visible" => false,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 216,
            "position" => 216,
        ]);
        $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'department_name', [
            "type" => "text",
            "backend" => "",
            "label" => "Supplier Department Name",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 217,
            "position" => 217,
            "system" => false,
        ]);
         $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'department_phonenumber', [
            "type" => "text",
            "backend" => "",
            "label" => "Supplier Department Phone Number",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 218,
            "position" => 218,
            "system" => false,
        ]);
         
         $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'department_email', [
            "type" => "text",
            "backend" => "",
            "label" => "Supplier Department email",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 219,
            "position" => 219,
            "system" => false,
             
        ]);
		$customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'company_name', [
            "type" => "text",
            "backend" => "",
            "label" => "Company Name",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 221,
            "position" => 221,
            "system" => false,
             
        ]);
		$customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'brand_name', [
            "type" => "text",
            "backend" => "",
            "label" => "Brand Name",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 222,
            "position" => 222,
            "system" => false,
             
        ]);
		$customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'legal_name', [
            "type" => "text",
            "backend" => "",
            "label" => "Legal Name",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 223,
            "position" => 223,
            "system" => false,
             
        ]);
		$customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'homepage_url', [
            "type" => "text",
            "backend" => "",
            "label" => "Homepage Url",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 224,
            "position" => 224,
            "system" => false,
             
        ]);
        $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY,'is_supplier_active', [
            'type' => 'int',
            'label' => 'Want to Activate/deactivate',
            'input' => 'select',
            "source" => "Synapse\Carrental\Model\Config\Source\CustomerYesNoOptions",
            'required' => false,
            'default' => '0',
            'visible' => true,
            'user_defined' => true,
            'sort_order' => 225,
            'position' => 225,
            'system' => false
        ]);
		$customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, 'supplier_notes', [
            "type" => "text",
            "backend" => "",
            "label" => "Add Note",
            "input" => "text",
            "visible" => true,
            "required" => false,
            "default" => "",
            "frontend" => "",
            "note" => "",
            "sort_order" => 226,
            "position" => 226,
            "system" => false,
             
        ]);
		
        $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY,'show_dinfo', [
            'type' => 'int',
            'label' => 'want to show department information',
            'input' => 'select',
            "source" => "Synapse\Carrental\Model\Config\Source\CustomerYesNoOptions",
            'required' => false,
            'default' => '0',
            'visible' => true,
            'user_defined' => true,
            'sort_order' => 220,
            'position' => 220,
            'system' => false,
            'adminhtml_only' => 1,
            'admin_checkout' => 1,
             
        ]);
        
        $customerSetup->addAttribute(\Magento\Customer\Model\Customer::ENTITY, self::APPROVE_ACCOUNT, [
            'type' => 'int',
            'label' => 'Approve Account',
            'input' => 'select',
            "source" => "Synapse\Carrental\Model\Config\Source\CustomerYesNoOptions",
            'required' => false,
            'default' => '0',
            'visible' => true,
            'user_defined' => true,
            'sort_order' => 215,
            'position' => 215,
            'system' => false,
            'adminhtml_only' => 1,
            'admin_checkout' => 1,
        ]);
        //add attribute to attribute set
        $attribute = $customerSetup->getEavConfig()->getAttribute('customer', 'is_supplier');

        $attribute->setData('used_in_forms', [ 'customer_account_create', 'customer_account_edit']);
        $attribute->save();
        
        $attribute2 = $customerSetup->getEavConfig()->getAttribute('customer', 'department_name');
        $attribute2->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute2->save();
        
        $attribute3 = $customerSetup->getEavConfig()->getAttribute('customer', 'department_phonenumber');
        $attribute3->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute3->save();
        
        $attribute4 = $customerSetup->getEavConfig()->getAttribute('customer', 'department_email');
        $attribute4->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute4->save();
        
        $attribute5 = $customerSetup->getEavConfig()->getAttribute('customer', 'show_dinfo');
        $attribute5->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute5->save();

		$attribute6 = $customerSetup->getEavConfig()->getAttribute('customer', 'company_name');
        $attribute6->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute6->save();
		
		$attribute7 = $customerSetup->getEavConfig()->getAttribute('customer', 'brand_name');
        $attribute7->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute7->save();
		
		$attribute8 = $customerSetup->getEavConfig()->getAttribute('customer', 'legal_name');
        $attribute8->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute8->save();
		
		$attribute9 = $customerSetup->getEavConfig()->getAttribute('customer', 'homepage_url');
        $attribute9->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute9->save();
		
		$attribute10 = $customerSetup->getEavConfig()->getAttribute('customer', 'is_supplier_active');
        $attribute10->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute10->save();
		
		$attribute11 = $customerSetup->getEavConfig()->getAttribute('customer', 'supplier_notes');
        $attribute11->setData('used_in_forms', ['adminhtml_customer','customer_account_create', 'customer_account_edit']);
        $attribute11->save();
		
		
		
        $attribute1 = $customerSetup->getEavConfig()->getAttribute('customer', self::APPROVE_ACCOUNT);
        $attribute1->addData([
            'attribute_set_id' => $attributeSetId,
            'attribute_group_id' => $attributeGroupId]);
        $attribute1->setData('used_in_forms', ['adminhtml_customer', 'customer_account_create']);
        $attribute1->save();
        $setup->endSetup();
    }

}
