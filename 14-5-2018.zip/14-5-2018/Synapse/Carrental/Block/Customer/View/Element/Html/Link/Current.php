<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


namespace Synapse\Carrental\Block\Customer\View\Element\Html\Link;

class Current extends \Magento\Framework\View\Element\Html\Link\Current
{
    protected $_customerSession;
    CONST CUSTOMER_GROUP_ID = 4;

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Framework\App\DefaultPathInterface $defaultPath,
        \Magento\Customer\Model\Session $customerSession,
        array $data = []
     ) {
         $this->_customerSession = $customerSession;
         parent::__construct($context, $defaultPath, $data);
     }

    protected function _toHtml()
    {
        if($this->_customerSession->isLoggedIn()) {

            $customerGroup = $this->_customerSession->getCustomer()->getGroupId(); //Current customer groupID

            //Your Logic Here
            if($customerGroup == self::CUSTOMER_GROUP_ID) {
              
                return parent::_toHtml(); //Return link html
            } else {
                return; //Return null
            }
        }
        return;
    }
   
     
}