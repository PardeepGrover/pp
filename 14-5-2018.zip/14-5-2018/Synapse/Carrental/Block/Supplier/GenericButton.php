<?php
namespace Synapse\Carrental\Block\Supplier;
class GenericButton
{
  /**
   * @var Context
   */
  protected $context;

  /**
   * @param Context $context
   */
  public function __construct(\Magento\Framework\View\Element\Template\Context  $context)
  {
    $this->context = $context;
  }

  /**
   * Return Settings ID
   *
   * @return int
   */
  public function getSettingsId()
  {
    return 1;
  }

  /**
   * Generate url by route and parameters
   *
   * @param   string $route
   * @param   array $params
   * @return  string
   */
  public function getUrl($route = '', $params = [])
  {
    return $this->context->getUrlBuilder()->getUrl($route, $params);
  }
}