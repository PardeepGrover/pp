<?php
namespace Synapse\Carrental\Block\Vehicle;
class Vehicles extends \Magento\Framework\View\Element\Template
{
    protected $_customerSession;
    private $directoryHelper;
    /**
     * @var \Magento\Framework\App\Cache\Type\Config
     */
    protected $_configCacheType;
    
     /**
     * @var \Magento\Framework\Serialize\SerializerInterface
     */
    private $serializer;
    /**
     * @var \Magento\Directory\Model\ResourceModel\Region\CollectionFactory
     */
    protected $_regionCollectionFactory;

    /**
     * @var \Magento\Directory\Model\ResourceModel\Country\CollectionFactory
     */
    protected $_countryCollectionFactory;
    protected $_carrentalhelper;
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Directory\Helper\Data $directoryHelper,
        \Magento\Framework\App\Cache\Type\Config $configCacheType,
        \Magento\Directory\Model\ResourceModel\Region\CollectionFactory $regionCollectionFactory,
        \Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
        \Synapse\Carrental\Helper\Data $carrentalHelper,
        array $data = []
    )
    {
        parent::__construct($context, $data);
		$this->_customerSession = $customerSession;
        $this->directoryHelper = $directoryHelper;
        $this->_configCacheType = $configCacheType;
        $this->_regionCollectionFactory = $regionCollectionFactory;
        $this->_countryCollectionFactory = $countryCollectionFactory;
        $this->_carrentalhelper = $carrentalHelper;
	 
    }
    public function getPostActionUrl(){
        return $this->getUrl('carrental/warehouse/add');
    }
    public function getItems(){
        return [];
        
    }
    public function getSaveUrl(){
         return $this->getUrl('carrental/warehouse/save');
    }
    
    public function addWarehouseUrl(){
        
        return $this->getUrl('carrental/warehouse/add');
    }
    public function getHelper(){
        return $this->_carrentalhelper; 
    }
	public function addVehicleUrl(){
		return $this->getUrl('carrental/vehicle/add');
		
	}
	 
	
	
}