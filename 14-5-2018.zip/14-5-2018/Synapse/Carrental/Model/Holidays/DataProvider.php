<?php
namespace Synapse\Carrental\Model\Holidays;
use Synapse\Carrental\Model\ResourceModel\Holidays\CollectionFactory;
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $holidayCollectionFactory
     * @param array $meta
     * @param array $data
     */
    protected $collection;
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $holidayCollectionFactory,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $holidayCollectionFactory->create();
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }

        $items = $this->collection->getItems();
	$this->loadedData = array();
        /** @var Customer $customer */
        foreach ($items as $holidy) {
		$this->loadedData[$holidy->getId()] = $holidy->getData();
        }
	return $this->loadedData;

    }
     
}