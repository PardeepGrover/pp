<?php
namespace Synapse\Carrental\Model\VanModel;
use Synapse\Carrental\Model\ResourceModel\CarModel\CollectionFactory;
use Magento\Backend\Model\Session;
class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{
    /**
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param CollectionFactory $carmodelCollectionFactory
     * @param array $meta
     * @param array $data
     */
    protected $collection;
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        CollectionFactory $carmodelCollectionFactory,
		Session $session,
        array $meta = [],
        array $data = []
    ) {
        $this->collection = $carmodelCollectionFactory->create();
		$this->session = $session;
        parent::__construct($name, $primaryFieldName, $requestFieldName, $meta, $data);
    }

    public function getData()
    {
        if (isset($this->loadedData)) {
            return $this->loadedData;
        }
		$this->collection->addFieldToFilter('vehicle_model_type','van');
        $items = $this->collection->getItems();
		$this->loadedData = array();
        foreach ($items as $_itm) {
				$this->loadedData[$_itm->getId()] = $_itm->getData();
        }
		$data = $this->session->getFormData();
		if (!empty($data)) {
            $segment = $this->collection->getNewEmptyItem();
            $segment->setData($data);
            $this->loadedData[$segment->getId()] = $segment->getData();
             
        }
		$this->session->unsetFormData();
		return $this->loadedData;

    }
     
}