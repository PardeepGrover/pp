<?php
/**
 * Copyright © 2018. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Model\Product\Type;

/**
 * Class Price
 * @package Magenest\RentalAndBookingSystem\Model\Product\Type
 */
class Price extends \Magento\Catalog\Model\Product\Type\Price
{

}
