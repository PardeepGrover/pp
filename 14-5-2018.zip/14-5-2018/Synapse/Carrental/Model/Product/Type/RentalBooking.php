<?php
/**
 * Copyright © 2018. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Model\Product\Type;

use Magento\Catalog\Model\Product\Type\Virtual;

/**
 * Class Synapse
 * @package Synapse\Carrental\Model\Product\Type
 */
class RentalBooking extends Virtual
{

}
