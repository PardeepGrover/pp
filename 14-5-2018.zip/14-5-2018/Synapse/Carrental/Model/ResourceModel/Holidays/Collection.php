<?php
namespace Synapse\Carrental\Model\ResourceModel\Holidays;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends AbstractCollection{
	
	 /**
     * Define model & resource model
     */
     protected $_idFieldName = 'id';
    protected function _construct()
    {
        $this->_init(
            'Synapse\Carrental\Model\Holidays',
            'Synapse\Carrental\Model\ResourceModel\Holidays'
        );
    }
}