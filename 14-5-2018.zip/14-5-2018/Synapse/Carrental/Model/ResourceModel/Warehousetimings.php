<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace Synapse\Carrental\Model\ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Warehousetimings extends AbstractDb{
    
   /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('wais_warehouse_timings', 'id');
    } 
}