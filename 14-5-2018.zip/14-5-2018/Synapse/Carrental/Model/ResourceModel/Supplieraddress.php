<?php
namespace Synapse\Carrental\Model\ResourceModel;
use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
class Supplieraddress extends AbstractDb{
	
	 /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('wais_supplier_address', 'id');
    } 
}