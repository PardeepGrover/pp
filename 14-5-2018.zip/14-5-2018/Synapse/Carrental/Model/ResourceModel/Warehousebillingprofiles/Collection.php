<?php
namespace Synapse\Carrental\Model\ResourceModel\Warehousebillingprofiles;
use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
class Collection extends AbstractCollection{
	
	
	 protected $_idFieldName = 'id';
	/**
     * Define model & resource model
     */
    protected function _construct()
    {
        $this->addFilterToMap('id', 'main_table.id');
		$this->_init(
            'Synapse\Carrental\Model\Warehousebillingprofiles',
            'Synapse\Carrental\Model\ResourceModel\Warehousebillingprofiles'
        );
    }
}