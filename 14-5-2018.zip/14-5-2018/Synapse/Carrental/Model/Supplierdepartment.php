<?php
namespace Synapse\Carrental\Model;
use Magento\Framework\Model\AbstractModel;
class Supplierdepartment extends AbstractModel{
	
	/**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Synapse\Carrental\Model\ResourceModel\Supplierdepartment');
    }  
	
}