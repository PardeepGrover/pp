<?php
namespace Synapse\Carrental\Ui\Component\Listing\Columns;
 
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Helper\Data;
 
class Button extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;
	
	/**
     * @var fleetFactory
     */
	
	protected $fleetFactory;
	
	/**
     * @var fleetFactory
     */
	
	protected $_helper;
	
    /**
     * Constructor
     *
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
		FleetFactory $fleetFactory,
		Data  $_helper,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
		$this->fleetFactory = $fleetFactory;
		$this->_helper = $_helper;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }
 
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
		$fleetcollection = $this->fleetFactory->create()->getCollection();
		$fleetcollection->addFieldToSelect('fleet_name');
		$fleetcollection->addFieldToSelect('id');
		$transmissions = $this->_helper->getTransmission();
		$fuel = $this->_helper->getFuel();
		$fleetlist = $fleetcollection->getData();
		unset($collection);
        if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) { 
                $item[$fieldName . '_html'] = "<button class='button'><span>Add</span></button>";
                $item[$fieldName . '_title'] = __('Select the required Fields:');
                $item[$fieldName . '_submitlabel'] = __('Add');
               // $item[$fieldName . '_cancellabel'] = __('Reset');
                $item[$fieldName . '_id'] = $item['id'];
				$item[$fieldName . '-fleets'] = json_encode($fleetlist);
				$item[$fieldName . '-transmissions'] = json_encode($transmissions);
				$item[$fieldName . '-fuel'] = json_encode($fuel);
 
                $item[$fieldName . '_formaction'] = $this->urlBuilder->getUrl('carrental/fleet/save');
				$item[$fieldName . '_returnurl'] = $this->urlBuilder->getUrl('carrental/fleet/');
            }
        }
 
        return $dataSource;
    }
}