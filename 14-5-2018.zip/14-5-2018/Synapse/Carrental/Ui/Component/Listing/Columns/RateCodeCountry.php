<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Class LocationActions
 * @package Magenest\RentalAndBookingSystem\Ui\Component\Listing\Columns
 */
class RateCodeCountry extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;
	
	 /**
     * @var UrlInterface
     */
     private $_countryCollectionFactory;

    /**
     * CustomerActions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
		\Magento\Directory\Model\ResourceModel\Country\CollectionFactory $countryCollectionFactory,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
		$this->_countryCollectionFactory = $countryCollectionFactory;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
				$newarr = [];
                if(!empty($item[$fieldName])){
                    $country = $this->getCountryCollection();
					if(isset($item['assigned_country'])){  
							$ratecodecountry = explode(',',$item['assigned_country']);
						foreach($ratecodecountry as $_val):
							$key = array_search($_val, array_column($country, 'value'));
							$newarr[] = $country[$key]['label'];
						endforeach;
						
						
					}
					
				}
                 
                $item[$fieldName] =implode(',',$newarr);
            }
        }
		  return $dataSource;
       
    }
	public function getCountryCollection()
	{
		$collection = $this->_countryCollectionFactory->create()->loadByStore();
		$options = $collection
                ->setForegroundCountries($this->getTopDestinations())
                ->toOptionArray();
		return $options;
	}
}
