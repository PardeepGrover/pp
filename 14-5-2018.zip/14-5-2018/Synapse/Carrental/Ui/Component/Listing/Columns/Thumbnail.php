<?php
namespace Synapse\Carrental\Ui\Component\Listing\Columns;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Framework\View\Element\UiComponent\ContextInterface;
 
class Thumbnail extends \Magento\Ui\Component\Listing\Columns\Column
{
    const NAME = 'thumbnail';
 
    const ALT_FIELD = 'name';
 
 
    private $_getModel;
    /**
     * @var string
     */
    private $editUrl;
 
    private $_objectManager = null;
 
    /**
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param \Webkul\Hello\Model\Image\Image $imageHelper
     * @param \Magento\Framework\UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        \Synapse\Carrental\Model\CarModel\Image $imageHelper,
        \Magento\Framework\UrlInterface $urlBuilder,
       // \Magento\Framework\ObjectManagerInterface $objectManager,
        array $components = [],
        array $data = []
    ) {
        parent::__construct($context, $uiComponentFactory, $components, $data);
        $this->imageHelper = $imageHelper;
        $this->urlBuilder = $urlBuilder;
       // $this->_getModel = $model;
       // $this->_objectManager = $objectManager;
    }
 
    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    
	public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {  
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
			   $filename =  $item['url'];
			   if(!$filename){
				   $filename = $this->urlBuilder->getBaseUrl().'/pub/static/adminhtml/Magento/backend/en_US/Synapse_Carrental/images/noimage.gif';
				}
               $imagesContainer='<div class="vimages" style="width:150px !important;height:150px !important;">';
               $imagesContainer = $imagesContainer."<img src=". $filename ."   style='display:inline-block;margin:2px;width:140px!important;height:115px !important;'/>";
				$imagesContainer = $imagesContainer.'</div>'; 
                $item[$fieldName]=$imagesContainer;
				$item[$fieldName.'_src'] = $filename;
				$item[$fieldName.'_alt'] = $this->getAlt($item) ?: '';
				$item[$fieldName.'_orig_src'] = $filename;
				/*$item[$fieldName . '_link'] = $this->urlBuilder->getUrl(
                'carrental/carmodel/edit',
                ['id' => $item['id']]
				);*/
				$item[$fieldName . '_link'] = '#';
            
				
			}
			 
        }
        return $dataSource;
    }
   /**
   * @param array $row
   *
   * @return null|string
   */
 protected function getAlt($row)
 {
   $altField = self::ALT_FIELD;
   return isset($row[$altField]) ? $row[$altField] : null;
 }
}