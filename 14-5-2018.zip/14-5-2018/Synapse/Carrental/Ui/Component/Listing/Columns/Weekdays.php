<?php
/**
 * Copyright � 2015 Magenest. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Ui\Component\Listing\Columns;

use Magento\Framework\View\Element\UiComponent\ContextInterface;
use Magento\Framework\View\Element\UiComponentFactory;
use Magento\Ui\Component\Listing\Columns\Column;
use Magento\Framework\UrlInterface;

/**
 * Class LocationActions
 * @package Magenest\RentalAndBookingSystem\Ui\Component\Listing\Columns
 */
class Weekdays extends Column
{
    /**
     * @var UrlInterface
     */
    protected $urlBuilder;

    /**
     * CustomerActions constructor.
     * @param ContextInterface $context
     * @param UiComponentFactory $uiComponentFactory
     * @param UrlInterface $urlBuilder
     * @param array $components
     * @param array $data
     */
    public function __construct(
        ContextInterface $context,
        UiComponentFactory $uiComponentFactory,
        UrlInterface $urlBuilder,
        array $components = [],
        array $data = []
    ) {
        $this->urlBuilder = $urlBuilder;
        parent::__construct($context, $uiComponentFactory, $components, $data);
    }

    /**
     * Prepare Data Source
     *
     * @param array $dataSource
     * @return array
     */
    public function prepareDataSource(array $dataSource)
    {
		if (isset($dataSource['data']['items'])) {
            $fieldName = $this->getData('name');
            foreach ($dataSource['data']['items'] as & $item) {
				$newarr = [];
                if(!empty($item[$fieldName])){
                    $weekday = explode(',',$item['weekday']);
                }
				if($item['weekday']!=null){
					 foreach($weekday as $_val):
						if($_val ==1){
							$newarr[] = 'SUN';
						}elseif($_val ==2){
							$newarr[] = 'MON';
						}elseif($_val ==3){
							$newarr[] = 'TUES';
						}
						elseif($_val ==4){
							$newarr[] = 'WED';
						}
						elseif($_val ==5){
							$newarr[] = 'THU';
						}
						elseif($_val ==6){
							$newarr[] = 'FRI';
						}
						elseif($_val ==7){
							$newarr[] = 'SAT';
						}
					endforeach;
				}else{
					$newarr[] = '---';
				}
               
                $item[$fieldName] = implode(',', $newarr);
            }
        }
		  return $dataSource;
       
    }
}
