<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 02/04/2017
 * Time: 10:24
 */
namespace Synapse\Carrental\Observer\Customer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Magento\Customer\Api\CustomerRepositoryInterface;
/**
 * Class Update
 * @package Magenest\RentalAndBookingSystem\Observer\Frontend\Option
 */
class CheckSupplierApproval implements ObserverInterface
{
    /**
     * @var \Magento\Framework\App\Response\RedirectInterface
     */
    protected $redirect;
     /**
     * Customer session
     *
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;
    
    /**
     * 
     * @var type
     * request object
     */
    private $_request;
    protected $_customerRepositoryInterface;
    const CUSTOMER_GROUP_ID = 4;
    protected $_responseFactory;
    protected $_url;
    /**
     * Update constructor.
    
     */
    public function __construct(
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\App\Response\RedirectInterface $redirect,
        CustomerRepositoryInterface $customerRepositoryInterface,
        \Magento\Framework\App\ResponseFactory $responseFactory,
         \Magento\Framework\UrlInterface $url

    ) {

        $this->_customerSession = $customerSession;
        $this->redirect = $redirect;
        $this->customerRepositoryInterface = $customerRepositoryInterface;
        $this->_responseFactory = $responseFactory;
        $this->_url = $url;

    }
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
		 
        $actionName = $observer->getEvent()->getRequest()->getFullActionName();
        $controller = $observer->getControllerAction();
        if($this->_customerSession->isLoggedIn() && $this->_customerSession->getCustomerGroupId()==self::CUSTOMER_GROUP_ID) {
           $customerId = $this->_customerSession->getId();
           $isapproved = $this->isAccountNotApproved($customerId);
		  if($isapproved !="1"){
                $this->_customerSession->logout();
                $CustomRedirectionUrl = $this->_url->getUrl('customer/account/login');
                $this->_responseFactory->create()->setRedirect($CustomRedirectionUrl)->sendResponse();
                return $this;
            }

        }
		return $this;
    }
     public function isAccountNotApproved($customerId)
    {
        $customer = $this->customerRepositoryInterface->getById($customerId);
        $isApprovedAccount = $customer->getCustomAttribute('approve_account')->getValue();
		return $isApprovedAccount;
    }
}
