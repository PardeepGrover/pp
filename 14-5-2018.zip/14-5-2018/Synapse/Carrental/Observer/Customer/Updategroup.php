<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 02/04/2017
 * Time: 10:24
 */
namespace Synapse\Carrental\Observer\Customer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Synapse\Carrental\Model\SupplierinfoFactory;

/**
 * Class Update
 * @package Magenest\RentalAndBookingSystem\Observer\Frontend\Option
 */
class Updategroup implements ObserverInterface
{
    
    /**
     * 
     * @var type
     * request object
     */
    private $_request;
    protected $_customerRepositoryInterface;
    protected $_supplierinfoFactory;
    const CUSTOMER_GROUP_ID = 4;
    /**
     * Update constructor.
    
     */
    public function __construct(
       RequestInterface $request,
       \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        SupplierinfoFactory $SupplierinfoFactory
    ) {
            $this->_request = $request;
            $this->_customerRepositoryInterface = $customerRepositoryInterface;
            $this->_supplierinfoFactory = $SupplierinfoFactory;
    }

    /**
     * @param Observer $observer
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
         $customer = $observer->getEvent()->getCustomer();
         $is_supplier = $this->_request->getParam('is_supplier');
         if($is_supplier):
               $customer->setGroupId(self::CUSTOMER_GROUP_ID);
               $this->_customerRepositoryInterface->save($customer);
               $supplierinfoFactory = $this->_supplierinfoFactory->create();
               $supplierinfoFactory->setSupplierId($customer->getId());
               $supplierinfoFactory->save();
         endif;
        
    }
}
