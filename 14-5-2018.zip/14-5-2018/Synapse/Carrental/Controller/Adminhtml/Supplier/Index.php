<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 21/12/2016
 * Time: 10:58
 */
namespace Synapse\Carrental\Controller\Adminhtml\Supplier;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
#use Synapse\Carrental\Helper\Data as carrentalhelper;
/**
 * Class Index
 * @package Magenest\RentalAndBookingSystem\Controller\Rental
 */
class Index extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
    
    /**
     *
     * @var type object 
     */
    protected $_carrentalhelper;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context  $context,
        PageFactory  $resultPageFactory,
        \Synapse\Carrental\Helper\Data $carrentalhelper
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_carrentalhelper  = $carrentalhelper;
	parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::supplierinfo')
            ->addBreadcrumb(__('Suppliers'), __('Suppliers'));
        $resultPage->getConfig()->getTitle()->set(__('Suppliers'));
        return $resultPage;
    }
	/**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_pageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::supplier');
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
		return true;
       // return $this->_authorization->isAllowed('Synapse_Carrental::supplier');
    }
}
