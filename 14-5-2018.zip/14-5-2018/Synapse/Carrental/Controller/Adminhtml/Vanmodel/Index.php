<?php
/**
 * Created by PhpStorm.
 * User: hoang
 * Date: 21/12/2016
 * Time: 10:58
 */
namespace Synapse\Carrental\Controller\Adminhtml\Vanmodel;
use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Magento\Backend\Model\Session;
/**
 * Class Index
 * @package Magenest\RentalAndBookingSystem\Controller\Rental
 */
class Index extends Action
{
    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	 /**
     * @var \Magento\Backend\Model\Session
     */
	protected $session;
    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        Action\Context  $context,
        PageFactory  $resultPageFactory,
		Session $session
    ) {
        $this->resultPageFactory = $resultPageFactory;
		$this->session = $session;
		parent::__construct($context);
    }

    /**
     * Execute
     *
     * @return void
     */
    public function execute()
    {
		$this->session->setFormData(NULL);
		return $this->resultPageFactory->create();
    }
	/**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
		
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_pageFactory->create();
        $resultPage->setActiveMenu('Synapse_Carrental::vanmodel');
        return $resultPage;
    }

    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Synapse_Carrental::vanmodel');
    }
}
