<?php
/**
* Copyright 2018. All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Controller\Adminhtml\Vanmodel;

use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\App\Action\Context;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\App\Action\Action;
use Synapse\Carrental\Model\CarModelFactory ;
use Synapse\Carrental\Model\CarModelAttrFactory ;
use Synapse\Carrental\Model\CarModelImagesFactory ;
use Magento\Backend\Model\Session;

/**
 * Class Save
 *
 * @package Synapse\Carrental\Controller\Adminhtml\Carmodel
 */
class Save extends Action
{
    /**
     * @var PageFactory
     */
    private $resultPageFactory;

    /**
     * @var DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var RequestManagementInterface
     */
    private $requestManagement;

    /**
     * @var 
     */
    private $requestPostDataProcessor;

    /**
     * @var 
     */
    private $requestFactory;

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;
	
	
	private $carmodelfactory;
	private $carmodelattrfactory;
	private $carmodelimagesFactory;
	protected $session;
    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param RequestManagementInterface $requestManagement
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory,
        DataObjectHelper $dataObjectHelper,
        DataPersistorInterface $dataPersistor,
		CarModelFactory $CarModelFactory,
		CarModelAttrFactory $CarModelAttrFactory,
		CarModelImagesFactory $CarModelImagesFactory,
		Session $session
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataPersistor = $dataPersistor;
		$this->carmodelfactory = $CarModelFactory;
		$this->carmodelattrfactory = $CarModelAttrFactory;
		$this->carmodelimagesFactory =  $CarModelImagesFactory;
		$this->session = $session;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data = $this->getRequest()->getPostValue()) {
			try {
				$carmodelid ='';
				$carmodel = $this->carmodelfactory->create();
				if($data['id']==""){
					 $data['id']= NULL;
					 /* checking if already exist while inserting*/
				}
				if(isset($data['id1'])&& $data['id1']!=""){
					$carattrid = $data['id1'];
				}else{
					 $carattrid = NULL;
					 
				}
				/* checking if already exist while inserting*/
				$coll = $carmodel->getCollection();
				$coll->addFieldToFilter('vehicle_category_type',$data['vehicle_category_type']);
				$coll->addFieldToFilter('vehicle_type',$data['vehicle_type']);
				$coll->addFieldToFilter('country',$data['country']);
				$coll->addFieldToFilter('vehicle_name',$data['vehicle_name']);
				$coll->addFieldToFilter('vehicle_model_year',$data['vehicle_model_year']);
				$fcoll = $coll->getFirstItem();
				$vtype = $fcoll->getVehicleType();
				if(isset($vtype) and $vtype!=''){
					$this->session->setFormData($this->getRequest()->getPostValue());
					if(isset($data['id']) && $data['id']!='' && $fcoll->getId()!=$data['id']){
						$this->messageManager->addErrorMessage(__('Category and vehicle type already Exist! for '.$fcoll->getVehicleName()));
						return $resultRedirect->setPath('carrental/vanmodel/edit',array('id'=>$data['id']));
						
					}elseif(!isset($data['id']) || $data['id']==''){
						$this->messageManager->addErrorMessage(__('Category and vehicle type already Exist!'));
						return $resultRedirect->setPath('carrental/vanmodel/add');
					}
				}
				unset($coll);
				/* checking if already exist while inserting*/
				$carmodel->setData($data);
				$issaved = $carmodel->save();
				$carmodelid = $issaved->getId();
				if($carmodelid){
					$carmodelattr = $this->carmodelattrfactory->create();
					$carmodelattr->setData($data);
					$carmodelattr->setCarmodelId($carmodelid);
					$carmodelattr->setId($carattrid);
					$carmodelattr->save();
					if(isset($data['carmodel']['attachments'])):
						foreach($data['carmodel']['attachments'] as $_images):
							$carmodelimages = $this->carmodelimagesFactory->create();
							$carmodelimages->setData($_images);
							$carmodelimages->setCarmodelId($carmodelid);
							$carmodelimages->save();
						endforeach;
					endif;	
					 $this->messageManager->addSuccessMessage(__('Saved Successfully!'));
				}else{
					 $this->messageManager->addErrorMessage(__('Something went wrong!'));
					 return $resultRedirect->setPath('carrental/carmodel');
					
				}
				
				
				
               
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
				  
				 $this->messageManager->addExceptionMessage($e, __('Something went wrong while updating the return.'));
            }
            return $resultRedirect->setPath('carrental/vanmodel/edit',array('id'=>$carmodelid ));
        }
        
    }

    /**
     * Perform save
     *
     * @param array $data
     * @return RmaRequestInterface
     */
    private function performSave($data)
    {
        $requestObject = $this->requestFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $requestObject,
            $data,
            RmaRequestInterface::class
        );

        return $this->requestManagement->updateRequest($requestObject, true);
    }
}
