<?php
/**
 * Created by PhpStorm.
 */
namespace Synapse\Carrental\Controller\Adminhtml\Vanmodel;
use Magento\Backend\App\Action;
use Magento\Backend\Model\Session;
/**
 * Class NewAction
 * @package Synapse\Carrental\Controller\Adminhtml\CarModel
 */
class Add extends Action
{
	protected $session;
	public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
		Session $session
	) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
		$this->session = $session;
        parent::__construct($context);
    }
	protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        return $resultPage;
    }
    public function execute()
    {   
		if(!$this->session->getFormData()){
			$this->session->setFormData(NULL);
		}
		$resultPage = $this->resultPageFactory->create();
		$resultPage->getConfig()->getTitle()->prepend(__('New Commercial Van Model'));
		return $resultPage;
    }
	
    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }
}
