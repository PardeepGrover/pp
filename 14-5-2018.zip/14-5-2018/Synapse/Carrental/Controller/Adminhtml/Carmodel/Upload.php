<?php
/**
* Copyright All rights reserved.
* See LICENSE.txt for license details.
*/

namespace Synapse\Carrental\Controller\Adminhtml\Carmodel;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Synapse\Carrental\Model\CarModel\Attachment\FileUploader;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\ResultFactory;
use Synapse\Carrental\Model\Config;

/**
 * Class Upload
 *
 * @package Aheadworks\Rma\Controller\Adminhtml\Rma
 */
class Upload extends Action
{
    /**
     * {@inheritdoc}
     */
    const ADMIN_RESOURCE = 'Synapse_Carrental::manage_images';

    /**
     * @var FileUploader
     */
    private $fileUploader;

    /**
     * @var Config
     */
    private $config;

    /**
     * @param Context $context
     * @param FileUploader $fileUploader
     * @param Config $config
     */
    public function __construct(
        Context $context,
        FileUploader $fileUploader,
        Config $config
    ) {
        parent::__construct($context);
        $this->fileUploader = $fileUploader;
        $this->config = $config;
    }

    /**
     * {@inheritdoc}
     */
    public function execute()
    {
        /** @var Json $resultJson */
        $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
        try {
            $result = $this->fileUploader
                ->setAllowedExtensions($this->config->getAllowFileExtensions())
                ->saveToTmpFolder('carmodel[attachments]');
        } catch (\Exception $e) {
            $result = [
                'error' => $e->getMessage(),
                'errorcode' => $e->getCode()
            ];
        }
        return $resultJson->setData($result);
    }
}
