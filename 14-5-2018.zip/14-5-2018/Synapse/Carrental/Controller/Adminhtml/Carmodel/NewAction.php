<?php
/**
 * Created by PhpStorm.
 */
namespace Synapse\Carrental\Controller\Adminhtml\CarModel;
use Magento\Backend\App\Action;
/**
 * Class NewAction
 * @package Synapse\Carrental\Controller\Adminhtml\CarModel
 */
class NewAction extends Action
{
	public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry
	) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
        parent::__construct($context);
    }
	protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
        return $resultPage;
    }
    public function execute()
    {   
		$resultPage = $this->resultPageFactory->create();
		$resultPage->addHandle('carrental_carmodel_index');
		 return $resultPage;
    }
	
    /**
     * @return bool
     */
    protected function _isAllowed()
    {
        return true;
    }
}
