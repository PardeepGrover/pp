<?php
/**
 * Created by PhpStorm.
 * Time: 14:12
 */
namespace Synapse\Carrental\Controller\Adminhtml\CarModel;

use Magento\Backend\App\Action;
use Synapse\Carrental\Model\CarModelFactory;
use Magento\Backend\Model\Session;

class Edit extends \Magento\Backend\App\Action
{
    /**
     * @var \Magento\Framework\Registry|null
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;
	
	protected $carModelFactory;
	protected $session;

    /**
     * Edit constructor.
     * @param Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry,
		CarModelFactory $CarModelFactory,
		Session $session
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
		$this->carModelFactory = $CarModelFactory;
		$this->session = $session;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return true;
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        $resultPage = $this->resultPageFactory->create();
       // $resultPage->setActiveMenu('Synapse_Carrental::carmodel')
           // ->addBreadcrumb(__('Manage Car Model'), __('Manage Car Model'));
        return $resultPage;
    }

    /**
     * @return $this|\Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $model = $this->carModelFactory->create();
		$collection = $model->getCollection();
		if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This Car Model no longer exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();
				return $resultRedirect->setPath('*/*/');
            }
        }

         
        /*$data = $this->session->getFormData(true);
        if (!empty($data)) {
            //$model->setData($data);
        }*/
        //$this->_coreRegistry->register('car_model', $collection);
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
       // $resultPage->getConfig()->getTitle()->prepend($model->getId() ? __('Edit Car Model') : __('New Car Model'));
		return $resultPage;
    }
}
