<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Fleet;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\FleetFactory;
use Magento\Framework\Registry ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Edit extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $fleetFactory;
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;
	protected $registry;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		FleetFactory $FleetFactory,
		PageFactory $resultPageFactory,
		Registry $registry
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->fleetFactory = $FleetFactory;
		$this->resultPageFactory = $resultPageFactory;
		$this->registry = $registry;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		/** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		
		/** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
		
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		$fleetModel = $this->fleetFactory->create();
		$fleetCollection = $fleetModel->getCollection();
		$fleetCollection->addFieldToFilter('id',$this->getRequest()->getParam('id'));
		$fleetCollection->addFieldToSelect('*');
		$this->registry->register('Carrentalfleet',$fleetCollection->getFirstItem());
		$resultPage->addHandle('carrental_fleet_edit');
		$resultPage->getConfig()->getTitle()->prepend(__('Edit Fleet'));
        return $resultPage;
    }
	
	
}
