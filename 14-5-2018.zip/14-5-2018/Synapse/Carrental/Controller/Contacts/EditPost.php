<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Contacts;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\WarehousecontactsFactory;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class EditPost extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $warehousecontactsFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		WarehousecontactsFactory $WarehousecontactsFactory
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->warehousecontactsFactory = $WarehousecontactsFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());
		if ($validFormKey && $this->getRequest()->isPost()) {
			try {
				//echo "<pre>";
				//var_dump($this->getRequest()->getParams());
				//die;
				$carrentalContactModels = $this->warehousecontactsFactory->create();
				$carrentalContactModels->setData($this->getRequest()->getParams());
				$carrentalContactModels->setSupplierId($this->session->getCustomer()->getId());
				$carrentalContactModels->save();
				$this->messageManager->addSuccess(__('You saved the account information.'));
                return $resultRedirect->setPath('carrental/contacts/');
            }catch (UserLockedException $e) {
                $message = __(
                    'You did not sign in correctly or your account is temporarily disabled.'
                );
                $this->session->logout();
                $this->session->start();
                $this->messageManager->addError($message);
                return $resultRedirect->setPath('customer/account/login');
            }
            catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t save the Contacts.'));
            }

            $this->session->setCarrentalContactFormData($this->getRequest()->getPostValue());
        }
		return $resultRedirect->setPath('carrental/contacts/edit');
    }
	
}
