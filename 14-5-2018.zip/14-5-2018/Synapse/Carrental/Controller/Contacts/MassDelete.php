<?php

namespace Synapse\Carrental\Controller\Contacts;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Ui\Component\MassAction\Filter;
use Synapse\Carrental\Model\ResourceModel\Warehousecontacts\CollectionFactory;

class MassDelete extends \Magento\Framework\App\Action\Action
{
 
    protected $contactprofileFactory;

    /**
     * @var Filter
     */
    protected $_filter;
	
	protected $resultFactory;

    /**
     * MassDelete constructor.
     * @param Context $context
     * @param VehicleTypeCollectionFactory $vehicleTypeCollection
     * @param Filter $filter
     */
    public function __construct(
        \Magento\Framework\App\Action\Context $context,
        CollectionFactory $WarehousecontactsprofilesFactory,
        Filter $filter
    ) {
		parent::__construct($context);

        $this->_filter = $filter;
        $this->contactprofileFactory = $WarehousecontactsprofilesFactory;
    }

    /**
     * execute action
     *
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        $collection = $this->_filter->getCollection($this->contactprofileFactory->create());
        $delete = 0;
        foreach ($collection as $item) {
			$item->delete();
            $delete++;
        }
        $this->messageManager->addSuccessMessage(__('A total of %1 record(s) have been deleted.', $delete));
       
        $resultRedirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
        return $resultRedirect->setPath('carrental/contacts');
    }
}
