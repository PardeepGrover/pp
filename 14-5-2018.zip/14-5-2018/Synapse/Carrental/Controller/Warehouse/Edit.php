<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Warehouse;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\WarehouseinfoFactory;
use Magento\Framework\Registry ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Edit extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $warehouseinfoFactory;
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;
	protected $registry;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		WarehouseinfoFactory $WarehouseinfoFactory,
		PageFactory $resultPageFactory,
		Registry $registry
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->warehouseinfoFactory = $WarehouseinfoFactory;
		$this->resultPageFactory = $resultPageFactory;
		$this->registry = $registry;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		/** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		
		/** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
		
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		//$this->session->getCarrentalContactFormData(true);
		$warehouseinfoModel = $this->warehouseinfoFactory->create();
		$warehouseinfoCollection = $warehouseinfoModel->getCollection();
		$warehouseinfoCollection->addFieldToFilter('id',$this->getRequest()->getParam('id'));
		$warehouseinfoCollection->addFieldToSelect('id','warehouse_id');
		$warehouseinfoCollection->addFieldToSelect('supplier_contact_profile');
		$warehouseinfoCollection->addFieldToSelect('supplier_billing_profile');
		$warehouseinfoCollection->addFieldToSelect('warehouse_name');
		$warehouseinfoCollection->addFieldToSelect('telephone');
		$warehouseinfoCollection->addFieldToSelect('city');
		$warehouseinfoCollection->addFieldToSelect('region');
		$warehouseinfoCollection->addFieldToSelect('region_id');
		$warehouseinfoCollection->addFieldToSelect('country_id');
		$warehouseinfoCollection->addFieldToSelect('address');
		$warehouseinfoCollection->addFieldToSelect('postcode');
		$warehouseinfoCollection->addFieldToSelect('location');
		$warehouseinfoCollection->addFieldToSelect('desk_availability');
		$warehouseinfoCollection->addFieldToSelect('longitude');
		$warehouseinfoCollection->addFieldToSelect('grace_period');
		$warehouseinfoCollection->addFieldToSelect('advanced_reservation');
		$warehouseinfoCollection->addFieldToSelect('latitude');
		$warehouseinfoCollection->addFieldToSelect('customer_min_age');
		$warehouseinfoCollection->addFieldToSelect('customer_max_age');
		$warehouseinfoCollection->addFieldToSelect('supported_currency');
		$warehouseinfoCollection->addFieldToSelect('created_at');
		$warehouseinfoCollection->addFieldToSelect('updated_at');
		$this->registry->register('Carrentalwarehouseinfo',$warehouseinfoCollection->getFirstItem());
		$resultPage->addHandle('carrental_warehouse_edit');
        return $resultPage;
    }
	
	
}
