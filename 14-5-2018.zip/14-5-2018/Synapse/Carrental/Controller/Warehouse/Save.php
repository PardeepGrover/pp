<?php 
namespace Synapse\Carrental\Controller\Warehouse;  
use Magento\Framework\App\Action;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Data\Form\FormKey\Validator as FormKeyValidator;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\UrlInterface ;
use Synapse\Carrental\Helper\Data as Carrentalhelper;
use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
class Save extends \Magento\Framework\App\Action\Action { 
	
	private $_helper;
        private $_urlInterface;
	public function __construct(
        \Magento\Framework\App\Action\Context $context,
	\Magento\Framework\View\Result\PageFactory $resultPageFactory,
	\Magento\Customer\Model\Session $customerSession,
        FormKeyValidator $formKeyValidator,
        Carrentalhelper $carrentalhelper ,
        UrlInterface $UrlInterface
        
        //ObjectManager  $objectManager
        
          
	)
        {
            $this->resultPageFactory  = $resultPageFactory;
            $this->_customerSession   = $customerSession ;
            $this->resultRedirectFactory = $context->getResultRedirectFactory();
            $this->_formKeyValidator = $formKeyValidator;
            $this->_helper =           $carrentalhelper;
            $this->_urlInterface    =  $UrlInterface;
           // $this->_objectManager = $objectManager;
            return parent::__construct($context);
        }
	/**
     * Process  form save
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
       $resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->_customerSession->isLoggedIn()) {
			 $resultRedirect->setPath('customer/account/login');
			return $resultRedirect;
		}
        $redirectUrl = null;
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }
        if (!$this->getRequest()->isPost()) {
           $this->_getSession()->setWarehouseFormData($this->getRequest()->getPostValue());
            return $this->resultRedirectFactory->create()->setUrl(
                $this->_redirect->error($this->_buildUrl('*/*/add'))
            );
        }
        try {
			$warehouseinfo = $this->getRequest()->getParam('info');
			//$warehousetimings = $this->getRequest()->getParam('timings');
            //$warehousexceeded = $this->getRequest()->getParam('exceeded');
            $country_id = $this->getRequest()->getParam('country_id');
            $customer = $this->_customerSession;
            $supplier_id = $customer->getCustomer()->getId();
            $warehouseinfoModelFactory = $this->_helper->WarehouseinfoFactory();
            $warehouseinfoModelFactory->setData($warehouseinfo);
            $warehouseinfoModelFactory->setSupplierId($supplier_id);
            $warehouseinfoModelFactory->setCountryId($country_id);
			$warehouseinfoModelFactory->setSupplierContactProfile(implode(',',$warehouseinfo['supplier_contact_profile']));
			$warehouseinfoModelFactory->setSupportedCurrency(implode(',',$warehouseinfo['supported_currency']));
			
			
            $warehouseinfo = $warehouseinfoModelFactory->save();
            
			/* storing data in timings table */
            /*$warehousetimingsFactory  = $this->_helper->WarehousetimingsFactory();
            $warehousetimingsFactory->setData($warehousetimings);
            $warehousetimingsFactory->setWeekday(implode(',',$warehousetimings['weekday']));
            $warehousetimingsFactory->setSupplierId($supplier_id);
            $warehousetimingsFactory->setWarehouseId($warehouseinfo->getId());
            $warehousetimingsFactory->save();
            
            if($warehousexceeded):
                $warehouseexcludingFactory = $this->_helper->WarehouseexceededtimingsFactory();
                $warehouseexcludingFactory->setData($warehousexceeded);
                $warehouseexcludingFactory->setSupplierId($supplier_id);
                $warehouseexcludingFactory->setWarehouseId($warehouseinfo->getId());
                $warehouseexcludingFactory->save();
            endif;*/
           
            
            $this->messageManager->addSuccess(__('Record Successfully saved!.'));
            $url = $this->_urlInterface->getUrl('*/*/index');
            return $this->resultRedirectFactory->create()->setUrl($this->_redirect->success($url));
        } catch (InputException $e) {
            $this->messageManager->addError($e->getMessage());
            foreach ($e->getErrors() as $error) {
                $this->messageManager->addError($error->getMessage());
            }
        } catch (\Exception $e) {
            $redirectUrl = $this->_urlInterface->getUrl('*/*/index');
            $this->messageManager->addException($e, __('We can\'t save the data.'));
        }

        $url = $redirectUrl;
        if (!$redirectUrl) {
            $this->_getSession()->setWarehouseFormData($this->getRequest()->getPostValue());
            $url = $this->_urlInterface->getUrl('*/*/index', ['id' => $this->getRequest()->getParam('id')]);
       }

        return $this->resultRedirectFactory->create()->setUrl($this->_redirect->error($url));
    }
    /**
     * @param string $route
     * @param array $params
     * @return string
     */
    protected function _buildUrl($route = '', $params = [])
    {
        /** @var \Magento\Framework\UrlInterface $urlBuilder */
       // $urlBuilder = $this->_objectManager->create(\Magento\Framework\UrlInterface::class);
       // return $urlBuilder->getUrl($route, $params);
    }
  
} 


 
