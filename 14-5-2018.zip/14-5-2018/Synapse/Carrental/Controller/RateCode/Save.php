<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\RateCode;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\RateCodeFactory;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $ratecodeFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		RateCodeFactory $rateCodeFactory
      
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->ratecodeFactory = $rateCodeFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		$validFormKey = $this->formKeyValidator->validate($this->getRequest());
		if ($validFormKey && $this->getRequest()->isPost()) {
			try {
				$ratecodeModel = $this->ratecodeFactory->create();
				$ratecodeModel->setData($this->getRequest()->getParams());
				$ratecodeModel->setSupplierId($this->session->getCustomer()->getId());
				$ratecodeModel->setAssignedCountry(implode(',',$this->getRequest()->getParam('assigned_country')));
				$ratecodeModel->save();
				$this->messageManager->addSuccess(__('You saved the  information.'));
                return $resultRedirect->setPath('carrental/ratecode/');
            }catch (UserLockedException $e) {
                $message = __(
                    'You did not sign in correctly or your account is temporarily disabled.'
                );
                $this->session->logout();
                $this->session->start();
                $this->messageManager->addError($message);
                return $resultRedirect->setPath('customer/account/login');
            }
            catch (\Exception $e) {
                $this->messageManager->addException($e, __('We can\'t save the Contacts.'));
            }

            $this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
        }
		return $resultRedirect->setPath('carrental/ratecode/edit');
    }
	
}
