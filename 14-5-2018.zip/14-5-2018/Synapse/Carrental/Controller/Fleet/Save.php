<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Fleet;

use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\FleetFactory;
use Synapse\Carrental\Model\FleetcarmodelsFactory;
use Magento\Framework\Controller\Result\JsonFactory ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Save extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

	private $jsonfactory;

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $fleetFactory;
	protected $fleetcarmodelsFactory;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		FleetFactory $FleetFactory,
		FleetcarmodelsFactory $FleetcarmodelsFactory,
		JsonFactory $resultJsonFactory
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->fleetFactory = $FleetFactory;
		$this->fleetcarmodelsFactory = $FleetcarmodelsFactory;
		$this->resultJsonFactory = $resultJsonFactory;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
		
		 
        /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		$result = $this->resultJsonFactory->create();
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		try {
			$data = $this->getRequest()->getParam('data');
			if($data){
				
				$arr = explode('&',$data);
				if($arr){
					$final = [];
					foreach($arr as $_k=>$_val):
							$arr1 = explode('=',$_val);
							$final[$arr1[0]] = $arr1[1];
					endforeach;
				}
				if(count($final)>0){
					
					
					$fleetModel = $this->fleetFactory->create(); 
					$fleetcarmodelsFactry = $this->fleetcarmodelsFactory->create();
					
					if(isset($final['fleet_name']) && $final['fleet_name']!=''){
						
						$fleetModel->setFleetName($final['fleet_name']);
						$fleetModel->setSupplierId($this->session->getCustomer()->getId());
						$newrow = $fleetModel->save();
						$fleetId = $newrow->getId();
					
					}else{
						$fleetId = $final['fleet_list'];
					}
					
					$fleetcarmodelsFactry->setFleetId($fleetId);
					$fleetcarmodelsFactry->setCarModelId($final['fl_id']);
					$fleetcarmodelsFactry->setQty($final['qty']);
					$fleetcarmodelsFactry->setCarModelClass($final['carmodel_class']);
					$fleetcarmodelsFactry->setVehicleTransmission($final['vehicle_transmission']);
					$fleetcarmodelsFactry->setVehicleFuel($final['vehicle_fuel']);
					$fleetcarmodelsFactry->setCarmodelClass($final['carmodel_class']);
					$fleetcarmodelsFactry->save();
					$result->setData(['success' => true]);
				}else{
					$result->setData(['error' => true]);
				}
				
				return $result;
				 
			}
		}catch (UserLockedException $e) {
			$message = __(
				'You did not sign in correctly or your account is temporarily disabled.'
			);
			//$this->session->logout();
			//$this->session->start();
			//$this->messageManager->addError($message);
			//return $resultRedirect->setPath('customer/account/login');
		}
		catch (\Exception $e) {
			// $this->messageManager->addException($e, __('We can\'t save the Contacts.'));
		}

           // $this->session->setCarrentalRateCodeFormData($this->getRequest()->getPostValue());
        //}
		//return $resultRedirect->setPath('carrental/fleet/edit');
    }
	
}
