<?php
/**
 *
 * Copyright � Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Synapse\Carrental\Controller\Billingprofile;

use Magento\Framework\View\Result\PageFactory;
use Magento\Framework\Data\Form\FormKey\Validator;
use Magento\Customer\Model\Session;
use Magento\Framework\App\Action\Context;
use Synapse\Carrental\Model\WarehousebillingprofilesFactory;
use Magento\Framework\Registry ;


/**
 * Class EditPost
 * @SuppressWarnings(PHPMD.CouplingBetweenObjects)
 */
class Edit extends \Magento\Framework\App\Action\Action
{
    
    /**
     * @var Validator
     */
    protected $formKeyValidator;

   

    /**
     * @var Session
     */
    protected $session;
	/**
     * @param Context $context
     * @param Session $customerSession
     * @param Validator $formKeyValidator
     */
	 
	protected $warehousebillingprofilesFactory;
	/**
     * @var PageFactory
     */
    protected $resultPageFactory;
	protected $registry;
    public function __construct(
        Context $context,
        Session $customerSession,
        Validator $formKeyValidator,
		WarehousebillingprofilesFactory $WarehousebillingprofilesFactory,
		PageFactory $resultPageFactory,
		Registry $registry
    ){
        parent::__construct($context);
        $this->session = $customerSession;
        $this->formKeyValidator = $formKeyValidator;
		$this->warehousebillingprofilesFactory = $WarehousebillingprofilesFactory;
		$this->resultPageFactory = $resultPageFactory;
		$this->registry = $registry;
    }
	/**
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
       /** @var \Magento\Framework\Controller\Result\Redirect $resultRedirect */
		$resultRedirect = $this->resultRedirectFactory->create();
		
		/** @var \Magento\Framework\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
		
		if (!$this->session->isLoggedIn()) {
             $resultRedirect->setPath('customer/account/login');
            return $resultRedirect;
        }
		//$this->session->getCarrentalContactFormData(true);
		$billinfprofileModel = $this->warehousebillingprofilesFactory->create();
		$billinfprofileCollection = $billinfprofileModel->getCollection();
		$billinfprofileCollection->addFieldToFilter('id',$this->getRequest()->getParam('id'));
		$billinfprofileCollection->addFieldToSelect('id','profile_id');
		$billinfprofileCollection->addFieldToSelect('profile_name');
		$billinfprofileCollection->addFieldToSelect('vat_number');
		$billinfprofileCollection->addFieldToSelect('vat_percentage');
		$billinfprofileCollection->addFieldToSelect('bank_swift_bic');
		$billinfprofileCollection->addFieldToSelect('bank_account_information');
		$billinfprofileCollection->addFieldToSelect('accepted_payments');
		$billinfprofileCollection->addFieldToSelect('billing_city');
		$billinfprofileCollection->addFieldToSelect('billing_country_id');
		$billinfprofileCollection->addFieldToSelect('billing_region_id');
		$billinfprofileCollection->addFieldToSelect('billing_region');
		$billinfprofileCollection->addFieldToSelect('billing_postcode');
		$billinfprofileCollection->addFieldToSelect('billing_location');
		$billinfprofileCollection->addFieldToSelect('created_at');
		$billinfprofileCollection->addFieldToSelect('updated_at');
		$this->registry->register('CarrentalBillingprofileProfile',$billinfprofileCollection->getFirstItem());
		$resultPage->addHandle('carrental_billingprofile_edit');
        return $resultPage;
    }
	
	
}
