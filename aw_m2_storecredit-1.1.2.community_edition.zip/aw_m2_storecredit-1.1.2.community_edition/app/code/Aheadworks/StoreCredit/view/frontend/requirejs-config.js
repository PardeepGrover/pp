/**
* Copyright 2016 aheadWorks. All rights reserved.
* See LICENSE.txt for license details.
*/

var config = {
    map: {
        '*': {
            awStoreCreditAjax: 'Aheadworks_StoreCredit/js/aw-store-credit-ajax'
        }
    }
};
