/**
* Copyright 2016 aheadWorks. All rights reserved.
* See LICENSE.txt for license details.
*/

define(
    [
        'Magento_Ui/js/model/messages'
    ],
    function (Messages) {
        'use strict';
        return new Messages();
    }
);
