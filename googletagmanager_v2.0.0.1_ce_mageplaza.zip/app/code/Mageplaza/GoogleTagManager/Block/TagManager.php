<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_GoogleTagManager
 * @copyright   Copyright (c) 2017 Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\GoogleTagManager\Block;

use Magento\Catalog\Block\Product\ListProduct;
use Magento\Catalog\Block\Product\ProductList\Toolbar;
use Magento\Catalog\Helper\Data;
use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\ProductFactory;
use Magento\Framework\View\Element\Template;
use Magento\Framework\View\Element\Template\Context;
use Mageplaza\GoogleTagManager\Helper\Data as HelperData;
use Magento\Cookie\Helper\Cookie as HelperCookie;
use Magento\Framework\ObjectManagerInterface;

/**
 * Class TagManager
 * @package Mageplaza\GoogleTagManager\Block
 */
class TagManager extends Template
{
	/**
	 * @var HelperData
	 */
	protected $_helper;

	/**
	 * @var HelperCookie
	 */
	protected $_helperCookie;

	/**
	 * @var \Magento\Catalog\Model\CategoryFactory
	 */
	protected $_categoryFactory;

	/**
	 * @var \Magento\Catalog\Model\ProductFactory
	 */
	protected $_productFactory;

	/**
	 * @var \Magento\Framework\ObjectManagerInterface
	 */
	protected $_objectManager;

	/**
	 * @var \Magento\Catalog\Helper\Data
	 */
	protected $_catalogHelper;

	/**
	 * @var \Magento\Catalog\Block\Product\ListProduct
	 */
	protected $_listProduct;

	/**
	 * @var \Magento\Catalog\Block\Product\ProductList\Toolbar
	 */
	protected $_toolbar;

	/**
	 * TagManager constructor.
	 * @param \Magento\Catalog\Model\ProductFactory $productFactory
	 * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
	 * @param \Magento\Catalog\Helper\Data $catalogHelper
	 * @param \Magento\Catalog\Block\Product\ListProduct $listProduct
	 * @param \Magento\Catalog\Block\Product\ProductList\Toolbar $toolbar
	 * @param \Magento\Framework\View\Element\Template\Context $context
	 * @param \Mageplaza\GoogleTagManager\Helper\Data $helper
	 * @param \Magento\Cookie\Helper\Cookie $helperCookie
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param array $data
	 */
	public function __construct(
		ProductFactory $productFactory,
		CategoryFactory $categoryFactory,
		Data $catalogHelper,
		ListProduct $listProduct,
		Toolbar $toolbar,
		Context $context,
		HelperData $helper,
		HelperCookie $helperCookie,
		ObjectManagerInterface $objectManager,
		array $data = []
	)
	{
		$this->_catalogHelper   = $catalogHelper;
		$this->_productFactory  = $productFactory;
		$this->_categoryFactory = $categoryFactory;
		$this->_helper          = $helper;
		$this->_helperCookie    = $helperCookie;
		$this->_objectManager   = $objectManager;
		$this->_listProduct     = $listProduct;
		$this->_toolbar         = $toolbar;
		parent::__construct($context, $data);
	}

	/**
	 * Get GTM Id
	 * @param null $storeId
	 * @return mixed
	 */
	public function getTagId($storeId = null)
	{
		return $this->_helper->getTagId($storeId);
	}

	/**
	 * Check condition show page
	 * @return bool
	 */
	public function checkConditionShowPage()
	{
		if (!$this->_helperCookie->isUserNotAllowSaveCookie() && $this->_helper->isEnabled()) {
			return true;
		}

		return false;
	}

	/**
	 * Get product detail info
	 * @return $this|array|mixed
	 */
	public function getPageInfo()
	{
		$action = $this->getRequest()->getFullActionName();

		switch ($action) {

			// Product list page
			case 'catalog_category_view' :
				/**
				 * get current breadcrumb path name
				 */
				$path        = $this->_helper->getBreadCrumbsPath();
				$products      = [];
				$result        = [];
				$i             = 0;
				$loadedProduct = $this->_listProduct->getLoadedProductCollection()->addAttributeToSelect('manufacturer')->addAttributeToSelect('color');
				$loadedProduct->setCurPage($this->getPageNumber())->setPageSize($this->getPageLimit());

				$data ['ecommerce'] = [
					'currencyCode' => $this->_helper->getCurrentCurrency()
				];

				foreach ($loadedProduct as $item) {
					$i++;
					$products[$i]['id']    = $item->getId();
					$products[$i]['name']  = $item->getName();
					$products[$i]['price'] = number_format($item->getFinalPrice(), 2);
					if ($this->_helper->getProductBrand($item)) {
						$products[$i]['brand'] = $this->_helper->getProductBrand($item);
					}
					if ($this->_helper->getColor($item)) {
						$products[$i]['variant'] = $this->_helper->getColor($item);
					}
					$products[$i]['path']          = implode(" > ", $path) . " > " . $item->getName();
					$products[$i]['category_path'] = implode(" > ", $path);
					$result []                     = $products[$i];

				}

				$data ['ecommerce']['impressions'] = $result;
				
				return $data;
				break;

			// Product detail view page
			case 'catalog_product_view' :

				$currentProduct = $this->_helper->getGtmRegistry()->registry('product');
				$data           = $this->_helper->getProductDetailData($currentProduct);
				return $data;
				break;

			// Check out page
			case 'checkout_index_index' :

				return $this->getCheckoutProductData();
				break;

			// One step check out page
			case 'onestepcheckout_index_index' :

				if (!$this->_helper->moduleIsEnable('Mageplaza_Osc')) {
					return null;
				} else {

					return $this->getCheckoutProductData();
					break;
				}
				break;

			// Purchase page
			case 'checkout_onepage_success':
				$order              = $this->_helper->getSessionManager()->getLastRealOrder();
				$products           = [];
				$data ['ecommerce'] = [
					'purchase' => [
						'actionField' => [
							'affiliation' => $this->_helper->getAffiliationName(),
							'order_id'    => $order->getIncrementId(),
							'subtotal'    => number_format($order->getSubtotal(), 2),
							'shipping'    => number_format($order->getBaseShippingAmount(), 2),
							'tax'         => number_format($order->getBaseTaxAmount(), 2),
							'total'       => number_format($order->getGrandTotal(), 2),
							'discount'    => number_format($order->getDiscountAmount(), 2),
							'coupon'      => (string)$order->getCouponCode()
						]
					]
				];
				$items              = $order->getAllVisibleItems();

				foreach ($items as $item) {

					$products[] = $this->_helper->getProductOrderedData($item);
				}
				$data ['ecommerce']['products'] = $products;

				return $data;
				break;

			default:
				return null;
		}
	}

	/**
	 * Get the page limit in category product list page
	 * @return int
	 */
	public function getPageLimit()
	{
		$result = ($this->_toolbar) ? $this->_toolbar->getLimit() : 9;

		return (int)$result;
	}

	/**
	 * Get the current page number of category product list page
	 * @return int|mixed
	 */
	public function getPageNumber()
	{
		$result = ($this->getRequest()->getParam('p')) ? $this->getRequest()->getParam('p') : 1;

		return $result;
	}

	/**
	 * Get AddToCartData data layered from checkout session
	 * @return null|string
	 */
	public function getAddToCartData()
	{

		if ($this->_helper->getSessionManager()->getAddToCartData()) {
			$data = json_encode($this->_helper->getSessionManager()->getAddToCartData());

			return $data;
		}

		return null;
	}

	/**
	 * Remove AddToCartData data layered from checkout session
	 */
	public function removeAddToCartData()
	{
		$this->_helper->getSessionManager()->setAddToCartData(null);
	}


	/**
	 * Get RemoveFromCartData from checkout session
	 * @return null|string
	 */
	public function getRemoveFromCartData()
	{
		if ($this->_helper->getSessionManager()->getRemoveFromCartData()) {
			$data = json_encode($this->_helper->getSessionManager()->getRemoveFromCartData());

			return $data;
		}

		return null;
	}

	/**
	 * Remove RemoveFromCartData from checkout session
	 */
	public function removeRemoveFromCartData()
	{
		$this->_helper->getSessionManager()->setRemoveFromCartData(null);
	}

	/**
	 * Get product data in checkout page
	 * @return mixed
	 */
	public function getCheckoutProductData()
	{
		$cart = $this->_objectManager->get('\Magento\Checkout\Model\Cart');
		// retrieve quote items array
		$items          = $cart->getQuote()->getAllVisibleItems();
		$products       = [];
		$data ['event'] = 'checkout';

		$checkoutData ['actionField'] = ['step' => 0, 'option' => ''];
		$checkoutData ['hasItems']    = $cart->getQuote()->hasData();
		$checkoutData ['hasCoupon']   = ($cart->getQuote()->getCouponCode()) ? true : false;
		$checkoutData ['coupon']      = ($cart->getQuote()->getCouponCode()) ? $cart->getQuote()->getCouponCode() : "";
		$checkoutData ['total']       = number_format($cart->getQuote()->getData('grand_total'), 2);

		foreach ($items as $item) {

			$products[] = $this->_helper->getProductCheckOutData($item);
		}
		$data ['ecommerce']['checkout'] = $checkoutData;
		$data ['ecommerce']['products'] = $products;

		return $data;
	}
}