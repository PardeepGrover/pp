<?php
/**
 * Mageplaza
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Mageplaza.com license that is
 * available through the world-wide-web at this URL:
 * https://www.mageplaza.com/LICENSE.txt
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Mageplaza
 * @package     Mageplaza_GoogleTagManager
 * @copyright   Copyright (c) 2017 Mageplaza (http://www.mageplaza.com/)
 * @license     https://www.mageplaza.com/LICENSE.txt
 */

namespace Mageplaza\GoogleTagManager\Helper;

use Magento\Catalog\Model\CategoryFactory;
use Magento\Catalog\Model\ResourceModel\Category;
use Magento\Checkout\Model\Session;
use Magento\Eav\Api\AttributeSetRepositoryInterface;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\ObjectManagerInterface;
use Magento\Framework\Registry;
use Magento\Store\Model\StoreManagerInterface;
use Mageplaza\Core\Helper\AbstractData;
use Magento\Catalog\Model\ProductFactory;

/**
 * Class Data
 * @package Mageplaza\GoogleTagManager\Helper
 */
class Data extends AbstractData
{

	const XML_PATH_GENERAL_ENABLED = 'googletagmanager/general/is_enabled';
	const XML_PATH_GENERAL_TAG_ID = 'googletagmanager/general/tag_id';

	/**
	 * @var \Magento\Catalog\Model\CategoryFactory
	 */
	protected $_categoryFactory;
	/**
	 * @var \Magento\Checkout\Model\Session
	 */
	protected $_checkoutSession;
	/**
	 * @var \Magento\Framework\Registry
	 */
	protected $_registry;

	/**
	 * @var \Magento\Eav\Api\AttributeSetRepositoryInterface
	 */
	protected $_attributeSet;

	/**
	 * @var \Magento\Catalog\Model\ResourceModel\Category
	 */
	protected $_resourceCategory;

	/**
	 * @var \Magento\Catalog\Model\ProductFactory
	 */
	protected $_productFactory;

	/**
	 * @var \Magento\Catalog\Helper\Data
	 */
	protected $_catalogHelper;

	/**
	 * Data constructor.
	 * @param \Magento\Framework\App\Helper\Context $context
	 * @param \Magento\Framework\ObjectManagerInterface $objectManager
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \Magento\Catalog\Model\CategoryFactory $categoryFactory
	 * @param \Magento\Framework\Registry $registry
	 * @param \Magento\Eav\Api\AttributeSetRepositoryInterface $attributeSetRepository
	 * @param \Magento\Catalog\Model\ResourceModel\Category $resourceCategory
	 * @param \Magento\Catalog\Model\ProductFactory $productFactory
	 * @param \Magento\Catalog\Helper\Data $catalogHelper
	 * @param \Magento\Checkout\Model\Session $checkoutSession
	 */
	public function __construct(
		Context $context,
		ObjectManagerInterface $objectManager,
		StoreManagerInterface $storeManager,
		CategoryFactory $categoryFactory,
		Registry $registry,
		AttributeSetRepositoryInterface $attributeSetRepository,
		Category $resourceCategory,
		ProductFactory $productFactory,
		\Magento\Catalog\Helper\Data $catalogHelper,
		Session $checkoutSession
	)
	{
		$this->_categoryFactory  = $categoryFactory;
		$this->_registry         = $registry;
		$this->_checkoutSession  = $checkoutSession;
		$this->_attributeSet     = $attributeSetRepository;
		$this->_resourceCategory = $resourceCategory;
		$this->_productFactory   = $productFactory;
		$this->_catalogHelper    = $catalogHelper;
		parent::__construct(
			$context,
			$objectManager,
			$storeManager
		);
	}

	/**
	 * @return \Magento\Framework\Registry
	 */
	public function getGtmRegistry()
	{
		return $this->_registry;
	}

	/**
	 * Get GTM checkout session
	 * @return \Magento\Checkout\Model\Session
	 */
	public function getSessionManager()
	{
		return $this->_checkoutSession;
	}

	/**
	 * Enable GTM configure
	 * @param null $storeId
	 * @return mixed
	 */
	public function isEnabled($storeId = null)
	{
		return $this->getConfigValue(self::XML_PATH_GENERAL_ENABLED, $storeId);

	}

	/**
	 * Get GTM ID configure
	 * @param null $storeId
	 * @return mixed
	 */
	public function getTagId($storeId = null)
	{
		return $this->getConfigValue(self::XML_PATH_GENERAL_TAG_ID, $storeId);
	}


//	/**
//	 * Get product categories name
//	 * @param $categoryIds
//	 * @return array|string
//	 */
//	public function getCategoriesName($categoryIds)
//	{
//		$categoriesName = [];
//		foreach ($categoryIds as $categoryId) {
//			$categoriesName[] = $this->_categoryFactory->create()->load($categoryId)->getName();
//		}
//
//		$this->getCategoryPath($categoryIds[0]);
//
//		return $categoriesName[0];
//	}
//
//	/**
//	 * Get category path of product
//	 * @param $categoryId
//	 * @return null|string
//	 */
//	public function getCategoryPath($categoryId)
//	{
//		$categoriesName = [];
//		$categoryPath   = $this->_resourceCategory->getCategoryPathById($categoryId[0]);
//		$categoryIds    = array_slice(explode('/', $categoryPath), 2);
//
//		foreach ($categoryIds as $id) {
//			$categoriesName[] = $this->_categoryFactory->create()->load($id)->getName();
//		}
//		if (isset($categoriesName)) {
//			$path = implode(" > ", $categoriesName);
//
//			return $path;
//		}
//
//		return null;
//	}

	/**
	 * Get Store Currency Code. EG:  'currencyCode': 'EUR','USD'
	 * @return mixed
	 */
	public function getCurrentCurrency()
	{
		return $this->storeManager->getStore()->getCurrentCurrencyCode();
	}

	/**
	 * Measure the additional of a product to a shopping cart.
	 * @param $product
	 * @param $quantity
	 * @return array
	 */
	public function getAddToCartData($product, $quantity)
	{
		$data                 = [
			'event'     => 'addToCart',
			'ecommerce' => [
				'currencyCode' => $this->getCurrentCurrency(),
			]
		];
		$productData          = [];
		$productData['id']    = $product->getId();
		$productData['sku']   = $product->getSku();
		$productData['name']  = $product->getName();
		$productData['price'] = number_format($product->getFinalPrice(), 2);
		if ($this->getProductBrand($product)) {
			$productData['brand'] = $this->getProductBrand($product);
		}
//		if ($this->getGtmRegistry()->registry('product_category123')){
//			$productData['category'] = $this->getGtmRegistry()->registry('product_category123');
//		}
//		$productData['category'] = $this->getCategoriesName($product->getCategoryIds());
		if ($this->getColor($product)) {
			$productData['variant'] = $this->getColor($product);
		}
		$productData['quantity']                 = $quantity;
		$data ['ecommerce']['add']['products'][] = $productData;

		return $data;

	}


	/**
	 * Measure the removal of a product from a shopping cart.
	 * @param $product
	 * @param $quantity
	 * @return array
	 */
	public function getRemoveFromCartData($product, $quantity)
	{
		$data                 = [
			'event'     => 'removeFromCart',
			'ecommerce' => [
				'currencyCode' => $this->getCurrentCurrency(),
			]
		];
		$productData          = [];
		$productData['id']    = $product->getId();
		$productData['sku']   = $product->getSku();
		$productData['name']  = $product->getName();
		$productData['price'] = number_format($product->getFinalPrice(), 2);
		if ($this->getProductBrand($product)) {
			$productData['brand'] = $this->getProductBrand($product);
		}

		if ($this->getColor($product)) {
			$productData['variant'] = $this->getColor($product);
		}
		$productData['quantity']                 = $quantity;
		$data['ecommerce']['remove']['products'] = $productData;

		return $data;
	}


	/**
	 * Get data layered in product detail page
	 * @param $product
	 * @return array
	 */
	public function getProductDetailData($product)
	{
		$categoryPath = '';
		$path         = $this->getBreadCrumbsPath();
		if (count($path) > 1) {
			array_pop($path);
			$categoryPath = implode(" > ", $path);
		}

		$data               = [
			'ecommerce' => [
				'currencyCode' => $this->getCurrentCurrency(),
				'detail'       => []
			]
		];
		$productData        = [];
		$productData['id']  = $product->getId();
		$productData['sku'] = $product->getSku();
		if ($this->getColor($product)) {
			$productData['variant'] = $this->getColor($product);
		}
		$productData['name']  = html_entity_decode($product->getName());
		$productData['price'] = number_format($product->getFinalPrice(), 2);
		if ($this->getProductBrand($product)) {
			$productData['brand'] = $this->getProductBrand($product);
		}
		$productData['attribute_set_id']   = $product->getAttributeSetId();
		$productData['attribute_set_name'] = $this->_attributeSet
			->get($product->getAttributeSetId())->getAttributeSetName();

		if ($product->getCategory()) {
			$productData['category'] = $product->getCategory()->getName();
		}

		if ($categoryPath) {
			$productData['category_path'] = $categoryPath;
		}

		$data['ecommerce']['detail']['products'][] = $productData;

		return $data;
	}

	/**
	 * @param $item
	 * @return mixed
	 */
	public function getProductCheckOutData($item)
	{

		if ($item->getProductType() == "configurable"){
			$selectedProduct = $this->_productFactory->create();
			$selectedProduct->load($selectedProduct->getIdBySku($item->getSku()));
		}else{
			$selectedProduct = $item->getProduct();
		}

		$data['id']    = $selectedProduct->getId();
		$data['name']  = $selectedProduct->getName();
		$data['sku']   = $selectedProduct->getSku();
		$data['price'] = number_format($selectedProduct->getFinalPrice(), 2);

		if ($this->getColor($selectedProduct)) {
			$data['variant'] = $this->getColor($selectedProduct);
		}
		if ($this->getProductBrand($selectedProduct)) {
			$data['brand'] = $this->getProductBrand($selectedProduct);
		}

		$data['attribute_set_id']   = $selectedProduct->getAttributeSetId();
		$data['attribute_set_name'] = $this->_attributeSet
			->get($selectedProduct->getAttributeSetId())->getAttributeSetName();

		return $data;
	}

	/**
	 * @param $item
	 * @return mixed
	 */
	public function getProductOrderedData($item)
	{

		if ($item->getProductType() == "configurable") {
			$selectedProduct = $this->_productFactory->create();
			$selectedProduct->load($selectedProduct->getIdBySku($item->getSku()));
		}else{
			$selectedProduct = $item->getProduct();
		}

		$data['id']    = $selectedProduct->getId();
		$data['name']  = $selectedProduct->getName();
		$data['price'] = number_format($item->getBasePrice(), 2);
		if ($this->getColor($selectedProduct)) {
			$data['variant'] = $this->getColor($selectedProduct);
		}
		if ($this->getProductBrand($selectedProduct)) {
			$data['brand'] = $this->getProductBrand($selectedProduct);
		}

		$data['attribute_set_id']   = $selectedProduct->getAttributeSetId();
		$data['attribute_set_name'] = $this->_attributeSet->get($selectedProduct->getAttributeSetId())->getAttributeSetName();
		$data['quantity']           = number_format($item->getQtyOrdered(), 0);

		return $data;
	}

	/**
	 * Get web site name
	 * @return string
	 */
	public function getAffiliationName()
	{

		$webName   = $this->storeManager->getWebsite()->getName();
		$groupName = $this->storeManager->getGroup()->getName();
		$storeName = $this->storeManager->getStore()->getName();

		return $webName . '-' . $groupName . '-' . $storeName;
	}

	/**
	 * Check the following modules is installed
	 * @param $moduleName
	 * @return bool
	 */
	public function moduleIsEnable($moduleName)
	{
		$result = false;
		if ($this->_moduleManager->isEnabled($moduleName)) {
			switch ($moduleName) {
				case 'Mageplaza_Shopbybrand' :
					$result = true;
					break;
				case 'Mageplaza_Osc' :
					$oscHelper = $this->objectManager->create('\Mageplaza\Osc\Helper\Data');
					$result    = ($oscHelper->isEnabled()) ? true : false;
					break;
			}
		}

		return $result;
	}

	/**
	 * Get product brand if module Mageplaza_Shopbybrand is installed
	 * @param $product
	 * @return null
	 */
	public function getProductBrand($product)
	{

		$attCode = null;
		if ($this->moduleIsEnable('Mageplaza_Shopbybrand')) {

			$sbbHelper    = $this->objectManager->create('\Mageplaza\Shopbybrand\Helper\Data');
			$brandFactory = $this->objectManager->create('\Mageplaza\Shopbybrand\Model\BrandFactory');
			if (!$sbbHelper->getGeneralConfig('enabled') || !$sbbHelper->getAttributeCode()) {
				return null;
			} else {
				$attCode = $sbbHelper->getAttributeCode();
				if ($this->_request->getFullActionName() == 'checkout_index_index') {

					$product = $this->objectManager->create('Magento\Catalog\Model\Product')
						->load($product->getId());
				}
				$brand = $brandFactory->create()->loadByOption($product->getData($attCode))->getValue();

				return $brand;
			}
		}

		return null;
	}

	/**
	 * Get color of configurable and simple product
	 * @param $product
	 * @return array|null|string
	 */
	public function getColor($product)
	{
		$color = [];

		switch ($product->getTypeId()) {
			case 'configurable' :
				$configurationAtt = $product->getTypeInstance(true)->getConfigurableAttributesAsArray($product);

				foreach ($configurationAtt as $att) {
					if ($att['label'] == 'Color') {
						foreach ($att['values'] as $value) {
							$color[] = $value['label'];
						}
						break;
					}
				}
				$color = implode(',', $color);

				return $color;
				break;

			case 'simple' :
				$table          = $this->objectManager->create('Magento\Eav\Model\Entity\Attribute\Source\Table');
				$eavAttribute   = $this->objectManager->get('\Magento\Eav\Model\Entity\Attribute');
				$colorAttribute = $eavAttribute->load($eavAttribute->getIdByCode('catalog_product', 'color'));
				$allColor       = $table->setAttribute($colorAttribute)->getAllOptions(false);
				foreach ($allColor as $color) {
					if ($color['value'] == $product->getData('color')) {
						return $color['label'];
					}
				}

				return null;
				break;

			default:
				return null;
		}
	}

	/**
	 * @return array
	 */
	public function getBreadCrumbsPath()
	{
		$path        = [];
		$breadCrumbs = $this->_catalogHelper->getBreadcrumbPath();
		foreach ($breadCrumbs as $breadCrumb) {
			$path [] = $breadCrumb['label'];
		}

		return $path;
	}
}