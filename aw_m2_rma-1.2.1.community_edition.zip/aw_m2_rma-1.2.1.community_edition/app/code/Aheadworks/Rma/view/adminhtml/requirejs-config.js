/**
* Copyright 2016 aheadWorks. All rights reserved.
* See LICENSE.txt for license details.
*/

var config = {
    map: {
        '*': {
            awRmaCustomFieldOptions: 'Aheadworks_Rma/js/customfield/form/options'
        }
    }
};
