<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2018 Amasty (https://www.amasty.com)
 * @package Amasty_ShopbyPage
 */

namespace Amasty\ShopbyPage\Model\Config\Source;

class Category extends \Amasty\Shopby\Model\Source\Category
{
}
