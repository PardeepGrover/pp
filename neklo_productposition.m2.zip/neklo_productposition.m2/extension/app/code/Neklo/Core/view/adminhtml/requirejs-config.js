/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            'neklocore/subscribe' : 'Neklo_Core/js/subscribe/script',
            'neklocore/contact' : 'Neklo_Core/js/contact/script'
        }
    }
};
