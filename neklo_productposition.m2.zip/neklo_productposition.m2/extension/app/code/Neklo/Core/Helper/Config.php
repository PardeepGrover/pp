<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Helper;

class Config extends \Magento\Framework\App\Helper\AbstractHelper
{

    const NOTIFICATION_TYPE = 'neklo_core/notification/type';

    /**
     * @param null $scopeType
     * @return array
     */
    public function getNotificationTypeList($scopeType = null)
    {
        return explode(',', $this->scopeConfig->getValue(self::NOTIFICATION_TYPE, $scopeType));
    }

}