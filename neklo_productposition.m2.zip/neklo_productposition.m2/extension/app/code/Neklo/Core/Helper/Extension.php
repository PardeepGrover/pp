<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Helper;

class Extension extends \Magento\Framework\App\Helper\AbstractHelper
{

    protected $_protectedModuleCodeList = array(
        'Neklo_Core'
    );

    protected $_cacheKey = null;
    protected $_moduleConfigList = null;
    protected $_moduleList = null;

    protected $_magentoModuleList;

    public function __construct(
        \Magento\Framework\Module\ModuleList $magentoModuleList,
        \Magento\Framework\App\Helper\Context $context
    )
    {
        $this->_magentoModuleList = $magentoModuleList;
        parent::__construct($context);
    }


    public function getModuleList()
    {
        if (is_null($this->_moduleList)) {
            $moduleList = array();
            foreach ($this->getModuleConfigList() as $moduleCode => $moduleConfig) {
                $moduleList[$moduleCode] = array(
                    'name'    => $moduleConfig['name'] ? $moduleConfig['name'] : $moduleCode,
                    'version' => $moduleConfig['setup_version'],
                );
            }
            $this->_moduleList = $moduleList;
        }
        return $this->_moduleList;
    }

    public function getModuleConfigList()
    {
        if (is_null($this->_moduleConfigList)) {

            //$moduleConfigList = (array)Mage::getConfig()->getNode('modules')->children();
            $moduleConfigList = $this->_magentoModuleList->getAll();
            //$moduleConfigList = $this->scopeConfig->getValue('modules');
            ksort($moduleConfigList);
            $moduleList = array();
            foreach ($moduleConfigList as $moduleCode => $moduleConfig) {
                if (!$this->_canShowExtension($moduleCode, $moduleConfig)) {
                    continue;
                }
                $moduleList[$moduleCode.'_m2'] = $moduleConfig;
            }
            $this->_moduleConfigList = $moduleList;
        }
        return $this->_moduleConfigList;
    }

    public function getCacheKey()
    {
        if (is_null($this->_cacheKey)) {
            $cacheList = array();
            foreach ($this->getModuleConfigList() as $moduleCode => $moduleConfig) {
                $version = explode('.', $moduleConfig['setup_version']);
                $version = (intval($version[0]) - 1) << 12 | intval($version[1]) << 6 | intval($version[2]) << 0;

                //TODO: what this doing
                $cacheList[] = dechex(intval($version)) . 't' . dechex(intval($version)) . 't' . substr(md5(strtolower($moduleCode)), 0, 2) . $version;
            }
            $this->_cacheKey = implode('n', $cacheList);
        }
        return $this->_cacheKey;
    }

    /**
     * @param string $code
     * @param \Magento\Framework\App\Config\Element $config
     *
     * @return bool
     */
    protected function _canShowExtension($code, $config)
    {
        if (!$code || !$config) {
            return false;
        }
//        if (!($config instanceof \Magento\Framework\App\Config\Element)) {
//            return false;
//        }
        /*if (!is_object($config) || !method_exists($config, 'is') || !$config->is('active', 'true')) {
            return false;
        }*/
        if (!$this->_isNekloExtension($code)) {
            return false;
        }
        if ($this->_isProtectedExtension($code)) {
            return false;
        }
        return true;
    }

    /**
     * @param string $code
     *
     * @return bool
     */
    protected function _isNekloExtension($code)
    {
        return (strstr($code,'Neklo_') !== false);
    }

    /**
     * @param string $code
     *
     * @return bool
     */
    protected function _isProtectedExtension($code)
    {
        return in_array($code, $this->_protectedModuleCodeList);
    }

}