<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Model;

class Observer
{
    /**
     * @var \Magento\Backend\Model\Auth\Session
     */
    protected $_backendAuthSession;

    /**
     * @var \Neklo\Core\Model\Feed
     */
    protected $_feed;

    public function __construct(
        \Magento\Backend\Model\Auth\Session $backendAuthSession,
        \Neklo\Core\Model\Feed $feed
    ) {
        $this->_feed = $feed;
        $this->_backendAuthSession = $backendAuthSession;
    }

    public function checkUpdate(\Magento\Framework\Event\Observer $observer)
    {
        if ($this->_backendAuthSession->isLoggedIn()) {
            $this->_feed->checkUpdate();
        }
    }

    public function sortModuleTabList(\Magento\Framework\Event\Observer $observer)
    {
        $configContainerBlock = $observer->getBlock();
        if (!$configContainerBlock instanceof \Magento\Config\Block\System\Config\Tabs) {
            return null;
        }

        $tabList = $configContainerBlock->getTabs();
        foreach ($tabList as $tab) {
            if ($tab->getId() !== 'neklo') {
                continue;
            }

            $sectionList = $tab->getSections();
            $sectionListArray = $sectionList->toArray();
            $sectionListArray = $sectionListArray['items'];
            usort($sectionListArray, array($this, '_sort'));

            $tab->getSections()->clear();
            foreach ($sectionListArray as $_section) {
                $section = new \Magento\Framework\DataObject($_section);
                $section->setId($_section['id']);
                $tab->getSections()->addItem($section);
            }
        }
    }

    protected function _sort($a, $b)
    {
        if ($a['id'] == 'neklo_core') {
            return 1;
        }
        if ($b['id'] == 'neklo_core') {
            return -1;
        }

        return strcasecmp($a['label'], $b['label']);
    }

}