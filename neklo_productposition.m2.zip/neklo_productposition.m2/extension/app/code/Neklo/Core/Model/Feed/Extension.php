<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Model\Feed;

class Extension
{

    const FEED_URL = 'http://store.neklo.com/feed.json';
    const CACHE_ID = 'NEKLO_EXTENSION_FEED';
    const CACHE_LIFETIME = 172800;

    /**
     * @var \Magento\Framework\App\Cache
     */
    protected $_cacheManager;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $_jsonHelper;


    function __construct(
        \Magento\Framework\App\Cache $cacheManager,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) {
        $this->_cacheManager = $cacheManager;
        $this->_jsonHelper = $jsonHelper;
    }


    public function getFeed()
    {
        if (!$feed = $this->_cacheManager->load(self::CACHE_ID)) {
            $feed = $this->_getFeedFromResource();
            $this->_save($feed);
        }
        $feedArray = $this->_jsonHelper->jsonDecode($feed);
        if (!is_array($feedArray)) {
            $feedArray = array();
        }

        return $feedArray;
    }

    protected function _getFeedFromResource()
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_URL, self::FEED_URL);
        curl_setopt(
            $ch,
            CURLOPT_HTTPHEADER,
            array(
                'Content-Type: application/json'
            )
        );
        $result = curl_exec($ch);
        if (curl_getinfo($ch, CURLINFO_HTTP_CODE) != 200) {
            $result = '{}';
        }
        curl_close($ch);

        return $result;
    }

    protected function _save($feed)
    {
        $this->_cacheManager->save($feed, self::CACHE_ID, array(), self::CACHE_LIFETIME);

        return $this;
    }

}