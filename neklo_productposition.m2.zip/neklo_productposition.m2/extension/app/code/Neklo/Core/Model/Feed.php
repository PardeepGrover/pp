<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Model;

class Feed extends \Magento\Framework\Model\AbstractModel
{

    const XML_USE_HTTPS_PATH    = 'neklo_core/notification/use_https';
    const XML_FEED_URL_PATH     = 'neklo_core/notification/feed_url';
    const XML_FREQUENCY_PATH    = 'neklo_core/notification/frequency';

    const LAST_CHECK_CACHE_KEY  = 'neklo_core_admin_notifications_last_check';

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Neklo\Core\Helper\Data
     */
    protected $_dataHelper;

    /**
     * @var \Neklo\Core\Helper\Config
     */
    protected $_configHelper;

    /**
     * @var \Neklo\Core\Helper\Extension
     */
    protected $_extensionHelper;


    public function __construct(
        \Neklo\Core\Helper\Data $dataHelper,
        \Neklo\Core\Helper\Extension $extensionHelper,
        \Neklo\Core\Helper\Config $configHelper,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Model\ResourceModel\AbstractResource $resource = null,
        \Magento\Framework\Data\Collection\AbstractDb $resourceCollection = null,
        array $data = []
    ) {
        $this->_scopeConfig = $scopeConfig;
        $this->_dataHelper = $dataHelper;
        $this->_configHelper = $configHelper;
        $this->_extensionHelper = $extensionHelper;

        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }


    public function getFrequency()
    {
        return $this->_scopeConfig->getValue(self::XML_FREQUENCY_PATH) * 3600;
    }

    public function getLastUpdate()
    {
        return $this->_cacheManager->load(self::LAST_CHECK_CACHE_KEY);
    }

    public function setLastUpdate()
    {
        $this->_cacheManager->save(time(), self::LAST_CHECK_CACHE_KEY);
        return $this;
    }

    public function getFeedUrl()
    {
        if (is_null($this->_feedUrl)) {
            $this->_feedUrl = ($this->_scopeConfig->isSetFlag(self::XML_USE_HTTPS_PATH) ? 'https://' : 'http://') . $this->_scopeConfig->getValue(self::XML_FEED_URL_PATH);
        }
        return $this->_feedUrl;
    }

    public function checkUpdate()
    {
        if (($this->getFrequency() + $this->getLastUpdate()) > time()) {
            return $this;
        }

        $feedData = array();
        $feedXml = $this->getFeedData();
        if ($feedXml && $feedXml->channel && $feedXml->channel->item) {
            foreach ($feedXml->channel->item as $item) {
                if (!$this->_isAllowedItem($item)) {
                    continue;
                }
                $feedData[] = array(
                    'severity'      => (int)$item->severity,
                    'date_added'    => $this->getDate((string)$item->pubDate),
                    'title'         => (string)$item->title,
                    'description'   => (string)$item->description,
                    'url'           => (string)$item->link,
                );
            }
            if ($feedData) {
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
                /** @var \Magento\AdminNotification\Model\Inbox $inboxModel */
                $inboxModel = $objectManager->get('\Magento\AdminNotification\Model\Inbox');
                $inboxModel->parse(array_reverse($feedData));
            }

        }
        $this->setLastUpdate();
        return $this;
    }

    protected function _isAllowedItem($item)
    {
        $itemType = $item->type ? $item->type : \Neklo\Core\Model\Source\Subscription\Type::INFO_CODE;
        $allowedTypeList = $this->_configHelper->getNotificationTypeList();
        if ($itemType == \Neklo\Core\Model\Source\Subscription\Type::UPDATE_CODE) {
            if (in_array(\Neklo\Core\Model\Source\Subscription\Type::UPDATE_ALL_CODE, $allowedTypeList)) {
                return true;
            }
            if (in_array(\Neklo\Core\Model\Source\Subscription\Type::UPDATE_CODE, $allowedTypeList)) {
                $installedExtensionList = array_keys($this->_extensionHelper->getModuleList());
                $isPresent = false;
                foreach ($item->extension->children() as $extensionCode) {
                    if (in_array((string)$extensionCode, $installedExtensionList)) {
                        $isPresent = true;
                    }
                }
                return $isPresent;
            }
        }
        if (!in_array($itemType, $allowedTypeList)) {

            return false;
        }
        return true;
    }

}