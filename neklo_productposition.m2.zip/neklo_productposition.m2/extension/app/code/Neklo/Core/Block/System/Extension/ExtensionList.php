<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Block\System\Extension;

class ExtensionList extends \Magento\Backend\Block\Template
{

    const DOMAIN = 'http://store.neklo.com/';
    const IMAGE_EXTENSION = '.jpg';

    protected $_feedData = null;

    /**
     * @var \Neklo\Core\Helper\Extension
     */
    protected $_extensionHelper;

    /**
     * @var \Neklo\Core\Model\Feed\Extension
     */
    protected $_feedExtension;

    public function __construct(
        \Neklo\Core\Helper\Extension $extensionHelper,
        \Neklo\Core\Model\Feed\Extension $feedExtension,
        \Magento\Backend\Block\Template\Context $context,
        array $data = []
    ) {
        parent::__construct($context, $data);

        $this->_feedExtension = $feedExtension;
        $this->_extensionHelper = $extensionHelper;
    }


    /**
     * @param string $code
     *
     * @return bool
     */
    public function canShowExtension($code)
    {
        $feedData = $this->_getExtensionInfo(strtolower($code));

        return !!count($feedData);
    }

    /**
     * @return array
     */
    public function getExtensionList()
    {
        return $this->_extensionHelper->getModuleConfigList();
    }

    /**
     * @param string $code
     *
     * @return mixed
     */
    public function getExtensionName($code)
    {
        $feedData = $this->_getExtensionInfo(strtolower($code));
        if (!array_key_exists('name', $feedData)) {
            return $code;
        }

        return $feedData['name'];
    }

    /**
     * @param string $code
     * @param $config
     *
     * @return bool
     */
    public function isExtensionVersionOutdated($code, $config)
    {
        $currentVersion = $this->getExtensionVersion($config);
        $lastVersion = $this->getLastExtensionVersion($code);

        return version_compare($currentVersion, $lastVersion) === -1;
    }

    public function getExtensionVersion($config)
    {
        $version = (string)$config['setup_version'];
        if (!$version) {
            return '';
        }

        return $version;
    }

    public function getLastExtensionVersion($code)
    {
        $feedData = $this->_getExtensionInfo(strtolower($code));
        if (!array_key_exists('version', $feedData)) {
            return '0';
        }

        return $feedData['version'];
    }

    public function getExtensionUrl($code)
    {
        $feedData = $this->_getExtensionInfo(strtolower($code));
        if (!array_key_exists('url', $feedData)) {
            return null;
        }

        return $feedData['url'];
    }

    public function getImageUrl($code)
    {
        $imgUrl = self::DOMAIN . 'cache/' . ($this->_getCacheKey() ? $this->_getCacheKey() . '/' : '') . strtolower($code) . self::IMAGE_EXTENSION;

        return $imgUrl;
    }

    protected function _getCacheKey()
    {
        return $this->_extensionHelper->getCacheKey();
    }

    protected function _getExtensionInfo($code)
    {
        if (is_null($this->_feedData)) {
            $this->_feedData = $this->_feedExtension->getFeed();
        }
        if (!array_key_exists($code, $this->_feedData)) {
            return array();
        }

        return $this->_feedData[$code];
    }

}