<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Controller\Adminhtml\Newsletter;

class Subscribe extends \Magento\Backend\App\Action
{
    use \Neklo\Core\Controller\Adminhtml\Traits\ZendClient;

    const SUBSCRIBE_URL = 'http://store.neklo.com/neklo_subscribe/index/index/';

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $_jsonHelper;

    /**
     * @var \Magento\Framework\Url\Encoder
     */
    protected $_urlEncoder;

    /**
     * @var \Magento\Framework\HTTP\ZendClient
     */
    protected $_zendClient;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @param Action\Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Framework\Url\Encoder $urlEncoder,
        \Magento\Framework\HTTP\ZendClient $zendClient,
        \Magento\Backend\App\Action\Context $context
    ) {
        parent::__construct($context);

        $this->_jsonHelper = $jsonHelper;
        $this->_urlEncoder = $urlEncoder;
        $this->_zendClient = $zendClient;
        $this->_logger = $logger;
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $result = array(
            'success' => true,
        );
        try {
            $data = $this->getRequest()->getPost();
            $this->_subscribe($data);
        } catch (\Exception $e) {
            $this->_logger->critical($e);
            $result['success'] = false;
            $this->getResponse()->setBody(\Zend_Json::encode($result));

            return;
        }

        $this->getResponse()->setBody(\Zend_Json::encode($result));

    }

    /**
     * @param $data
     */
    protected function _subscribe($data)
    {
        // Used from trait
        $this->sendPostData($data, self::SUBSCRIBE_URL, $this->_zendClient, $this->_urlEncoder, $this->_jsonHelper);
    }

    /**
     * Check the permission to run it
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Neklo_Core::config');
    }

}