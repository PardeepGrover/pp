<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Controller\Adminhtml\Traits;

trait ZendClient
{

    /**
     * @param $data
     * @param $url
     * @param \Magento\Framework\HTTP\ZendClient $zendClient
     * @param \Magento\Framework\Url\EncoderInterface $urlEncoder
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper
     * @throws \Zend_Http_Client_Exception
     */
    public function sendPostData(
        $data,
        $url,
        \Magento\Framework\HTTP\ZendClient $zendClient,
        \Magento\Framework\Url\EncoderInterface $urlEncoder,
        \Magento\Framework\Json\Helper\Data $jsonHelper)
    {
        $params = $urlEncoder->encode($jsonHelper->jsonEncode($data));
        if ($params) {
            $httpClient = $zendClient;
            $httpClient
                ->setMethod(\Magento\Framework\HTTP\ZendClient::POST)
                ->setUri($url)
                ->setConfig(['maxredirects' => 0, 'timeout' => 30])
                ->setRawData($params)
                ->request();
        }
    }

}