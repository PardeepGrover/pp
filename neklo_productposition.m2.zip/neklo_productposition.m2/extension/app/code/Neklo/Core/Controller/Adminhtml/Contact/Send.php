<?php
/*
NOTICE OF LICENSE

This source file is subject to the NekloEULA that is bundled with this package in the file ICENSE.txt.

It is also available through the world-wide-web at this URL: http://store.neklo.com/LICENSE.txt

Copyright (c)  Neklo (http://store.neklo.com/)
*/

namespace Neklo\Core\Controller\Adminhtml\Contact;

class Send extends \Magento\Backend\App\Action
{
    use \Neklo\Core\Controller\Adminhtml\Traits\ZendClient;

    const CONTACT_URL = 'http://store.neklo.com/neklo_support/index/index/';

    /**
     * @var \Magento\Framework\View\Result\PageFactory|PageFactory
     */
    protected $_resultPageFactory;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $_jsonHelper;

    /**
     * @var \Magento\Framework\Url\Encoder
     */
    protected $_urlEncoder;

    /**
     * @var \Magento\Framework\HTTP\ZendClient
     */
    protected $_zendClient;

    /**
     * @var \Psr\Log\LoggerInterface
     */
    protected $_logger;

    /**
     * @param Action\Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        \Psr\Log\LoggerInterface $logger,
        \Magento\Framework\Json\Helper\Data $jsonHelper,
        \Magento\Framework\Url\Encoder $urlEncoder,
        \Magento\Framework\HTTP\ZendClient $zendClient,
        \Magento\Backend\App\Action\Context $context
    ) {
        parent::__construct($context);

        $this->_jsonHelper = $jsonHelper;
        $this->_urlEncoder = $urlEncoder;
        $this->_zendClient = $zendClient;
        $this->_logger = $logger;
    }

    /**
     * Check the permission to run it
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Neklo_Core::config');
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        $result = array(
            'success' => true,
        );
        try {
            $data = $this->getRequest()->getPost();
            $data['version'] = \Magento\Framework\AppInterface::VERSION;
            $data['url'] = $this->_url->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
            $data['id'] = '<order_item_customer></order_item_customer>';
            $this->_sendContactEmail($data);
        } catch (\Exception $e) {
            $this->_logger->error($e->getMessage());
            $result['success'] = false;
            $this->getResponse()->setBody(\Zend_Json::encode($result));

            return;
        }
        $this->getResponse()->setBody(\Zend_Json::encode($result));
    }

    /**
     * @param $data
     */
    protected function _sendContactEmail($data)
    {
        // Used from trait
        $this->sendPostData($data, self::CONTACT_URL, $this->_zendClient, $this->_urlEncoder, $this->_jsonHelper);
    }

}